#!/usr/bin/env python3
"""Check attribution boundaries with an inlined Step and unresolved native leaf frames."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

names = ['host', 'Borough.Headless.ProfileDump.TimedStep(sim)', 'ShoppingEngine.Step(tick)',
         'WalkScratch.Search(graph)', 'BuildingResidency.NthIn(area)', 'UNMANAGED_CODE_TIME',
         'System.Diagnostics.Stopwatch.GetTimestamp()', 'reporting',
         'Borough.Core.Simulation.Layers()', 'Borough.Core.Space.LineSourceQueries.Level(graph)',
         'TripEngine.Start(citizen)', 'CommuteEngine.Generate(tick)']
events = []
def interval(start, end, frames):
    events.extend({'type': 'O', 'at': start, 'frame': frame} for frame in frames)
    events.extend({'type': 'C', 'at': end, 'frame': frame} for frame in reversed(frames))
interval(0, 100, [0, 7])
interval(100, 120, [0, 1, 2, 3, 5])
interval(120, 130, [0, 1, 2, 4, 5])
interval(130, 230, [0, 1, 6, 5])
interval(230, 240, [0, 1, 8, 9, 5])
interval(240, 255, [0, 1, 2, 10, 3, 5])
interval(255, 280, [0, 1, 11, 10, 3, 5])
source = {'shared': {'frames': [{'name': name} for name in names]},
          'profiles': [{'type': 'evented', 'unit': 'milliseconds', 'startValue': 0, 'endValue': 280, 'events': events}]}
with tempfile.TemporaryDirectory(prefix='borough-profile-summary-test-') as folder:
    path = Path(folder)
    (path / 'input.json').write_text(json.dumps(source))
    subprocess.run([sys.executable, str(Path(__file__).with_name('summarize-simulation-profile.py')),
                    str(path / 'input.json'), '--output', str(path / 'result.json')],
                   stdout=subprocess.DEVNULL, check=True)
    result = json.loads((path / 'result.json').read_text())
    assert result['step_weight_ms'] == 80
    assert result['route_weight_ms_by_caller'] == {'shopping': 35, 'commuting': 25}
    assert result['building_selection_weight_ms_by_caller'] == {'shopping': 10}
    leaf = {row['method']: row['self_weight_ms'] for row in result['methods']}
    assert leaf['WalkScratch.Search(graph)'] == 60
    assert leaf['BuildingResidency.NthIn(area)'] == 10
    assert 'reporting' not in leaf and 'UNMANAGED_CODE_TIME' not in leaf
    assert 'System.Diagnostics.Stopwatch.GetTimestamp()' not in leaf
    subprocess.run([sys.executable, str(Path(__file__).with_name('summarize-simulation-profile.py')),
                    str(path / 'input.json'), '--scope', 'layers', '--output', str(path / 'layers.json')],
                   stdout=subprocess.DEVNULL, check=True)
    layers = json.loads((path / 'layers.json').read_text())
    assert layers['step_weight_ms'] == 10
    assert layers['route_weight_ms_by_caller'] == {}
    assert layers['building_selection_weight_ms_by_caller'] == {}
    assert {row['method']: row['self_weight_ms'] for row in layers['methods']}[
        'Borough.Core.Space.LineSourceQueries.Level(graph)'] == 10
    subprocess.run([sys.executable, str(Path(__file__).with_name('summarize-simulation-profile.py')),
                    str(path / 'input.json'), '--scope', 'move', '--output', str(path / 'move.json')],
                   stdout=subprocess.DEVNULL, check=True)
    move = json.loads((path / 'move.json').read_text())
    assert move['step_weight_ms'] == 70
    assert move['move_weight_ms_by_work'] == {
        'shopping_estimate_search': 20, 'recorded_shopping_search': 15,
        'other_recorded_search': 25, 'non_search_move': 10}
print('PASS: excludes reporting and timestamps; handles inlined Step and native leaf markers.')
