import json
from pathlib import Path
p=Path(__file__).parent

def read(path):
    return [json.loads(line) for line in path.read_text().splitlines()]

counted=read(p/'run.jsonl'); control=read(p/'control.jsonl')
assert counted[-1]['type']==control[-1]['type']=='end'
assert counted[-1]==control[-1]
old=read(Path('/tmp/borough-layers-20260907/million-counted.jsonl'))
old_work={r['tick']:r for r in old if r.get('type')=='work'}
rows=[r for r in counted if r.get('type')=='work']
assert len(rows)==4096
assert [r['tick'] for r in rows]==list(range(14336,18432))
for r in rows:
    for name,work in [('estimates',r['shoppingWork']['Estimates']),('shopping',r['shoppingRoutes']),('other',r['otherRoutes'])]:
        probe=r['routeReuse'][name]
        assert probe['Searches']==work['Searches']
        assert probe['Unique']+probe['Repeats']+probe['Untracked']==probe['Searches']
    if r['tick'] in old_work:
        before=old_work[r['tick']]
        for field in ('travellers','vehicles','shopping','shoppingWork','shoppingRoutes','otherRoutes'):
            assert r[field]==before[field],(r['tick'],field)
volatile={'MeanMs','P95Ms','P99Ms','MaxMs','MaxTick','AllocatedBytes','Gen0Collections','Gen1Collections','Gen2Collections','ManagedHeapBytes','WorkingSetBytes'}
a=[r for r in counted if 'MeanMs' in r]; b=[r for r in control if 'MeanMs'in r]
assert len(a)==len(b)==2
for left,right in zip(a,b):
    assert {k:v for k,v in left.items() if k not in volatile}=={k:v for k,v in right.items() if k not in volatile}
days=[]
for sample,baseline in zip(a,b):
    day=[r for r in rows if sample['StartTick']<=r['tick']<sample['StartTick']+sample['Ticks']]
    reuse={name:{key:sum(r['routeReuse'][name][key] for r in day) for key in ('Searches','Repeats','Untracked')} for name in ('estimates','shopping','other')}
    growth=[{'tick':r['tick'],'stepAllocatedBytes':r['allocated'],**change} for r in day for change in r['tableGrowth']]
    days.append(dict(start=sample['StartTick'],reuse=reuse,growth=growth,countedAllocation=sample['AllocatedBytes'],controlAllocation=baseline['AllocatedBytes'],countedHeap=sample['ManagedHeapBytes'],controlHeap=baseline['ManagedHeapBytes']))
result=dict(end=counted[-1],activityMatches=True,firstDayWorkMatches=True,days=days,
    limitations='Overlapping diagnostic captures; no timing claim. Reuse is exact searches within one Tick and category, not a cross-Tick cache hit rate. Growth payload excludes array headers and alignment. Control resumes the same save, not a continuous run from creation.')
(p/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='days'},indent=2))
for d in days: print({k:v for k,v in d.items() if k!='growth'},'growth tables',[g['Table'] for g in d['growth']])
