import json,os,pathlib,socket,subprocess,tempfile,time
out=pathlib.Path('/tmp/borough-preparation/regenerate');out.mkdir(exist_ok=True)
(out/'boot.drive').write_text('64 pause\n')
with tempfile.TemporaryDirectory(prefix='borough-regen-') as folder:
 address=str(pathlib.Path(folder)/'s.sock')
 with (out/'game.log').open('w') as log:
  p=subprocess.Popen(['godot','--path','src/Borough.Godot','--','--ruleset','rulesets/stress-shopping.toml','--citizens','16000','--start-at','64','--drive',str(out/'boot.drive'),'--listen',address,'--route-workers','8'],env=dict(os.environ,BOROUGH_LOG='1'),stdout=log,stderr=subprocess.STDOUT)
  try:
   deadline=time.monotonic()+60
   while not pathlib.Path(address).exists():
    assert time.monotonic()<deadline;time.sleep(.05)
   with socket.socket(socket.AF_UNIX) as c:
    c.settimeout(60);c.connect(address)
    with c.makefile('rwb',buffering=0) as w:
     def send(cmd):
      w.write((cmd+'\n').encode());r=w.readline().decode();assert r.startswith('ok\t'),r;return r
     def state(name):
      path=out/(name+'.json');send('ui read '+str(path));return json.loads(path.read_text())
     send('');before=state('before');assert before['Tick']==64
     send('ui key Tab');send('ui key Enter')
     reply=send('ui key Escape');assert 'preparing' in reply,reply
     send('');cancelled=state('cancelled');assert cancelled['Hash']==before['Hash'] and cancelled['Tick']==64
     send('ui key Enter');send('');after=state('after');assert after['Tick']==1,after['Tick']
     send('shoot '+str(out/'regenerated.png'));time.sleep(.3);send('quit')
   assert p.wait(timeout=30)==0
  finally:
   if p.poll() is None:p.terminate();p.wait(timeout=30)
 (out/'checks.json').write_text(json.dumps({'cancelled_hash':cancelled['Hash'],'regenerated_hash':after['Hash'],'regenerated_tick':after['Tick']},indent=2))
 print((out/'checks.json').read_text())
