Background city preparation: Godot Debug functional observations on the M4 Pro desktop, not reference timings.
Build src/Borough.Godot (Debug) and Borough.Headless (Release); run scripts/check-city-preparation.py and scripts/check-shell-threading.py with the recorded arguments.
loading-final is the final progress/cancellation capture. aged is successful preparation and gameplay at 16000 Citizens, start Tick 14336. regenerate.py verifies cancellation preserves a standing city before completing a replacement; its replay.txt verifies the new log.
final-source contains the shell source and tests at completion. Core is unchanged by this work; prior threading/capacity archives own its earlier changes.
