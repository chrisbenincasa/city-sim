from pathlib import Path
import json,re
root=Path(__file__).parent
ignored=set('MeanMs P95Ms P99Ms MaxMs MaxTick AllocatedBytes Gen0Collections Gen1Collections Gen2Collections ManagedHeapBytes WorkingSetBytes RoutePrepared RouteUsed RouteFallback'.split())
groups={}; results={}
for p in sorted(root.glob('*.jsonl')):
    records=[json.loads(s) for s in p.read_text().splitlines()]
    if not records or records[-1].get('type')!='end': continue
    conditions=records[0]; sample=records[-2]; end=records[-1]
    key=(conditions['Citizens'],conditions['Seed'],sample['StartTick'],sample['Ticks'])
    activity={k:v for k,v in sample.items() if k not in ignored}
    if key in groups:
        name,old,oldend=groups[key]
        assert activity==old, (p.name,name,{k:(old.get(k),v) for k,v in activity.items() if old.get(k)!=v})
        assert end==oldend,(p.name,name,end,oldend)
    else:groups[key]=(p.stem,activity,end)
    resources=(root/(p.stem+'-resources.txt')).read_text()
    readings={}
    for label in ('maximum resident set size','peak memory footprint','involuntary context switches'):
        m=re.search(r'(\d+)\s+'+label,resources)
        if m:readings[label]=int(m.group(1))
    results[p.stem]={'sample':sample,'end':end,'resources':readings}
summary={'conditions':'Sequential Release captures, M4 Pro, desktop open, no concurrent builds/tests/captures; not quiet-machine budget ratification.','activityAndEndHashEqualWithinEachFixture':True,'groups':[{'population':k[0],'seed':k[1],'startTick':k[2],'ticks':k[3],'activity':v[1],'end':v[2]} for k,v in groups.items()],'runs':results}
(root/'comparisons.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,r in results.items():
 s=r['sample'];print(name,*(round(s[k],3) for k in ['MeanMs','P95Ms','P99Ms','MaxMs']),s['AllocatedBytes'],s.get('RouteUsed',0))
print('Matched activity and end State Hash in',len(results),'completed runs.')
