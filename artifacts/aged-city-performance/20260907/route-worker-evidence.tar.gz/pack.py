from pathlib import Path
import hashlib,json,tarfile,shutil
root=Path(__file__).parent
out=Path('artifacts/aged-city-performance/20260907')
archive=out/'route-worker-evidence.tar.gz'
manifest=out/'route-worker-manifest.json'
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
entries=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=p.relative_to(root),recursive=False)
record={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':entries}
manifest.write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 for e in entries:
  content=tar.extractfile(e['path']).read()
  assert len(content)==e['bytes'] and hashlib.sha256(content).hexdigest()==e['sha256'], e['path']
shutil.copy2(root/'comparisons.json',out/'route-worker-comparisons.json')
print('Verified',len(entries),'files in',archive,'bytes',archive.stat().st_size)
