# 0067 — Aged-city performance

Investigate the expensive Ticks in `ProfileDump` with `stress-shopping.toml`, then fix the largest
measured cost without changing the city. Earlier `minimal.toml` readings do not establish capacity.

## Sequence and gates

1. **Attribute** — Release, M4 Pro, one simulation thread, seed 0, 100,000 Citizens;
   age 14,336 Ticks and capture the next 2,048. Keep untraced timings separate from managed
   stack samples. Preserve commands, assembly/Ruleset fingerprints, activity, trace and State Hash.
   Deliver a ranked list of functions, distinguishing inclusive from self samples and separating
   `Simulation.Step` from reporting. Stack samples are not CPU utilization measurements.
2. **Count** — instrument only the leading consumers: route requests and visited nodes;
   shopping candidates/retries; active Travellers; periodic scans or allocations, as indicated.
   Correlate work with expensive Ticks. A hypothesis must predict which count or cost changes.
3. **Control** — compare 1,000/10,000/100,000/1,000,000 Citizens, then vary population at fixed network,
   network at fixed population, and congestion at fixed population/network. Preserve the
   original fixture as a control. Record actual activity and rejected/failed journeys.
4. **Optimize** — choose the largest supported cost. First add a regression at its real call
   boundary, then fix it. Require unchanged State Hashes and activity on identical Inputs.
   Re-run untraced mean/p95/p99/max and allocations, a second seed, and relevant assertions.
   Retain an optimization only with a measured benefit and no unexplained regression.
5. **Broaden** — add functioning care/school and other implemented systems with activity checks;
   separate a functioning economy from distress. Run an older horizon and watch the city in Godot.
   Update `0013` only for costs actually isolated; no million-Citizen extrapolation from this fixture.

## Outstanding work

This is the remaining work queue for this investigation. Findings below supply the evidence;
backing out a candidate does not close the cost it targeted. Apply step 4's retention gate to every
optimization. The row-prefix optimization and the initial population ladder are complete.

| Order | Open item | Completion evidence |
|---|---|---|
| 1 | Move attribution and the bounded commute route-worker experiment are complete below. Broader route parallelism and cross-Tick route reuse remain untested. | Opt-in workers preserve replay/save/reload and measured activity; scaling and costs below. The within-Tick probe does not justify an exact cache for the dominant non-Shopping category. |
| 2 | **Next:** compare resumed and continuous capacities and test the restoration policy for the three attributed allocation bursts. | No table growth in the next measured Day; continuous-run comparison and longer horizons remain open. |
| 3 | Reassess remaining Shopping candidate-selection and unsuccessful discovery work after the prefix change. | Separate candidate-query cost from route cost and successful activity; measure before proposing another change. |
| 4 | Revisit noise-query cost and resolve the rejected candidate's seed-1 mean discrepancy before considering retention. | Controlled untraced comparisons distinguish a code regression from capture variation; isolated Layers improvement alone is insufficient. |
| 5 | Extend population/network/congestion controls to the million-Citizen workload and repeat with another seed. | Same-network and same-population controls separate multiplicands; retain activity, failures and hashes. The existing ladder alone does not establish scaling. |
| 6 | Broaden to functioning care, school and other implemented systems, including a functioning economy alongside distress. | Activity assertions prove the added systems actually run; compare their attributed costs. |
| 7 | Measure older horizons and the weekly workload pattern. | Multiple comparable Days distinguish schedule effects, ageing, recurring allocation and sustained memory growth. |
| 8 | Watch the aged city in Godot, connect shell/frame costs to the simulation readings, and evaluate a dedicated Step thread. | Driven observation under recorded population, age, speed and view conditions; a snapshot/command ownership boundary before moving Step. Headless timings alone do not establish player-visible performance. |
| 9 | Take quiet-machine reference captures and update `0013` for isolated consumers. | Reproducible readings with machine/thread/guard conditions; keep current desktop diagnostics distinct from budget ratification. |
| 10 | ✅ Preserve selected raw evidence beyond temporary capture directories. | `artifacts/aged-city-performance/20260907/prior-evidence.tar.gz`; its manifest verifies every archived file. The reproducible checkpoint is excluded. |

### Threading decision gate

Evaluate threading after Move and allocation attribution (items 1–2); do not require exhausting
every possible serial micro-optimization first. Begin a bounded parallelism experiment when a
representative aged workload repeatedly misses the target on the named reference hardware, the
remaining cost is attributed, and independent work accounts for enough of it to matter.

The existing target is 15.6 ms per Tick at one million Citizens on one core of the reference class
([`0105`](../docs/adr/0105-the-target-speed-is-4x-at-a-million-and-a-rung-dilates-rather-than-being-withdrawn.md),
[`0106`](../docs/adr/0106-a-wall-clock-budget-names-a-machine-class-and-a-thread-count-or-it-is-not-a-budget.md)).
Current M4 Pro desktop diagnostics justify investigating the gap, not redefining that contract.
Any multicore wall-clock claim must name the hardware and worker count explicitly.

Before committing to threading:

- Bound the opportunity: serial cost plus parallel work divided by worker count, plus scheduling,
  synchronization and memory costs. If the serial remainder already exceeds the target, threading
  that candidate cannot suffice. Measure scaling; do not infer it from CPU count.
- Prototype the dominant suitable consumer. Route work is a candidate; Layers and Decide alone
  cannot address a workload dominated by Move. Prove independence against the state actually read
  by current queries, including ordering-sensitive traffic and availability.
- Require end-to-end mean/tail improvement after overhead, with acceptable allocation and memory
  on representative workloads. Separate CPU work from waiting, GC and bandwidth limits.
- Add thread-count equivalence, including one versus eight threads, alongside replay/save-reload
  and activity checks. Worker completion order must not affect the city. Delaying route results to
  another Tick is not automatically hash-preserving.

Moving serial `Step` off the render thread is a separate shell responsiveness decision; it does
not by itself increase simulation throughput. `docs/05` §6 provides candidate build order, not a
measurement that the current route implementation is ready for workers.

## Initial hypotheses

Ranked before attribution: routing grows with search work; shopping repeats unsuccessful work;
congestion grows the active movement population; periodic scans/GC produce tail costs.
Changing one multiplicand must change its predicted cost before it becomes the explanation.

## Capture controls

The reference timing capture runs without other workloads. Record exceptions; local diagnostics do
not ratify a budget. Exclude ageing, reporting and end invariants from Tick timings, but keep
staggered invariants active. Explicitly disable the Decide-write guard to match the game. Profiling
must preserve the State Hash. Do not hide throughput costs by moving work onto another thread.

`stress-shopping.toml` has synthetic supply and declining successful purchases at the older horizon;
it is an aged stress fixture, not a balanced mature economy. Geometry and traffic distributions grow
with population, so the current ladder does not identify an algorithm's complexity by itself.

## Progress

- First daily attribution capture complete. `WalkScratch.Search`/`PopRoot` and
  `BuildingResidency.NthIn` lead; `ShoppingEngine.Step` is their main calling path.
  This is aggregate attribution, not a diagnosis of individual tail Ticks.
- Traced and untraced 100,000-Citizen runs from Tick 14,336 through 16,384 produced identical
  workload/allocation counters and State Hash `D551BD2FA385894A`. Local artifacts are under
  `/tmp/borough-attribution-steady`; the reproduction command below is the durable capture path.
- Counting and controlled fixtures complete. The row-prefix optimization preserves candidate order
  and city activity; validation and comparison results are below. Tick 14,608's additional cost is
  in the Layers phase. Noise distance queries are attributed, but the candidate optimization was
  backed out after a second-seed mean regression. Million-Citizen captures are below.
  Bounded commute workers are measured below. **Next:** restoration-capacity controls.
- `ProfileDump.TimedStep` preserves a stack frame despite JIT inlining. The analysis excludes
  the ending timestamp and reports managed leaf weights, including unresolved native time.

```sh
dotnet tool install dotnet-trace --tool-path /tmp/borough-profiler --version 10.0.731102
dotnet build src/Borough.Headless -c Release
python3 scripts/profile-simulation.py --trace-tool /tmp/borough-profiler/dotnet-trace \
  --output /tmp/borough-attribution
```

The output directory must be empty. `step.json`/`step.txt` filter the Speedscope trace to the
simulation boundary; the tool's unfiltered reports also include waiting and end-of-run checks.

## Work counts — 2026-09-07

`--profile-work` enables caller-owned `ShoppingWork`, `BuildingQueryWork` and `RouteWork` counters.
`ProfileDump.Measure` emits one work record per Tick outside the timed Step. Route requests include
shortcuts; searches count actual scratch initializations. `Settled` counts nodes, `Pops` includes
stale heap entries, and `Pushes` counts successful relaxations including seeds. Recorded-route
counters cover `TripEngine`'s Leg queries, separated by Shopping purpose; they are not every routing
consumer in the simulation. Candidate counters cover shopping discovery only.

Release .NET 10.0.2, M4 Pro, one simulation thread, seed 0, `stress-shopping.toml`, age 14,336,
measure 2,048 Ticks; Decide guard off, staggered invariants on. Chrome/iTerm desktop activity remained
present: **local diagnostics, not a quiet-machine budget reading**. Commands, assembly fingerprints,
per-Tick logs and summaries are in `/tmp/borough-work-20260907`.

| Citizens | Shopping estimate searches | Settled / estimate search | Settled / recorded Shopping search | Candidate calls | Cells / candidate |
|---:|---:|---:|---:|---:|---:|
| 1,000 | 3,677 | 7.71 | 6.14 | 28,937 | 126.53 |
| 10,000 | 21,689 | 42.83 | 38.89 | 683,200 | 324.82 |
| 100,000 | 122,080 | 402.80 | 309.01 | 10,289,995 | 1,112.09 |

These worlds also change geometry and activity. The ladder does **not** isolate population scaling.
Completed Trips were 4,094 / 41,680 / 416,610; purchases 63 / 2,414 / 2,448. All three completed end
invariants with zero no-route and over-budget Trip counts. Declining purchases per Citizen remain
part of the fixture's distress, not evidence of a functioning mature economy.

At 100,000 Citizens, the slowest 1% of counted Ticks averaged 403 settled nodes per shopping
estimate search versus 403 overall, and 301 per recorded Shopping search versus 309 overall.
They contained more searches, rather than larger average searches. Candidate selection visited
11.44 billion Cells over the measured Day but followed only 3.12 Building links per call on average.
Heap pops exceeded settled nodes by less than 0.02% in each measured route category. These counts
support investigating search request volume and Cell scanning; they do not establish identical
repeated queries, cache hit rates or an optimization's benefit.

Tick 14,608 remained the maximum at every population. At 100,000 it took 53.13 ms instrumented,
against 32.78 and 32.54 ms for its neighbours, with comparable total settled-node counts and zero
allocation on all three. It coincides with the land-value cadence; that is a lead, not attribution.
Daily stack attribution and the cause of one maximum are still different questions.

The 100,000-Citizen uncounted/counted runs matched all activity and allocation counters and State
Hash `D551BD2FA385894A`, also matching the prior capture. Uncounted mean/p95/p99/max were
11.68 / 24.03 / 28.96 / 48.20 ms; counted were 15.13 / 27.66 / 33.72 / 53.13 ms under the desktop
conditions above. **Counter instrumentation is materially intrusive.** JSON emission is outside
Step but can affect later GC and process scheduling; counted timings cannot replace the baseline.

Reproduce the counted capture after the Release build; omit `--profile-work` for its control:

```sh
dotnet src/Borough.Headless/bin/Release/net10.0/Borough.Headless.dll \
  --profile --profile-work --ruleset rulesets/stress-shopping.toml --citizens 100000 \
  --seed 0 --warmup-ticks 14336 --ticks 2048 --no-decide-guard > /tmp/borough-work.jsonl
python3 scripts/summarize-work-profile.py /tmp/borough-work.jsonl --output /tmp/borough-work-summary.json
```

Focused assertions covered shortcut counter resets, Cell scans including empty Cells, and profiling
through shopping without changing the city. The spatial-index change followed in the section below.

## Controlled fixtures and candidate-selection change — 2026-09-07

`--profile-population` separates the initial population from `--citizens`, which retains its network
and table sizing. `SyntheticCity.PeopleInto` accepts the smaller population; the default path is
unchanged. Conditions now include a fingerprint of node coordinates, Segment endpoints, modes,
lengths, speeds and capacities. This verifies the fixed network, rather than inferring it from a flag.

The controlled runs retain seed 0, the original Ruleset and the 14,336 + 2,048 Tick horizon. At
10,000 Citizens, increasing the network from 453 nodes / 758 Segments to 2,829 nodes / 5,514 Segments
increased settled nodes per shopping estimate from 42.83 to 68.11. Candidate calls were nearly
unchanged (683,200 / 680,935), but Cells inspected per candidate rose from 324.82 to 1,083.58.
At 100,000 Citizens on the identical larger network, those readings were 402.80 nodes per estimate,
10,289,995 candidate calls and 1,112.09 Cells per candidate. More Citizens also change occupied
geography and journey distributions; the fixed network alone does not hold those constant.

A separate copy changes only traffic `alpha_percent` from 15 to 0. On the identical 100,000-Citizen
network, peak Travellers fell from 42,763 to 11,443, while completed Trips rose from 416,610 to
575,887 and recorded Shopping searches from 356,608 to 706,254. Over-budget outcomes rose from
0 to 2,533, with no no-route outcomes in either run; purchases were 2,448 / 2,463. Faster journeys
permit more work, so active movement population alone does not predict cost. The over-budget
outcomes have not been attributed to a specific refusal path.

The first optimization targets the spatial cost these controls isolate. `BuildingResidency.PrefixRow`
builds row prefixes lazily; `Add`, `Remove` and `Rebuild` invalidate them. `CountIn` sums row ranges,
and `NthIn` skips whole rows and finds the selected Cell by binary search. Cell order and the
intrusive Building list order remain unchanged. Storage is bounded by the map dimensions. Work
records distinguish prefix reads and Cells read during rebuilding from the old linear Cell scans.

The shopping-boundary regression first failed with 8,620,049 index reads for 28,937 draws, then
passed after the change. Ordinal queries are checked against enumeration after warm reads,
demolition, slot reuse and rebuilding. Save/reload and derived-state assertions are included.
`--profile-work` now also records phase durations through `Simulation.PhaseCompleted`; the clock
remains in the host. These instrumented durations exclude Advance/save after Commit and carry
observer overhead; they are diagnostic, not replacements for untraced Step timings.

### Verification and remaining tail

The controlled artifacts, frozen baseline/optimized binaries, assembly fingerprints, commands and
comparison checks are in `/tmp/borough-controls-20260907`. All timing comparisons here are Release
on the M4 Pro, one simulation thread, with the desktop open; they are local diagnostics, not budget
ratification. The no-delay counted run overlapped validation during ageing. The first seed-0
baseline was accidentally paused inside its measurement window; its timing is discarded and the
`baseline-seed0-repeat` capture is the replacement. Exceptions are retained with the artifacts.

The counted comparison preserves candidate calls and links, every route-work counter, per-Tick
shopping activity, Travellers, Vehicles and allocation. Logical index work per candidate falls from
1,210.94 to 48.81, including the associated count queries and prefix rebuilding: a 95.97% reduction.
These are counter-defined lookups, not hardware memory transactions. The prefix array adds roughly
one MiB per world at the current map dimensions; measured Step allocation is unchanged.

At Tick 14,608 in the optimized counted run, Move costs 23.84 ms and Layers 19.08 ms. The preceding
and following Ticks spend 23.69 ms in Move and effectively no time in Layers. Thus the additional
spike is isolated to Layers, not inferred from the cadence alone. This phase reading does not
establish that all 19.08 ms belongs to one method; the internal attribution follows below.

The Release build and 57 focused assertions pass, including the shopping-boundary regression,
ordinal maintenance, save/reload and the derived-state audit. The full milestone suite was not run.

Retained after untraced comparisons on identical Inputs at 100,000 Citizens. Timing units below are
milliseconds per Tick under the machine, thread count and desktop conditions stated above.

| Seed | Build | Mean | p95 | p99 | Maximum |
|---:|---|---:|---:|---:|---:|
| 0 | before | 11.78 | 24.19 | 30.09 | 49.00 |
| 0 | after | 8.59 | 19.50 | 23.69 | 43.04 |
| 1 | before | 12.12 | 24.64 | 30.79 | 54.64 |
| 1 | after | 8.93 | 20.38 | 25.05 | 41.82 |

Mean Step cost fell 27.01% on seed 0 and 26.29% on seed 1. Every daily activity and allocation
counter matched; State Hashes remained `D551BD2FA385894A` and `FDD1DBA842295351`, respectively.
At 1,000 Citizens on seed 0, mean cost fell from 0.03170 to 0.02616 ms, with p95/p99/max also lower
and State Hash `A4763BF6939AD36B` unchanged. This is an observed small-fixture improvement, not a
claim that the prefix is cheaper for every possible query distribution.

The broader care/school/economy fixtures, older horizon and Godot observation in step 5 remain
outstanding. These results establish a benefit on the measured stress workload, not city capacity.

## Million-Citizen captures and Layers — 2026-09-07

**Outcome:** checkpoint support, GC/memory reporting and trace selection are retained. The noise
candidate and its temporary counters are **not retained**: the second seed failed the untraced mean
gate. All “after” readings below refer to that rejected candidate. The final Core matches “before”.

`ProfileDump` now accepts `--profile-save` and `--profile-load`. A resumed capture verifies the save's
Ruleset and seed; `--warmup-ticks` names the absolute capture Tick. The million-Citizen comparison
loads the same Tick-12,288 save, warms scratch for a full Day, and measures Tick 14,336–16,384.
Save restoration and reporting are outside Step timing. GC collection deltas cover measured Steps;
managed heap and working set are snapshots after each sample, not peak memory or simulation state.
`/usr/bin/time -l` records process peak resident memory separately, including setup and warmup.

The first-Day feasibility pilot at 1,000,000 Citizens completed with end invariants passing and State
Hash `E9D79CD2C256E113`. Release .NET 10.0.2, M4 Pro, one simulation thread, desktop open,
`stress-shopping.toml`, seed 0, Tick 0–2,048: mean 89.39 ms, p95 113.41 ms, p99 2,416.33 ms,
maximum 4,424.45 ms at Tick 0. Process peak resident memory was 676,790,272 bytes. This includes
startup scheduling and is **not an aged-city result**. Its network has 26,463 nodes and 53,498
Segments; network SHA-256 is `466C348F9BF185B31D90E2FD24FCE039917BCB3A4D1F29822F4DEA27F5F822F2`.
Artifacts are in `/tmp/borough-million-20260907`; the subsequent staging run overlaps focused
validation and its intermediate timings are not controlled comparisons.

The Layers-only stack selection (`summarize-simulation-profile.py --scope layers`) captures
112.11 ms of sampled stack weight from the 100,000-Citizen aged trace. All selected weight passes
through `MapLayers.SetLandValueTargets` and `LineSourceQueries.Level`: managed self shares are
44.44% in `Level`, 31.64% in `IntegerMath.SqrtFloor`, and 23.92% in `DistanceTiles`. These are
sample weights, not the phase's wall time. Presence rebuilding and land-value drift do not appear
in this selection; that does not establish zero cost. The trace, commands and frozen builds are
in `/tmp/borough-layers-20260907`.

The candidate's `LineSourceQueries.DistanceSquared` preserved rounded projection and delayed roots
until needed. A nearest-Street candidate must beat the current **floored** distance; a contribution is
outside range only at squared distance at least `(range + 1)²`. Tests cover both floor boundaries.
The work regression failed before the change with 1,552 square roots for 1,552 distances.
Its temporary `MapLayers.QueryWork` exposed query/distance/root counters in `--profile-work` records;
these covered noise queries made through MapLayers, not every possible line-source caller.

### Aged million-Citizen result

Release .NET 10.0.2 on the M4 Pro, one simulation thread, desktop open, seed 0, the same
`stress-shopping.toml` and Tick 14,336–16,384 window. Both builds include the row-prefix optimization;
“after” adds the squared-distance rejection. Captures ran sequentially without overlapping builds,
tests or staging. These remain local diagnostics, not quiet-machine budget ratification.

| Build | Mean ms | p95 ms | p99 ms | Maximum ms |
|---|---:|---:|---:|---:|
| before | 124.71 | 407.80 | 471.85 | 582.55 |
| after | 121.32 | 391.36 | 450.00 | 549.18 |

The mean is 2.72% lower in this pair; a single pair does not establish that all of that difference
comes from the changed query. Both maxima occur at Tick 14,608. State Hash `FAE56437750E05C7`,
every activity counter and measured allocation match. End invariants pass. At capture end there are
1,000,000 Citizens, 86,938 Buildings and 756,929 employed Citizens. The Day peaks at 358,826
Travellers and 340,862 Vehicles, completes 1,929,265 Trips and records 201,792 Shopping outings,
2,461 purchases and 89,624 delivered Goods; no NoRoute or OverBudget outcomes are reported.

Both builds allocate 925,778,216 bytes during measured Steps and record GC generation counts
2 / 1 / 1. Managed heap snapshots are approximately 1.668 GB in both. Process peak resident memory
is 1,364,017,152 bytes before and 1,540,145,152 after; these process peaks include restoration and
warmup and are not evidence of a simulation-state memory change. The save loader restores table
storage from slot counts; later capacity growth is a candidate explanation for allocation, not an
attributed finding. A full Day of warmup has **not** established allocation-free steady state.

The checkpoint's State Hash is `5D2B7C3AF9419C35` at Tick 12,288. Reproduction with a Release host:

```sh
dotnet src/Borough.Headless/bin/Release/net10.0/Borough.Headless.dll --profile \
  --ruleset rulesets/stress-shopping.toml --citizens 1000000 --seed 0 \
  --warmup-ticks 0 --ticks 12288 --no-decide-guard --profile-save /tmp/million-day6.save
dotnet src/Borough.Headless/bin/Release/net10.0/Borough.Headless.dll --profile \
  --ruleset rulesets/stress-shopping.toml --citizens 1000000 --seed 0 \
  --profile-load /tmp/million-day6.save --warmup-ticks 14336 --ticks 2048 --no-decide-guard
```

Use a new save path: profiling refuses to overwrite an existing file. Add `--profile-work` for
per-Tick phase/work attribution, separately from the untraced reading. `profile-simulation.py` also
accepts `--profile-load` and `--binary` for a traced run against the same save and frozen build.

### Query verification

The 100,000-Citizen counted comparison against the earlier prefix-optimized capture preserves
per-Tick route work, shopping selection, activity and allocation. Across 87,552 MapLayers noise
queries, 5,887,788 valid distance calculations now require 1,105,295 square roots: 81.23% avoid
one. Previously every valid distance calculation took a root. Counted Layers time totals
105.49 → 75.10 ms over the Day. At Tick 14,608, Layers costs 19.08 → 13.54 ms while Move costs
23.84 → 23.96 ms; this supports the query change as the cause of the reduced periodic spike.
These are observer-instrumented phase timings under the local diagnostic conditions above.

The million-Citizen counted capture also preserves activity, allocation and State Hash. Its Move
phase totals 243.24 s over the Day; Layers totals 0.71 s and Growth 1.35 s. At Tick 14,608,
Move is 417.53 ms and Layers 136.50 ms. These are phase costs, not an internal Move attribution.
Noise performs 48,289,696 valid distance calculations with 10,662,774 roots, avoiding 77.92%.

| Million-Citizen routing consumer | Searches during the Day | Settled nodes per search |
|---|---:|---:|
| Shopping estimates | 223,713 | 1,588.32 |
| Recorded Shopping routes | 563,465 | 1,134.41 |
| Other recorded routes | 1,522,277 | 1,690.99 |

The other recorded routes settle 2,574,155,452 nodes, versus 994,526,524 across the two Shopping
categories. These counters establish work, not a corresponding CPU-time share. Shopping draws
143,544,987 candidates and uses 75.88 counter-defined index reads per draw. Population scaling is
still confounded with the larger network and changed traffic; none of these is an isolated exponent.

Ticks 14,626 / 14,635 / 14,640 allocate 73,109,304 / 116,490,512 / 716,767,040 bytes respectively:
97.90% of the measured Day's total. All three spend nearly all their time in Move and none is the
slowest Tick. The allocation-owning call sites still need attribution. Work records are in
`million-counted.jsonl`, with derived totals in `million-work-summary.json` under the artifact path
above. The counted run's GC counts differ from the untraced pair; use it for attribution rather than
as another clean timing replicate.

The million-Citizen baseline repeat measures mean 124.89 ms, p95 407.49 ms, p99 474.35 ms and
maximum 572.25 ms at Tick 14,608, with identical state, activity and allocation. Its peak resident
memory is 1,273,708,544 bytes, demonstrating variation even within one frozen build. The separate
`time -l` peak-memory-footprint readings are 1,517,537,368 / 1,516,800,016 / 1,514,096,680 bytes
for before / after / before-repeat. Thus the higher after-run residency is not accompanied by a
higher managed heap or peak footprint. These process-wide observations do not isolate GC or OS
costs inside the measured window.

### Second-seed timing discrepancy

All seed-1 captures preserve State Hash `FDD1DBA842295351`, activity and allocation, with no measured
GC. Under the same local diagnostic conditions, the untraced readings are:

| Order | Build | Mean ms | p95 ms | p99 ms | Maximum ms |
|---|---|---:|---:|---:|---:|
| initial pair | before | 8.73 | 19.80 | 24.85 | 41.92 |
| initial pair | after | 9.83 | 23.84 | 30.31 | 60.37 |
| reverse-order repeat | after | 9.47 | 22.03 | 27.35 | 39.09 |
| reverse-order repeat | before | 8.90 | 20.31 | 25.03 | 41.89 |

The first after run reports 21,482 process-wide involuntary context switches versus 3,056 before,
and ending resident memory falls to 107,855,872 bytes from 262,766,592 despite nearly identical
managed heaps. Its maximum is at Tick 14,845, outside the Layers pass; the repeat after maximum is
at Tick 14,591. These observations suggest disturbed capture conditions but do not prove the cause.
Both after means exceed their before controls. The results are retained, not discarded.

The counted seed-1 pair preserves every per-Tick route, shopping, activity and allocation counter.
Layers totals 111.70 → 78.19 ms over the Day and costs 21.18 → 14.23 ms at Tick 14,608. Move totals
19.54 → 19.31 s; counted mean is 9.68 → 9.55 ms. This confirms the isolated query benefit on both
seeds, but does not resolve the repeated untraced mean regression. Under step 4, the candidate is
backed out rather than treated as a generally successful optimization. The captures, frozen builds,
candidate source and patch remain under `/tmp/borough-layers-20260907` (`candidate-source/`).
The two floor-boundary assertions remain; the rejected work-reduction assertion stays with the
candidate source. The earlier row-prefix optimization is unchanged.

Final verification: 45 focused assertions pass, including save/reload, profiling and floor boundaries;
the trace-summary scope checks pass. The rebuilt Core SHA-256 is exactly the frozen before-build
`BEE2D200BC8871F4516463C5F77958A1B08EA61648C2BB5E236EEB5CBB3B8172`, so the retained simulation
is the one measured by the million-Citizen baseline and repeat. The full milestone suite was not run.

## Move, route reuse and capacity attribution — 2026-09-07

Release .NET 10.0.2, M4 Pro, one simulation thread, seed 0, `stress-shopping.toml`,
checkpoint Tick 12,288, warm to 14,336. The managed trace measures the next 2,048 Ticks;
the new counted run measures 4,096. Desktop activity, validation and captures overlap.
These are attribution runs: **none of their timings ratifies a budget or an optimization**.
The trace uses the frozen baseline Core and ends at the expected `FAE56437750E05C7`, with
end invariants passing.

`summarize-simulation-profile.py --scope move` recognizes the inlined Advance wrapper through
`AdvanceTravellers`, `ReleaseEnded` and `CloseTick`. Of 284,386.98 ms of sampled Step stack weight,
281,153.34 ms is recognized as Move. The mutually exclusive search categories are:

| Work | Sampled weight, ms |
|---|---:|
| Other recorded route searches | 131,005.20 |
| Recorded Shopping route searches | 38,052.31 |
| Shopping estimate searches | 20,393.42 |
| Non-search Move | 91,702.41 |

This is managed stack weight, not CPU utilization or isolated wall time. `WalkScratch.PopRoot`
has 38.13% of Step self weight; `Search` has 28.49% self and 66.62% inclusive, **including**
`PopRoot`. `BuildingResidency.NthIn`, `CommuteEngine.Generate` and `WorkSchedule.Accrue` follow
at 6.06%, 5.59% and 5.05% self. Inclusive rows must not be added together.

`RouteReuseProbe` observes only actual searches, keyed by graph identity/version, mode and both
full Addresses. It resets each Tick and holds at most 65,536 distinct keys per category; overflow
is reported, not treated as unique evidence. No overflow occurred. Over Tick 14,336–16,384:

| Category | Searches | Exact repeats within the same Tick |
|---|---:|---:|
| Other recorded | 1,522,277 | 230 |
| Recorded Shopping | 563,465 | 88,928 |
| Shopping estimates | 223,713 | 6,739 |

This is an opportunity count, not an implemented cache or a cross-Tick hit rate. It gives little
reason to prioritize an exact within-Tick cache for the dominant category.

`TableGrowthProbe` reads capacities after Step. It counts replacement-array payload from the
column declarations, including intrinsic columns and both buffers, and accounts for multiple
doublings. Array headers and alignment are excluded. The three bursts are `Rows.Grow` calling
`Column<T>.Grow` through these owners:

| Tick | Table | Capacity before → after | New array payload, bytes |
|---:|---|---:|---:|
| 14,626 | Trip | 338,465 → 676,930 | 37,908,080 |
| 14,626 | Traveller | 338,465 → 676,930 | 35,200,360 |
| 14,635 | Leg | 987,200 → 1,974,400 | 116,489,600 |
| 14,640 | Route Hop | 12,358,040 → 24,716,080 | 716,766,320 |

`TripEngine.Start` creates Trips, Legs and Travellers; `RecordRoute` appends Route Hops.
The following Day, Tick 16,384–18,432, has **no table growth**, but still allocates 19,423,280
bytes in the counted Steps. Two Days do not establish sustained memory behavior. The continuous
run comparison remains open; the new control also resumes the checkpoint. The probes add
33,264 bytes to the first Day's measured allocation versus the frozen control, outside the three
bursts. Their timings and GC counts are therefore diagnostic only.

**Implementation choice (prototype below):** bounded route workers. `WalkRouting.SpeedOn` and
`RoadArcs.TimeFor` read free-flow costs, so current traffic volume is not a search input.
That establishes a useful computation boundary, **not independence of Trip creation**:
`TripEngine.Itinerary`, `Start`, parking and result application retain ordering-sensitive state.
Prove request preparation and ordered consumption before dispatching workers; require 1/8-thread,
replay, save/reload and activity equivalence. Search leaves substantial non-search work, so idealized
search-only parallelism is not a promise to reach the existing Tick target. Moving serial Step off
the render thread separately needs a snapshot/command ownership boundary for the shell's world reads.

Verification: 30 focused profiling/routing assertions and the synthetic stack-boundary checks pass.
Across both measured Days, the counted run and frozen control have identical activity and finish
at Tick 18,432 with State Hash `0540B89003B50764` and passing end invariants. Every first-Day
route-work, Shopping-work and activity record matches the earlier counted fixture. Second-Day
Step allocation matches the control exactly. This is not a milestone/full-suite validation.

Durable evidence is under `artifacts/aged-city-performance/20260907/`: `checks.json` exposes the
comparisons; `move.json` exposes ranked self/inclusive attribution. The two archives preserve
commands, fingerprints, raw traces, work logs, builds and source, including the rejected noise
candidate. Both manifests carry archive and per-file SHA-256 checks, verified after writing.
The prior archive excludes only the reproducible Tick-12,288 save. The new evidence is also in
`/tmp/borough-move-20260907-retry` and `/tmp/borough-growth-20260907` while those directories survive.
Items 3–9 remain open; the two-Day observation does not close weekly patterns, older horizons,
functioning-economy controls, quiet-machine captures or Godot observation.

## Bounded commute route workers — 2026-09-07

`Simulation.RouteWorkerCount` selects 1–8 workers, default 1. `CommuteEngine.Flush` prepares a
fixed window of up to 128 requests; `RouteBatch` gives each worker its own `WalkScratch` and
stores copied Arc paths in reusable slots. Workers only read the stable Road Graph. The caller
joins them before `TripEngine.StartPrepared` applies results in original Citizen/Trip/Leg order.
Each commute source flushes separately. Small networks and short request windows stay serial.
These are host execution thresholds, not Ruleset choices or saved state.

Preparation does not reserve parking or create Trips. `StartPrepared` runs the usual qualification
and itinerary checks; consuming a result requires matching graph version, mode, full endpoint
Addresses and crossing cost. A mismatch searches synchronously. Thread completion order never
chooses mutation order. This covers commute searches only: Shopping, civic journeys and all world
writes remain serial, and `Step` still runs on its caller. A dedicated simulation thread for Godot
requires the separate snapshot/command ownership work described above.

`RouteWorkerTests` exercises actual Input Log replay with per-Tick 1/2/8-worker State Hash checks,
save/reload while changing worker count, real result consumption, reversed worker completion,
unchanged state during preparation, stale-input fallback and parking refusal. The initial stub
failed because no prepared routes were consumed. The focused routing/commute/profiling group
passes 44 assertions; the final Input Log version passes all seven route-worker cases.

The profile-only CLI flag is `--route-workers N`. Allocation measurement now uses process-wide
managed allocation deltas around Step, including workers. Synchronous route-work counters exclude
worker searches; `routeBatch` separately reports prepared, used and fallback results. Worker count
is a concurrency limit including the caller, not a promise that every worker stays occupied.

Comparisons use frozen Release builds, .NET 10.0.2 on M4 Pro, `stress-shopping.toml`, warm to
Tick 14,336 and measure 2,048 Ticks, Decide guard off. The million-Citizen runs resume Tick 12,288.
Captures run sequentially without overlapping builds/tests; the desktop remains open. These are
local diagnostics, not quiet-machine ratification of the one-core Tick budget.

### Scaling and costs

On that million-Citizen M4 Pro fixture, with worker limits including the caller:

| Route workers | Mean ms | p95 ms | p99 ms | Maximum ms | Step allocation, bytes | Gen 0/1/2 collections |
|---:|---:|---:|---:|---:|---:|---|
| 1 | 120.79 | 393.55 | 452.66 | 568.52 | 925,780,664 | 2 / 1 / 1 |
| 2 | 96.64 | 289.48 | 327.71 | 462.27 | 949,194,704 | 4 / 2 / 1 |
| 4 | 84.88 | 239.70 | 272.58 | 416.91 | 956,396,232 | 5 / 2 / 1 |
| 8 | 77.40 | 208.29 | 232.91 | 381.97 | 970,245,872 | 6 / 2 / 1 |

Every maximum is Tick 14,608. Every run preserves State Hash `FAE56437750E05C7`, all recorded
activity and end invariants. Each parallel run prepares and consumes 3,721,812 route queries with
no fallback; these include cheap routing shortcuts and must not be compared directly with the
earlier count of actual searches. Eight workers reduce measured mean by 35.92% and p99 by 48.55%,
with diminishing returns. This neither meets nor changes the existing one-core target.

The worker configuration adds 44,465,208 allocated bytes to the eight-worker Day and increases GC
frequency. Managed heap at the end is 1,667,805,656 / 1,674,973,440 / 1,674,062,136 / 1,680,046,048
bytes for 1/2/4/8 workers. Process-wide peak memory footprint is 1,519,192,080 / 1,522,305,064 /
1,527,269,464 / 1,525,762,040 bytes; peak residency varies independently and is preserved in the raw
resource readings. Scheduling and retained scratch have costs; the attributed table-growth bursts
remain. These captures do not establish long-run memory stability.

At 100,000 Citizens under the same desktop conditions, the revised 1/8-worker comparison is:

| Seed | Workers | Mean ms | p95 ms | p99 ms | Maximum ms | Step allocation, bytes |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 9.05 | 20.52 | 24.76 | 43.75 | 3,836,440 |
| 0 | 8 | 8.41 | 17.12 | 21.89 | 42.47 | 9,077,512 |
| 1 | 1 | 8.78 | 20.07 | 25.01 | 41.71 | 3,842,088 |
| 1 | 8 | 7.87 | 16.20 | 21.08 | 39.65 | 9,146,168 |

Seed 0 runs eight then one; seed 1 reverses the order. No measured GC occurs in these four runs.
State Hashes remain `D551BD2FA385894A` / `FDD1DBA842295351`, with identical activity. All prepared
results are consumed: 335,248 / 340,607 by seed. The original serial build also measures 8.64 ms
mean on seed 0, so the eight-worker benefit against that control is smaller than against the new
serial reading. The initial prototype's two-seed means and all subsequent controls are preserved.

### Small-city and serial controls

The first prototype made the 1,000-Citizen M4 Pro fixture worse: mean 0.02561 → 0.04246 ms for
1 → 8 workers. It dispatched work too small to amortize scheduling. That behavior is rejected;
`CommuteEngine.QueueTravel` now bypasses workers below its network threshold. Three revised pairs
measure means 0.02598–0.02635 ms at one worker and 0.02603–0.02636 ms at eight, with no prepared
queries and identical Step allocation of 2,166,224 bytes.

An older serial control initially measured 0.02313 ms mean and 0.4537 ms maximum, while the revised
serial build showed occasional maxima near 1.9 ms. This was investigated rather than discarded.
The unchanged original build repeats at 0.02563 ms mean and 1.9537 ms maximum. The old profiler
driving the new Core measures 0.02528 / 1.9151 ms. Counted original/hybrid/revised runs have identical
per-Tick route, Shopping and activity work; all reproduce the Layers spike at Tick 14,608. With
`DOTNET_TieredCompilation=0`, original/revised means are 0.03513 / 0.03496 ms, p95 0.0801 / 0.0799 ms
and p99 0.0899 / 0.0905 ms. Those controls support runtime/capture sensitivity rather than added
simulation work; they do not identify a particular JIT event. The original adverse observations
remain in the archive. All these small runs finish at `A4763BF6939AD36B` with passing invariants.

The 100,000-Citizen seed-0 serial repeat is original/revised 8.49446 / 8.63290 ms mean,
19.0886 / 19.3248 ms p95 and 23.6518 / 23.7335 ms p99. To separate the profiler changes from Core,
the old profiler then drives the new Core: 8.47991 ms mean, 19.0830 ms p95, 23.4655 ms p99 and
42.6198 ms maximum, with the same activity and 3,836,440 allocated bytes. This control supports
retaining the Core change; the apparent serial penalty does not reproduce with the old measurement
host. It does not identify which profiler/runtime interaction changed the reading. New-profiler
worker comparisons share that host, and all original controls remain available.

**Retained, opt-in:** bounded commute route workers. Default execution stays serial. The next
investigation is the continuous/resumed capacity comparison; broader routing work, weekly/older
horizons, fixed-network controls, functioning-system fixtures, quiet captures and shell observation
remain open. Moving Step to its own thread remains a separate shell change.

Durable evidence: `artifacts/aged-city-performance/20260907/route-worker-comparisons.json` carries
activity/hash comparisons and raw measurement summaries. `route-worker-evidence.tar.gz` preserves
commands, frozen original/prototype/revised/hybrid builds, source, resource readings, rejected small
dispatch behavior and serial controls. `route-worker-manifest.json` verifies archive and per-file
SHA-256. The reproducible million-Citizen checkpoint remains excluded. The as-measured and final
source snapshots distinguish later comment edits and the strengthened save/reload assertion.

Final validation: `scripts/test.sh` collects 2,946 assertions: 2,943 pass and three fail. Two explicit
fixture allow-lists omitted `stress-shopping.toml`; they now name it while retaining the exact
lattice-count and District checks. The strengthened save/reload test initially finds no worker use
in its short post-load interval; a full-Day interval now requires actual consumption before and
after saving, alongside every-Tick hash equality and worker-count changes. All three pass the
focused rerun. Core logic is unchanged from the measured build; subsequent Core edits are comments.
Both runs and the initial failing prototype tests are archived. This is assertion-lane validation,
not an unfiltered milestone suite or a quiet-machine capture.
