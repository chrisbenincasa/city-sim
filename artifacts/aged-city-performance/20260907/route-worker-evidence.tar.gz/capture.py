from pathlib import Path
import subprocess,json,hashlib,sys
root=Path(__file__).parent
cases=[('small-before', 'before', 1000,0,None),('small-serial','prototype',1000,0,1),('small-eight','prototype',1000,0,8),('hundred-before','before',100000,0,None),('hundred-serial','prototype',100000,0,1),('hundred-eight','prototype',100000,0,8),('hundred-seed1-eight','prototype',100000,1,8),('hundred-seed1-serial','prototype',100000,1,1)]
if len(sys.argv)>1 and sys.argv[1]=='million':
    cases=[('million-'+str(n),'prototype',1000000,0,n) for n in (1,2,4,8)]
if len(sys.argv)>1 and sys.argv[1]=='final':
    cases=[(f'final-small-{n}-{repeat}','final',1000,0,n) for repeat in range(3) for n in (1,8)]
    cases += [('final-hundred-eight','final',100000,0,8),('final-hundred-serial','final',100000,0,1),('final-hundred-before','before',100000,0,None),('final-seed1-serial','final',100000,1,1),('final-seed1-eight','final',100000,1,8)]
    cases += [('final-million-'+str(n),'final',1000000,0,n) for n in (1,2,4,8)]
for name,build,pop,seed,workers in cases:
    binary=root/build/'Borough.Headless.dll'
    cmd=['dotnet',str(binary),'--profile','--ruleset','rulesets/stress-shopping.toml','--citizens',str(pop),'--seed',str(seed),'--warmup-ticks','14336','--ticks','2048','--no-decide-guard']
    if workers is not None:cmd+=['--route-workers',str(workers)]
    if pop==1000000:cmd+=['--profile-load','/tmp/borough-layers-20260907/million-day6.save']
    (root/(name+'-command.json')).write_text(json.dumps({'command':cmd,'conditions':'Sequential Release captures on M4 Pro, desktop open; no overlapping builds/tests/captures. Local diagnostic, not quiet-machine budget ratification.','assemblies':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.parent.glob('Borough.*.dll')}},indent=2))
    print('START',name,flush=True)
    with (root/(name+'.jsonl')).open('x') as out,(root/(name+'-resources.txt')).open('x') as err:
        result=subprocess.run(['/usr/bin/time','-l',*cmd],stdout=out,stderr=err)
    if result.returncode:raise RuntimeError(f'{name} failed: {result.returncode}')
    records=[json.loads(s) for s in (root/(name+'.jsonl')).read_text().splitlines()]
    expected={(1000,0):'A4763BF6939AD36B',(100000,0):'D551BD2FA385894A',(100000,1):'FDD1DBA842295351',(1000000,0):'FAE56437750E05C7'}
    assert records[-1]==dict(type='end',tick=16384,hash=expected[(pop,seed)],invariants='passed'), name
    print('DONE',name,json.dumps(records[-2]),json.dumps(records[-1]),flush=True)
