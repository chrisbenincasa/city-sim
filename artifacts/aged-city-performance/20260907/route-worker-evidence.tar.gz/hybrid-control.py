from pathlib import Path
import subprocess,json,hashlib,os
root=Path(__file__).parent
cases=[('hundred-hybrid','hybrid',100000,None,None)]
for name,build,pop,workers,work in cases:
 binary=root/build/'Borough.Headless.dll'
 cmd=['dotnet',str(binary),'--profile','--ruleset','rulesets/stress-shopping.toml','--citizens',str(pop),'--seed','0','--warmup-ticks','14336','--ticks','2048','--no-decide-guard']
 if workers is not None:cmd+=['--route-workers',str(workers)]
 env=os.environ.copy()
 if work is True:cmd+=['--profile-work']
 if work is False:env['DOTNET_TieredCompilation']='0'
 (root/(name+'-command.json')).write_text(json.dumps({'command':cmd,'environmentOverrides':{'DOTNET_TieredCompilation':'0'} if work is False else {},'conditions':'Sequential Release M4 Pro desktop diagnostic; no overlapping tests/builds/captures.','assemblies':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.parent.glob('Borough.*.dll')}},indent=2))
 print('START',name,flush=True)
 with (root/(name+'.jsonl')).open('x') as out,(root/(name+'-resources.txt')).open('x') as err:
  result=subprocess.run(['/usr/bin/time','-l',*cmd],stdout=out,stderr=err,env=env)
 if result.returncode:raise RuntimeError((name,result.returncode))
 records=[json.loads(s) for s in (root/(name+'.jsonl')).read_text().splitlines()]
 assert records[-1]['hash']=={1000:'A4763BF6939AD36B',100000:'D551BD2FA385894A'}[pop]
 print('DONE',name,json.dumps(records[-2]),flush=True)
