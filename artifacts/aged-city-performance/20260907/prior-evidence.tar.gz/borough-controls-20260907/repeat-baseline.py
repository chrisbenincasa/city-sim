import json,subprocess,time
from pathlib import Path
out=Path(__file__).parent
last=out/'small-after.jsonl'
while not last.exists() or '"type":"end"' not in last.read_text():time.sleep(1)
m=json.loads((out/'capture.json').read_text());cmd=m['commands']['baseline-seed0']
with (out/'baseline-seed0-repeat.jsonl').open('w') as log,(out/'baseline-seed0-repeat.err').open('w') as err:subprocess.run(cmd,stdout=log,stderr=err,check=True)
print('Replacement seed-0 baseline complete.',flush=True)
