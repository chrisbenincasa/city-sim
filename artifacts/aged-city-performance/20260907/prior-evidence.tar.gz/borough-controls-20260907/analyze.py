import json,importlib.util
from pathlib import Path
out=Path(__file__).parent
spec=importlib.util.spec_from_file_location('summary','scripts/summarize-work-profile.py');summary=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary)
def read(name):
 records=[json.loads(line) for line in (out/(name+'.jsonl')).read_text().splitlines()]
 assert records[-1].get('type')=='end' and records[-1].get('invariants')=='passed'
 return next(r for r in records if 'MeanMs' in r),records[-1]
result={}
for label,before,after in [('seed0','baseline-seed0-repeat','optimized-seed0'),('seed1','baseline-seed1','optimized-seed1'),('small','small-before','small-after')]:
 if not (out/(before+'.jsonl')).exists() or not (out/(after+'.jsonl')).exists():continue
 try:a,ae=read(before);b,be=read(after)
 except AssertionError:continue
 differences={k:[a[k],b[k]] for k in a if k not in ('MeanMs','P95Ms','P99Ms','MaxMs','MaxTick') and a[k]!=b[k]}
 assert not differences and ae==be,(label,differences,ae,be)
 result[label]={'before':a,'after':b,'activityAndAllocationsMatch':True,'hash':ae['hash'],'meanReductionPercent':100*(a['MeanMs']-b['MeanMs'])/a['MeanMs']}
for name in ['network10k-pop10k','network100k-pop10k','network100k-pop100k','no-delay','optimized-counted']:
 p=out/(name+'.jsonl')
 if not p.exists():continue
 try:s=summary.summarize(p)
 except ValueError:continue
 (out/(name+'-summary.json')).write_text(json.dumps(s,indent=2))
if (out/'optimized-counted-summary.json').exists():
 a=json.loads((out/'network100k-pop100k-summary.json').read_text());b=json.loads((out/'optimized-counted-summary.json').read_text())
 for name in a['counters']:
  if name.startswith('shoppingWork.Selection.') or name=='ms':continue
  assert a['counters'][name]['total']==b['counters'][name]['total'],name
 arows={r['tick']:r for r in map(json.loads,(out/'network100k-pop100k.jsonl').read_text().splitlines()) if r.get('type')=='work'}
 brows={r['tick']:r for r in map(json.loads,(out/'optimized-counted.jsonl').read_text().splitlines()) if r.get('type')=='work'}
 for tick in arows:
  x,y=arows[tick],brows[tick]
  for field in ['shopping','shoppingRoutes','otherRoutes','travellers','vehicles','allocated']:
   assert x[field]==y[field],(tick,field)
  for field in ['Considered','Starts','NoKnownShop','Unreachable','Estimates']:
   assert x['shoppingWork'][field]==y['shoppingWork'][field],(tick,field)
  for field in ['CountCalls','CandidateCalls','CandidateLinks']:
   assert x['shoppingWork']['Selection'][field]==y['shoppingWork']['Selection'][field],(tick,field)
 result['work']={'perTickWorkMatches':True,'before':a['perRequest']['selection'],'after':b['perRequest']['selection'],
  'spike':brows[14608], 'neighbours':[brows[14607],brows[14609]]}
(out/'comparisons.json').write_text(json.dumps(result,indent=2))
for label,r in result.items():
 if label!='work':print(label,r['meanReductionPercent'],r['hash'])
 else: print('selection',r['before'],r['after']);print('phase at spike',r['spike']['phaseMs'])
