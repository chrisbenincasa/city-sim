import json,time,subprocess,hashlib
from pathlib import Path
out=Path(__file__).parent
last=out/'baseline-seed1.jsonl'
while not last.exists() or '"type":"end"' not in last.read_text():time.sleep(1)
manifest={'assemblySha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'optimized').glob('Borough.*.dll')},'commands':{}}
cases=[('optimized-seed1','optimized',100000,1,False),('optimized-seed0','optimized',100000,0,False),('optimized-counted','optimized',100000,0,True),('small-before','baseline',1000,0,False),('small-after','optimized',1000,0,False)]
for name,build,size,seed,counted in cases:
 cmd=['dotnet',str(out/build/'Borough.Headless.dll'),'--profile','--ruleset','rulesets/stress-shopping.toml','--citizens',str(size),'--seed',str(seed),'--warmup-ticks','14336','--ticks','2048','--no-decide-guard']
 if counted:cmd+=['--profile-work']
 manifest['commands'][name]=cmd;(out/'optimization.json').write_text(json.dumps(manifest,indent=2))
 with (out/(name+'.jsonl')).open('w') as log,(out/(name+'.err')).open('w') as err:subprocess.run(cmd,stdout=log,stderr=err,check=True)
 print(name+' complete',flush=True)
