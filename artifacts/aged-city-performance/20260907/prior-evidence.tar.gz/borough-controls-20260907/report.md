## Controlled fixtures and candidate-selection change — 2026-09-07

`--profile-population` separates the initial population from `--citizens`, which retains its network
and table sizing. `SyntheticCity.PeopleInto` accepts the smaller population; the default path is
unchanged. Conditions now include a fingerprint of node coordinates, Segment endpoints, modes,
lengths, speeds and capacities. This verifies the fixed network, rather than inferring it from a flag.

The controlled runs retain seed 0, the original Ruleset and the 14,336 + 2,048 Tick horizon. At
10,000 Citizens, increasing the network from 453 nodes / 758 Segments to 2,829 nodes / 5,514 Segments
increased settled nodes per shopping estimate from 42.83 to 68.11. Candidate calls were nearly
unchanged (683,200 / 680,935), but Cells inspected per candidate rose from 324.82 to 1,083.58.
At 100,000 Citizens on the identical larger network, those readings were 402.80 nodes per estimate,
10,289,995 candidate calls and 1,112.09 Cells per candidate. More Citizens also change occupied
geography and journey distributions; the fixed network alone does not hold those constant.

A separate copy changes only traffic `alpha_percent` from 15 to 0. On the identical 100,000-Citizen
network, peak Travellers fell from 42,763 to 11,443, while completed Trips rose from 416,610 to
575,887 and recorded Shopping searches from 356,608 to 706,254. Over-budget outcomes rose from
0 to 2,533, with no no-route outcomes in either run; purchases were 2,448 / 2,463. Faster journeys
permit more work, so active movement population alone does not predict cost. The over-budget
outcomes have not been attributed to a specific refusal path.

The first optimization targets the spatial cost these controls isolate. `BuildingResidency.PrefixRow`
builds row prefixes lazily; `Add`, `Remove` and `Rebuild` invalidate them. `CountIn` sums row ranges,
and `NthIn` skips whole rows and finds the selected Cell by binary search. Cell order and the
intrusive Building list order remain unchanged. Storage is bounded by the map dimensions. Work
records distinguish prefix reads and Cells read during rebuilding from the old linear Cell scans.

The shopping-boundary regression first failed with 8,620,049 index reads for 28,937 draws, then
passed after the change. Ordinal queries are checked against enumeration after warm reads,
demolition, slot reuse and rebuilding. Save/reload and derived-state assertions are included.
`--profile-work` now also records phase durations through `Simulation.PhaseCompleted`; the clock
remains in the host. These instrumented durations exclude Advance/save after Commit and carry
observer overhead; they are diagnostic, not replacements for untraced Step timings.

### Verification and remaining tail

The controlled artifacts, frozen baseline/optimized binaries, assembly fingerprints, commands and
comparison checks are in `/tmp/borough-controls-20260907`. All timing comparisons here are Release
on the M4 Pro, one simulation thread, with the desktop open; they are local diagnostics, not budget
ratification. The no-delay counted run overlapped validation during ageing. The first seed-0
baseline was accidentally paused inside its measurement window; its timing is discarded and the
`baseline-seed0-repeat` capture is the replacement. Exceptions are retained with the artifacts.

The counted comparison preserves candidate calls and links, every route-work counter, per-Tick
shopping activity, Travellers, Vehicles and allocation. Logical index work per candidate falls from
1,210.94 to 48.81, including the associated count queries and prefix rebuilding: a 95.97% reduction.
These are counter-defined lookups, not hardware memory transactions. The prefix array adds roughly
one MiB per world at the current map dimensions; measured Step allocation is unchanged.

At Tick 14,608 in the optimized counted run, Move costs 23.84 ms and Layers 19.08 ms. The preceding
and following Ticks spend 23.69 ms in Move and effectively no time in Layers. Thus the additional
spike is isolated to Layers, not inferred from the cadence alone. The specific consumer inside that
phase is still unmeasured; this does not establish that all 19.08 ms belongs to one method.

The Release build and 57 focused assertions pass, including the shopping-boundary regression,
ordinal maintenance, save/reload and the derived-state audit. The full milestone suite was not run.

Retained after untraced comparisons on identical Inputs at 100,000 Citizens. Timing units below are
milliseconds per Tick under the machine, thread count and desktop conditions stated above.

| Seed | Build | Mean | p95 | p99 | Maximum |
|---:|---|---:|---:|---:|---:|
| 0 | before | 11.78 | 24.19 | 30.09 | 49.00 |
| 0 | after | 8.59 | 19.50 | 23.69 | 43.04 |
| 1 | before | 12.12 | 24.64 | 30.79 | 54.64 |
| 1 | after | 8.93 | 20.38 | 25.05 | 41.82 |

Mean Step cost fell 27.01% on seed 0 and 26.29% on seed 1. Every daily activity and allocation
counter matched; State Hashes remained `D551BD2FA385894A` and `FDD1DBA842295351`, respectively.
At 1,000 Citizens on seed 0, mean cost fell from 0.03170 to 0.02616 ms, with p95/p99/max also lower
and State Hash `A4763BF6939AD36B` unchanged. This is an observed small-fixture improvement, not a
claim that the prefix is cheaper for every possible query distribution.

The broader care/school/economy fixtures, older horizon and Godot observation in step 5 remain
outstanding. These results establish a benefit on the measured stress workload, not city capacity.
