import json,subprocess,hashlib
from pathlib import Path
out=Path(__file__).parent
binary=out/'baseline/Borough.Headless.dll'
cases=[('network10k-pop10k',10000,None,0,False,True),('network100k-pop10k',100000,10000,0,False,True),('network100k-pop100k',100000,None,0,False,True),('no-delay',100000,None,0,True,True),('baseline-seed0',100000,None,0,False,False),('baseline-seed1',100000,None,1,False,False)]
manifest={'conditions':'Release, M4 Pro, one simulation thread; desktop open; no concurrent build or simulation; diagnostic timings', 'assemblySha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.parent.glob('Borough.*.dll')}, 'commands':{}}
for name,size,pop,seed,no_delay,counted in cases:
 cmd=['dotnet',str(binary),'--profile','--ruleset',str(out/'no-delay.toml') if no_delay else 'rulesets/stress-shopping.toml','--citizens',str(size),'--seed',str(seed),'--warmup-ticks','14336','--ticks','2048','--no-decide-guard']
 if pop:cmd+=['--profile-population',str(pop)]
 if counted:cmd+=['--profile-work']
 manifest['commands'][name]=cmd
 (out/'capture.json').write_text(json.dumps(manifest,indent=2))
 with (out/(name+'.jsonl')).open('w') as log,(out/(name+'.err')).open('w') as err:subprocess.run(cmd,stdout=log,stderr=err,check=True)
 print(name+' complete',flush=True)
