# First aged-city attribution capture

M4 Pro, Release .NET 10.0.2, one simulation thread, stress-shopping.toml, seed 0, 100,000 Citizens. Age to Tick 14336, capture 2048 Ticks. The editor remained open at low load; these are local diagnostics, not a quiet-machine budget ratification.

**Finding:** walking-route search/heap work and spatial Building selection lead the sampled simulation work. Shopping is their main caller. This is not yet proof of redundant work or of a particular algorithm’s asymptotic complexity.

| Function | Managed leaf share | Inclusive share |
|---|---:|---:|
| Borough.Core.Movement.WalkScratch.PopRoot | 23.05% | 23.05% |
| Borough.Core.Movement.WalkScratch.Search | 20.79% | 43.84% |
| Borough.Core.Space.BuildingResidency.NthIn | 19.37% | 19.37% |
| Borough.Core.Movement.CommuteEngine.Generate | 5.82% | 18.88% |
| Borough.Core.Movement.WorkSchedule.Accrue | 4.38% | 7.42% |
| Borough.Core.Movement.TripEngine.AdvanceTravellers | 3.67% | 5.52% |
| Borough.Core.Movement.TripEngine.ReleaseEnded | 3.29% | 3.29% |
| Borough.Core.Movement.WorkSchedule.OnDuty | 3.09% | 3.09% |
| Borough.Core.Parking.ParkingShed.Expand | 2.20% | 2.44% |
| Borough.Core.Space.BuildingResidency.CountIn | 2.10% | 2.10% |
| 1>,int32) | 1.73% | 2.89% |
| Borough.Core.Rules.ShoppingEngine.Step | 1.70% | 63.03% |

Routing: 73.9% of route-search stack weight comes through shopping; the remainder through commuting. 98.5% of Building-selection stack weight comes through shopping.

ShoppingEngine.Step contains 63.03% of total filtered stack weight. Its child costs overlap that figure and must not be added to it. These are managed stack weights, not CPU utilization. Native time without native symbols is attributed to its managed caller. The analysis excludes the ending timestamp, attach wait, reporting and final invariants. Tiering may inline lower-level functions, so leaf attribution depends on the generated code.

## Control

| Reading | Untraced | Traced |
|---|---:|---:|
| MeanMs | 10.657 | 10.965 |
| P95Ms | 22.417 | 23.013 |
| P99Ms | 27.222 | 28.297 |
| MaxMs | 46.281 | 48.152 |

Timing units are milliseconds per Tick. The observed tracing overhead is why attributed captures do not replace the untraced timing baseline. Both runs identify Tick 14608 as their slowest; the daily trace does not yet attribute that specific Tick separately.

All activity/allocation counters and final State Hash `D551BD2FA385894A` match. Both completed end invariants. The Decide-write guard was off to match the game; staggered invariants remained active.

## Next probe

Count shopping estimate/start/recorded-route requests, graph nodes relaxed/popped, candidate-selection calls and Cells scanned. Associate these with expensive Ticks. Compare request repetition against work per request before proposing caching or a spatial-index change.

## Artifacts

- [Filtered method report](step.txt)
- [Filtered method data](step.json)
- [Traced/untraced comparison](comparison.json)
- [Trace for Speedscope](simulation.speedscope.json)
- [Original .NET trace](simulation.nettrace)
- [Capture commands and tool version](capture.json)
- [Assembly fingerprints](assemblies.json)
- [Traced run](run.jsonl)
- [Untraced run](untraced.jsonl)

The two smoke captures and aborted captures in neighbouring temporary directories are harness validation/debug artifacts, not performance evidence.

Profiler semantics: [Microsoft dotnet-trace documentation](https://learn.microsoft.com/en-us/dotnet/core/diagnostics/dotnet-trace) distinguishes managed thread-stack sampling from on-CPU sampling.
