import subprocess,json,time
from pathlib import Path
out=Path(__file__).parent
while 'Finished million-before-repeat' not in (out/'memory-repeat-progress.log').read_text():time.sleep(10)
for build in ['after','before']:
    name='hundred-seed1-'+build+'-repeat'
    cmd=json.loads((out/('hundred-seed1-'+build+'-command.json')).read_text())
    (out/(name+'-command.json')).write_text(json.dumps({'command':cmd,'purpose':'Reverse-order repeat after seed-1 outlier with increased context switches and resident-memory drop'},indent=2))
    print('Starting '+name,flush=True)
    with (out/(name+'.jsonl')).open('w') as log,(out/(name+'-resource.log')).open('w') as err:
        subprocess.run(['/usr/bin/time','-l',*cmd],stdout=log,stderr=err,check=True)
    print('Finished '+name,flush=True)
