import subprocess,json,hashlib
from pathlib import Path
out=Path(__file__).parent
binary=out/'before/Borough.Headless.dll'
cmd=['python3','scripts/profile-simulation.py','--trace-tool','/tmp/borough-profiler/dotnet-trace','--binary',str(binary),'--output',str(out/'trace')]
subprocess.run(cmd,check=True)
cmd=['dotnet',str(binary),'--profile','--ruleset','rulesets/stress-shopping.toml','--citizens','1000000','--seed','0','--warmup-ticks','0','--ticks','12288','--no-decide-guard','--profile-save',str(out/'million-day6.save')]
(out/'staging-command.json').write_text(json.dumps({'command':cmd,'purpose':'Age to a reusable checkpoint; daily intermediate timings are diagnostic, not controlled comparison windows','assemblies':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.parent.glob('Borough.*.dll')}},indent=2))
with (out/'million-staging.jsonl').open('w') as log,(out/'million-staging-resource.log').open('w') as err:subprocess.run(['/usr/bin/time','-l',*cmd],stdout=log,stderr=err,check=True)
print('Million-Citizen Day-6 checkpoint ready.',flush=True)
