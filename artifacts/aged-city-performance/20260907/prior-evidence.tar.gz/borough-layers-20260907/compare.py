import json
from pathlib import Path
out=Path(__file__).parent
variable={'MeanMs','P95Ms','P99Ms','MaxMs','MaxTick','Gen0Collections','Gen1Collections','Gen2Collections','ManagedHeapBytes','WorkingSetBytes'}
def read(path):
    rows=[json.loads(s) for s in path.read_text().splitlines()]
    assert rows[-1].get('invariants')=='passed',path
    return rows
results={}
for label in ['million','hundred','hundred-seed1']:
    paths=[out/(label+'-'+b+'.jsonl') for b in ['before','after']]
    if not all(p.exists() and '"type":"end"' in p.read_text() for p in paths):continue
    a,b=map(read,paths)
    x=next(r for r in a if 'MeanMs' in r);y=next(r for r in b if 'MeanMs' in r)
    assert a[-1]==b[-1],(label,a[-1],b[-1])
    assert a[0]['network']==b[0]['network'],label
    assert {k:v for k,v in x.items() if k not in variable}=={k:v for k,v in y.items() if k not in variable},label
    results[label]={'before':x,'after':y,'end':a[-1],'meanImprovementPercent':100*(1-y['MeanMs']/x['MeanMs'])}
for label in ['million','hundred']:
    path=out/(label+'-counted.jsonl')
    if not path.exists() or '"type":"end"' not in path.read_text():continue
    data=read(path);work=[r for r in data if r.get('type')=='work']
    assert len(work)==2048
    if label in results:
        assert data[-1]==results[label]['end']
        s=next(r for r in data if 'MeanMs' in r)
        assert {k:v for k,v in s.items() if k not in variable}=={k:v for k,v in results[label]['after'].items() if k not in variable}
    result={'phaseTotalMs':{phase:sum(r['phaseMs'][phase] for r in work) for phase in work[0]['phaseMs']},
            'lineSources':{key:sum(r['lineSources'][key] for r in work) for key in work[0]['lineSources']},
            'tick14608':next(r for r in work if r['tick']==14608)}
    if label=='hundred':
        previous=read(Path('/tmp/borough-controls-20260907/optimized-counted.jsonl'))
        old=[r for r in previous if r.get('type')=='work']
        drop={'ms','phaseMs','lineSources'}
        assert [{k:v for k,v in r.items() if k not in drop} for r in old]==[{k:v for k,v in r.items() if k not in drop} for r in work]
        result['previousLayersTotalMs']=sum(r['phaseMs']['Layers'] for r in old)
        result['previousTick14608']=next(r for r in old if r['tick']==14608)
    results[label+'-work']=result
(out/'comparisons.json').write_text(json.dumps(results,indent=2)+'\n')
for label,r in results.items():
    if 'before' in r:
        print(label,r['meanImprovementPercent'],r['end'])
        for b in ['before','after']:print(b,{k:r[b][k] for k in ['MeanMs','P95Ms','P99Ms','MaxMs','AllocatedBytes','PeakTravellers','Purchases','ManagedHeapBytes','WorkingSetBytes']})
    else:print(label,r['phaseTotalMs'],r['lineSources'])
