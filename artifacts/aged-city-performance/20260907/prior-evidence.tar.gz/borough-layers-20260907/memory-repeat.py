import subprocess,json,time
from pathlib import Path
out=Path(__file__).parent
while 'Finished hundred-seed1-after' not in (out/'second-seed-progress.log').read_text():time.sleep(10)
cmd=json.loads((out/'million-before-command.json').read_text())['command']
(out/'million-before-repeat-command.json').write_text(json.dumps({'command':cmd,'purpose':'Check process-memory and run-order variation after the original before/after pair'},indent=2))
print('Starting million-before-repeat',flush=True)
with (out/'million-before-repeat.jsonl').open('w') as log,(out/'million-before-repeat-resource.log').open('w') as err:
    subprocess.run(['/usr/bin/time','-l',*cmd],stdout=log,stderr=err,check=True)
print('Finished million-before-repeat',flush=True)
