namespace Borough.Core.Space;

public sealed class LineSourceWork
{
    public long Queries { get; set; }
    public long Distances { get; set; }
    public long SquareRoots { get; set; }
    public void Reset() { Queries = Distances = SquareRoots = 0; }
}
