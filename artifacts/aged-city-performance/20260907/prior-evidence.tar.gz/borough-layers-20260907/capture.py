import subprocess,json,time,hashlib
from pathlib import Path
out=Path(__file__).parent
stage=out/'million-staging.jsonl'
while '"type":"end"' not in stage.read_text(): time.sleep(10)
print('Staging complete; starting sequential controlled captures.',flush=True)
def run(name,build,pop,work=False,save=False):
    binary=out/build/'Borough.Headless.dll'
    cmd=['dotnet',str(binary),'--profile','--ruleset','rulesets/stress-shopping.toml','--citizens',str(pop),'--seed','0','--warmup-ticks','14336','--ticks','2048','--no-decide-guard']
    if pop==1000000: cmd+=['--profile-load',str(out/'million-day6.save')]
    if work:cmd+=['--profile-work']
    if save:cmd+=['--profile-save',str(out/'hundred-day8.save')]
    (out/(name+'-command.json')).write_text(json.dumps({'command':cmd,'assemblies':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.parent.glob('Borough.*.dll')}},indent=2))
    print('Starting '+name,flush=True)
    with (out/(name+'.jsonl')).open('w') as log,(out/(name+'-resource.log')).open('w') as err:
        subprocess.run(['/usr/bin/time','-l',*cmd],stdout=log,stderr=err,check=True)
    print('Finished '+name,flush=True)
run('million-before','before',1000000)
run('million-after','after',1000000)
run('hundred-before','before',100000)
run('hundred-after','after',100000)
run('hundred-counted','after',100000,True)
run('million-counted','after',1000000,True)
print('All captures complete.',flush=True)
