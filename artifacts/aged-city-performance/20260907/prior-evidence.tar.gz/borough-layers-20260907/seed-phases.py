import subprocess,json
from pathlib import Path
out=Path(__file__).parent
for build in ['before','after']:
    name='hundred-seed1-'+build+'-counted'
    cmd=json.loads((out/('hundred-seed1-'+build+'-command.json')).read_text())+['--profile-work']
    (out/(name+'-command.json')).write_text(json.dumps(cmd,indent=2))
    print('Starting '+name,flush=True)
    with (out/(name+'.jsonl')).open('w') as log,(out/(name+'-resource.log')).open('w') as err:
        subprocess.run(['/usr/bin/time','-l',*cmd],stdout=log,stderr=err,check=True)
    print('Finished '+name,flush=True)
