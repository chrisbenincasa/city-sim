import subprocess,json,time
from pathlib import Path
out=Path(__file__).parent
while 'All captures complete.' not in (out/'capture-progress.log').read_text(): time.sleep(10)
for build in ['before','after']:
    name='hundred-seed1-'+build
    cmd=['dotnet',str(out/build/'Borough.Headless.dll'),'--profile','--ruleset','rulesets/stress-shopping.toml','--citizens','100000','--seed','1','--warmup-ticks','14336','--ticks','2048','--no-decide-guard']
    (out/(name+'-command.json')).write_text(json.dumps(cmd,indent=2))
    print('Starting '+name,flush=True)
    with (out/(name+'.jsonl')).open('w') as log,(out/(name+'-resource.log')).open('w') as err:
        subprocess.run(['/usr/bin/time','-l',*cmd],stdout=log,stderr=err,check=True)
    print('Finished '+name,flush=True)
