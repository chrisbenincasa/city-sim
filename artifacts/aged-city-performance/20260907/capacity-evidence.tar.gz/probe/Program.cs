using System.Text.Json;
using System.Security.Cryptography;
using Borough.Core;
using Borough.Core.Entities;
using Borough.Core.Determinism;
using Borough.Core.Quantities;
using Borough.Core.Persistence;
using Borough.Formats;
using Borough.Headless;

string mode = args[0], checkpoint = args[1];
int population = int.Parse(args[2]), seed = int.Parse(args[3]), workers = int.Parse(args[4]);
int days = int.Parse(args[5]); bool work = args.Length > 6 && args[6] == "work";
const string rulesPath = "rulesets/stress-shopping.toml";
var loaded = RulesetLoader.Load(rulesPath);
if (!loaded.Ok) throw new Exception(loaded.Describe());
var key = WorldKey.FromSeed((ulong)seed);
World world;
if (mode == "resumed")
{
    using var stream = File.OpenRead(checkpoint);
    world = SaveFile.Read(new StreamSave(stream), loaded.Ruleset!, out var header);
    if (header.Key != key || header.RulesetInForce != RulesetFile.HashOf(rulesPath)) throw new Exception("Wrong checkpoint");
}
else
{
    world = new World(population, loaded.Ruleset!, key);
    SyntheticCity.PopulateInto(world, key, Ticks.Zero);
}
var sim = new Simulation(world, key) { RouteWorkerCount = workers, VerifyDecideWritesNothing = false };
Write(new { type = "conditions", mode, population, seed, workers, days, work, checkpoint,
    runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    coreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(World).Assembly.Location))),
    rulesetSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(rulesPath))) });
if (mode == "resumed") Storage("loaded");
while (world.Tick.Raw < 14336)
{
    sim.Step(default);
    if (world.Tick.Raw % Ticks.PerDay == 0) Storage("warmup");
    if (mode == "continuous" && world.Tick.Raw == 12288)
    {
        using var stream = new FileStream(checkpoint, FileMode.CreateNew, FileAccess.Write);
        SaveFile.Write(world, RulesetFile.HashOf(rulesPath), new StreamSave(stream));
    }
}
sim.Trips.Drain(); sim.Rules.Drain();
Storage("measure-start");
for (int day = 0; day < days; day++)
{
    Write(ProfileDump.Measure(sim, (int)Ticks.PerDay, work ? Console.Out : null));
    Storage("measure-end");
}
sim.CheckEndOfRun();
Write(new { type = "end", tick = world.Tick.Raw, hash = world.HashState().ToString("X16"), invariants = "passed" });
void Storage(string stage)
{
    var tables = new List<object>();
    foreach (var table in world.Tables)
    {
        long width = 0;
        foreach (var column in table.Columns) width += column.BytesPerRow;
        if (table.Buffering == Borough.Core.Tables.Buffering.TwoCopies) width *= 2;
        tables.Add(new { table.Name, table.SlotCount, table.LiveCount, table.Capacity, payloadBytes = width * table.Capacity });
    }
    Write(new { type = "storage", stage, tick = world.Tick.Raw, hash = world.HashState().ToString("X16"), tables });
}
static void Write(object value) { Console.WriteLine(JsonSerializer.Serialize(value)); Console.Out.Flush(); }
sealed class StreamSave(Stream stream) : ISaveSink, ISaveSource
{
    public void Write(ReadOnlySpan<byte> bytes) => stream.Write(bytes);
    public void Read(Span<byte> into) => stream.ReadExactly(into);
}
