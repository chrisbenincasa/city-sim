from pathlib import Path
import hashlib,json,tarfile,shutil
r=Path(__file__).parent
out=Path('artifacts/aged-city-performance/20260907')
archive=out/'capacity-evidence.tar.gz'
files=sorted(p for p in r.rglob('*') if p.is_file() and p.suffix!='.save' and not any(x in ('obj','bin','__pycache__') for x in p.parts))
entries=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=p.relative_to(r),recursive=False)
manifest={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':entries,'excluded':'Reproducible checkpoints; see checkpoint-fingerprints.json in archive.'}
(out/'capacity-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 for e in entries:
  blob=tar.extractfile(e['path']).read();assert len(blob)==e['bytes'] and hashlib.sha256(blob).hexdigest()==e['sha256'],e['path']
shutil.copy2(r/'comparisons.json',out/'capacity-comparisons.json')
print('Verified',len(entries),'files;',archive.stat().st_size,'archive bytes')
