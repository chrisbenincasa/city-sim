from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent
cases=[('small-resumed-after','after','resumed',r/'small.save',1000,0,True)]
for seed in (0,1):
 checkpoint=r/f'hundred-{seed}.save'
 cases.extend([(f'hundred-{seed}-continuous','before','continuous',checkpoint,100000,seed,True),(f'hundred-{seed}-resumed-before','before','resumed',checkpoint,100000,seed,True),(f'hundred-{seed}-resumed-after','after','resumed',checkpoint,100000,seed,True)])
checkpoint=Path('/tmp/borough-layers-20260907/million-day6.save')
cases.extend([(f'million-resumed-{build}',build,'resumed',checkpoint,1000000,0,False) for build in ('after','before')])
for name,build,mode,checkpoint,pop,seed,work in cases:
 binary=r/(build+'-run')/'Borough.Tests.dll'
 cmd=['dotnet',str(binary),mode,str(checkpoint),str(pop),str(seed),'8','2']+(['work'] if work else [])
 (r/(name+'-command.json')).write_text(json.dumps({'command':cmd,'conditions':'Release .NET 10, M4 Pro, 8 route workers including caller; sequential captures, no overlapping builds/tests; desktop open. Work-instrumented small/100k, untraced million. Timings are local diagnostics, not quiet-machine ratification.','assemblies':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.parent.glob('*.dll')}},indent=2)+'\n')
 print('START',name,flush=True)
 with (r/(name+'.jsonl')).open('x') as out,(r/(name+'-resources.txt')).open('x') as err:
  status=subprocess.run(['/usr/bin/time','-l',*cmd],stdout=out,stderr=err)
 if status.returncode:raise RuntimeError((name,status.returncode))
 a=[json.loads(s) for s in (r/(name+'.jsonl')).read_text().splitlines()]
 assert a[-1]['invariants']=='passed'
 print('DONE',name,json.dumps([x for x in a if 'MeanMs' in x]),json.dumps(a[-1]),flush=True)
