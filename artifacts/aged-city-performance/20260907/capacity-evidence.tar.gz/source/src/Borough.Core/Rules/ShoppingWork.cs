using Borough.Core.Space;
using Borough.Core.Movement;

namespace Borough.Core.Rules;

public sealed class ShoppingWork
{
    public RouteWork Estimates { get; } = new();
    public BuildingQueryWork Selection { get; } = new();
    public long Considered { get; set; }
    public long Starts { get; set; }
    public long NoKnownShop { get; set; }
    public long Unreachable { get; set; }
    public void Reset()
    {
        Estimates.Reset(); Selection.Reset();
        Considered = Starts = NoKnownShop = Unreachable = 0;
    }
}
