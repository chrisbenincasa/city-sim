namespace Borough.Core.Entities;

using Borough.Core.Rules;
using Borough.Core.Tables;

/// <summary>
/// The Businesses, each occupying a Building and holding its own balance.
/// </summary>
/// <remarks>
/// <para>
/// <b>A balance sits on the actor, because that is already how the one existing actor holds one</b>
/// (<c>adr/0113</c>) — <c>adr/0024</c>'s <em>"one integer per Household and per Business"</em> is
/// trivial in the way that sentence claims only if both actors spell it the same way. ⚠ <b>They do,
/// and the spelling is a Bin rather than the column task 4b built</b> (<c>adr/0114</c>): see
/// <see cref="Balance"/>.
/// </para>
/// <para>
/// <b>A Building never holds money, and this table is what makes that affordable.</b>
/// <see cref="BuildingTable.OccupantHead"/> is the head of a <em>list</em>, so a money Bin on the
/// Building would be a sum over however many Occupants are in it — an average wearing a total, which
/// is <c>adr/0025</c>'s Cohort prohibition applied to the container. A balance belonging to the actor
/// is right at any cardinality, which is the property a Bin <em>on the Building</em> lacks. ⚠ <b>That
/// is an argument about whose balance it is, not about how it is stored</b>, and reading it as the
/// second is what put a column here for a day.
/// </para>
/// <para>
/// <b>The occupant list stays homogeneous.</b> This is a <em>second</em> list on the Building rather
/// than one polymorphic list holding two row types — the third axis on the precedent of the second,
/// after <see cref="BuildingTable.OccupantHead"/> into <see cref="HouseholdTable.DwellingNext"/> and
/// <see cref="BuildingTable.WorkerHead"/> into <see cref="CitizenTable.WorkerNext"/>. So
/// <c>CONTEXT.md</c> → Occupant is a concept spanning two lists rather than a discriminated union,
/// which is what lint 7 wants anyway.
/// </para>
/// <para>
/// ⚠ <b>The balance is all there is, and stopping there is the decision.</b> A Business fully
/// modelled <em>"consumes inputs, produces outputs, employs Citizens, and offers Goods or services to
/// the market"</em> — milestones <b>12</b>, <b>13</b> and <b>15</b>. Milestone 10 needs exactly one
/// property: somewhere for conserved money to sit that is not a Building.
/// </para>
/// <para>
/// ⚠ <b>How many Businesses occupy one Building is undesigned</b> (<c>adr/0070</c>) and nothing in the
/// corpus states it. It does not block this table — a balance on the actor is right at any
/// cardinality — but it blocks the first money term a Rule fires on a workplace, because
/// <c>local</c> money must resolve to <em>an</em> actor and a list does not name one.
/// </para>
/// </remarks>
[Table]
public sealed class BusinessTable
{
    private readonly Rows<Business> _rows;

    /// <param name="capacity">Initial slot count.</param>
    /// <param name="buildings">The table this one's premises handles address.</param>
    /// <param name="bins">The table this one's balance handles address.</param>
    public BusinessTable(int capacity, BuildingTable buildings, BinTable bins)
    {
        ArgumentNullException.ThrowIfNull(buildings);
        ArgumentNullException.ThrowIfNull(bins);

        _rows = new Rows<Business>("business", capacity, Buffering.OneCopy);

        // Severable, on CitizenTable.Workplace's precedent and for its reason: demolishing the
        // premises invalidates the handle with no hook, and `the premises stopped existing` is a fact
        // worth reading off a dangling handle rather than a state worth writing. The alternative --
        // clearing it in DestroyBuilding -- is a write to a saved column, so a demolition would move
        // the State Hash for a reason that has nothing to do with the demolition.
        Building = _rows.SavedHandle("building", buildings.Rows, reference: Reference.Severable);
        Kind = _rows.Saved<byte>("kind");

        // 🔴 adr/0148, AMENDED by milestone 27 task 10: which premises INSTANTIATED this Business,
        // and the amendment is here because the ADR asked DestroyBuilding to identify "the trade this
        // kind came with" and gave it only the kind to identify it by. A KIND IS NOT AN IDENTITY: a
        // Household may found a Business of the very trade a dwelling declares, so on a file that
        // does -- rulesets/founded.toml and rulesets/levied.toml, since founding draws uniformly over
        // every declared trade -- the founded shop and the instantiated one are indistinguishable in
        // the list, and demolition razed whichever came first. Measured at 24,576 Ticks: 52 stranded.
        //
        // Severable, on Building's own precedent above: these premises may come down while this
        // Business is elsewhere, and `the premises that made me stopped existing` is a fact worth
        // reading off a dangling handle rather than a state worth writing.
        //
        // ⚠ IT IS THE ORIGIN AND NOT A FLAG, which is the half that keeps adr/0148's "no founder, no
        // capital and no flag" true. A bit saying `I was instantiated` would follow the Business into
        // whatever premises it was later placed in and get it razed there; a handle naming ONE
        // Building stops meaning anything the moment it leaves, which is exactly right.
        Origin = _rows.SavedHandle("origin", buildings.Rows, reference: Reference.Severable);
        BinHead = _rows.SavedHandle("bin_head", bins.Rows);
        BinTail = _rows.SavedHandle("bin_tail", bins.Rows);
        // 🔴 How many CONSECUTIVE paydays this Business has failed to meet in full. Saved and
        // hashed, because it is the only thing in the build that remembers a trade is in trouble --
        // WageEngine's `owed` is computed fresh every payday and forgotten, and Underpaying is a
        // readout counter that survives one Tick. ***A city whose failures are all instantaneous has
        // no economic middle***, which is CLAUDE.md's standing `balance -> unbalance -> balance`
        // constraint restated at the Business.
        //
        // ⚠ SATURATING, and the byte is the bound rather than an estimate of one. A trade whose
        // Ruleset states no GoesBankruptAfterShortPaydays never goes bankrupt, so nothing would stop this climbing
        // for the life of the world -- adr/0006's magnitude trending upward at steady state, in the
        // column added to give a failure a consequence. It stops at 255 and means `at least 255`.
        //
        // ⚠ Saved rather than derived, and the distinction is load-bearing: it cannot be rebuilt.
        // Nothing else records that last payday was short, so a reload that recomputed this would
        // hand every insolvent Business a clean slate and reset the city's decline on every load.
        ShortPaydays = _rows.Saved<byte>("short_paydays");
        Balance = _rows.DerivedHandle("balance", bins.Rows, reference: Reference.Required);
        BuildingNext = _rows.Derived<int>("building_next");
        PoolSlot = _rows.Derived<int>("pool_slot");

        // Moved here from BuildingTable by milestone 27 task 7 (adr/0141): a Citizen is employed by
        // a TRADE and not by premises, so the list of who works somewhere hangs off the employer.
        // Derived, because it is rebuilt from CitizenTable.Workplace and folds into no hash.
        WorkerHead = _rows.Derived<int>("worker_head");
        WorkerTail = _rows.Derived<int>("worker_tail");

        _rows.Seal();
    }

    /// <summary>The slot allocator, the generation counters and the column list.</summary>
    public Rows<Business> Rows => _rows;

    /// <summary>The Building this Business occupies.</summary>
    public HandleColumn<Building> Building { get; }

    /// <summary>
    /// The premises that <b>instantiated</b> this Business, or none if nothing did.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b><c>adr/0148</c>'s pairing, made identifiable</b> — <em>when those premises come down it goes
    /// with them</em>. <c>World.Fit</c> writes it and <c>World.DestroyBuilding</c> is the only reader:
    /// it razes the Business in its list whose origin is <em>itself</em>, and pools every other tenant.
    /// </para>
    /// <para>
    /// 🔴 <b>It exists because a kind is not an identity, and milestone 27 task 10's long run is what
    /// found that out.</b> Demolition matched on <see cref="Kind"/>, which is correct in any world
    /// where the only Business of a trade in a Building is the one construction made — and
    /// <c>[founding]</c> draws uniformly over <em>every</em> declared trade, so a founded shop can sit
    /// in a dwelling beside the instantiated shop and be razed in its place. ***Two defects from one
    /// line***: the founded Business's capital left the city through <c>Raze</c>'s money-supply write,
    /// and the instantiated one outlived its premises into the unpremised pool, where nothing ever
    /// collected it. **Measured on <c>rulesets/levied.toml</c> at 24,576 Ticks: 52 stranded shops
    /// holding nothing; on <c>minimal.toml</c> and <c>taxed.toml</c>, which found nothing, zero.**
    /// </para>
    /// <para>
    /// ⚠ <b>Saved rather than derived, because nothing else in the world records it.</b> A demolition
    /// is the only reader and a construction the only writer, so there is no second copy to rebuild
    /// from — which is what makes this hash-bearing rather than free.
    /// </para>
    /// </remarks>
    public HandleColumn<Building> Origin { get; }

    /// <summary>Which Business kind — the trade. Resolved through the Ruleset.</summary>
    /// <remarks>
    /// <para>
    /// <b>The second kind namespace, and it is deliberately not the Building's.</b> <c>adr/0141</c>:
    /// <em>the premises and the trade are not correlated, and nothing in a single kind table can
    /// express that</em> — putting <em>bakery</em> on the walls would make a tenant leaving demolish
    /// the shop in order to stop being one. So this id indexes <c>[[business]]</c> and never
    /// <c>[[building]]</c>, and the two may legitimately carry the same name for different things.
    /// </para>
    /// <para>
    /// ⚠ <b>A Business kind declares nothing yet, and the column is still worth its byte.</b> What it
    /// buys is that a Business can NAME its trade and keep that name across a reload
    /// (<see cref="Ruleset.BusinessKindKeys"/>). <c>jobs</c>, shift hours and the wage arrive at
    /// milestone 27's task 7; until then this is identity and nothing else.
    /// </para>
    /// <para>
    /// <b>Zero is legal and means the trade is derelict</b> — the kind is one a reloaded Ruleset no
    /// longer declares, or the Business was made by a fixture that named none. The row and its balance
    /// survive either way, because money is conserved regardless of who is holding it
    /// (<c>adr/0024</c>).
    /// </para>
    /// </remarks>
    public Column<byte> Kind { get; }

    /// <summary>
    /// Consecutive paydays this Business has failed to meet in full, saturating at <c>255</c>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Zero is solvent, and a payroll met in full writes zero.</b> The count is of consecutive
    /// failures rather than total ones, so recovery is a real state a Business can reach and not
    /// merely a slower decline — see
    /// <see cref="Rules.BusinessKindDefinition.GoesBankruptAfterShortPaydays"/>, which carries why.
    /// </para>
    /// <para>
    /// ⚠ <b>It counts OCCASIONS and not Days.</b> One increment is one payday, so what a given
    /// value means in elapsed time is <see cref="Rules.BusinessKindDefinition.PayPeriodDays"/>
    /// times it. <b>Reading it as a duration is a unit error the column name is chosen to prevent.</b>
    /// </para>
    /// </remarks>
    public Column<byte> ShortPaydays { get; }

    /// <summary>
    /// This Business's money Bin — its balance (<c>adr/0114</c>).
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Task 4b shipped this as a <c>Column&lt;Money&gt;</c> and task 4c replaced it</b>, because
    /// <c>adr/0114</c> — settled the same day as the decision that created this table — says a balance
    /// a Rule can fail on is a Bin. See <see cref="HouseholdTable.Balance"/> for the shape and the
    /// reason the link sits on the actor.
    /// </para>
    /// <para>
    /// <b>The column was not merely a different spelling of the same thing.</b> <c>adr/0024</c>'s
    /// <em>"one integer per Household and per Business"</em> is only trivial if both actors spell it
    /// the same way — which was 4b's argument for a column, and survives the reversal intact, because
    /// the Household moved too. ***An argument for symmetry does not name which side to move.***
    /// </para>
    /// <para>
    /// <b>Nothing funds one.</b> A Business opens with an empty Bin and there is no door that pays it.
    /// ⚠ <b>This sentence used to blame milestone 13's price surface and that was the wrong address.</b>
    /// A Household's opening balance is an authored band on its <em>Hinterland</em> and
    /// <c>World.Endow</c> has no Business overload at all, so what is missing is a <em>capitalisation
    /// band</em> rather than a counterparty — a hash-bearing number owed a named ratifier under
    /// <c>adr/0052</c>. It is <c>plans/0002</c> §D2 and it belongs to milestone <b>27</b>.
    /// </para>
    /// <para>
    /// 🔴 <b>It is <see cref="Disposition.Derived"/> as of <c>adr/0143</c>, and it used to be saved.</b>
    /// A Business now owns a <em>list</em> of Bins — <see cref="BinHead"/> — and the balance is one entry
    /// in it, so a second saved handle to the same Bin would be two saved facts that can disagree. It is
    /// maintained at the write site and re-derived by <c>World.RebuildDerived</c>.
    /// </para>
    /// </remarks>
    public HandleColumn<Bin> Balance { get; }

    /// <summary>
    /// Head of this Business's own Bins — its stock, and its till. <b>The Business is the owner</b>
    /// (<c>adr/0141</c>, <c>adr/0143</c>).
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>A bakery holds its own flour, its own bread and its own till; the building holds a street
    /// address and some floors.</b> That is <c>adr/0141</c>, and this list is the half of it that
    /// leaves when the tenant leaves. Threaded through <see cref="BinTable.OwnerNext"/>.
    /// </para>
    /// <para>
    /// <b>Saved rather than derived</b>, because an Occupant-owned Bin names no owner and
    /// <em>a derived list is only derivable when the element names its owner</em>. ⚠ <b>The capacity of
    /// what is in it is still the premises'</b> — <c>adr/0141</c> keys a Bin's ceiling on the
    /// <em>building</em> kind — which is why 🔴 <b>an unpremised Business is an open question rather
    /// than a solved case</b>: <see cref="Building"/> is <see cref="Reference.Severable"/> and
    /// <c>adr/0142</c> makes losing the premises a legitimate state, so what bounds these Bins then is
    /// <c>plans/0040</c> open decision <b>1</b>.
    /// </para>
    /// </remarks>
    public HandleColumn<Bin> BinHead { get; }

    /// <summary>Tail of this Business's Bins, so a new one appends rather than push-fronts.</summary>
    public HandleColumn<Bin> BinTail { get; }

    /// <summary>Link in the premises' Business list.</summary>
    public Column<int> BuildingNext { get; }

    /// <summary>
    /// Where this Business is in the unpremised pool, plus one, or <c>0</c> if it has premises.
    /// </summary>
    /// <remarks>
    /// <b>Derived, and rebuilt from <see cref="UnpremisedTable"/> on load</b>, which is
    /// <c>HouseholdTable.PoolSlot</c>'s disposition for its reason: the pool table is the saved truth
    /// and a reverse index that was also saved is a second fact free to disagree with it
    /// (<c>plans/0040</c> <b>F12</b>, one relation later). ⚠ <b>Plus-one encoded</b> so that a
    /// zero-filled column reads as <em>premised</em> rather than as <em>at position 0</em>.
    /// </remarks>
    public Column<int> PoolSlot { get; }

    /// <summary>The first Citizen this Business employs. Zero means it employs nobody.</summary>
    /// <remarks>
    /// <b>The reverse index behind <see cref="CitizenTable.Workplace"/></b>, moved off the Building
    /// when the Workplace stopped being one (<c>adr/0141</c>, milestone 27 task 7). ⚠ <b>An
    /// unpremised Business can hold workers</b> — its founder is one (<c>adr/0146</c>) — and they
    /// make no Trip, because a commute needs a location and this Business has none yet.
    /// </remarks>
    public Column<int> WorkerHead { get; }

    /// <summary>The last Citizen this Business employs, so an append needs no walk.</summary>
    public Column<int> WorkerTail { get; }

    /// <summary>Whether this Business is in the unpremised pool.</summary>
    public bool IsUnpremised(int slot) => PoolSlot[slot] != 0;

    /// <summary>Where in the pool it is, or <see cref="Rows.NoSlot"/> if it has premises.</summary>
    public int PoolPosition(int slot) => PoolSlot[slot] - 1;

    /// <summary>Records that this Business is now at <paramref name="position"/> in the pool.</summary>
    public void EnterPool(int slot, int position) => PoolSlot[slot] = position + 1;

    /// <summary>Records that this Business is no longer in the pool.</summary>
    public void LeavePool(int slot) => PoolSlot[slot] = 0;
}
