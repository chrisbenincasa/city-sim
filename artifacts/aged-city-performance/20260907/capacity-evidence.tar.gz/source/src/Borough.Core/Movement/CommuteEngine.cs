using Borough.Core.Entities;
using Borough.Core.Quantities;
using Borough.Core.Rules;
using Borough.Core.Space;
using Borough.Core.Tables;

namespace Borough.Core.Movement;

/// <summary>
/// The first Trip generator in the project: everybody with a Workplace travels to it once a Day.
/// </summary>
/// <remarks>
/// <para>
/// <b>This is what <c>adr/0080</c> was written against.</b> That decision built Phase 4 ahead of any
/// generator, on the ground that nothing in the cursor, the Fate or the Census depends on
/// <em>which</em> pairs travel — so the test of it is whether a generator can arrive without editing
/// any of them. It can: this class creates Trips through <see cref="TripEngine.Start"/> and touches
/// nothing else. <c>TripPurpose.Commanded</c> keeps its rule — <b>nothing downstream branches on the
/// purpose</b> — and the only new thing in Phase 4 is the loop below.
/// </para>
/// <para>
/// <b>The occasion is a <em>phase</em>, not a schedule, and <c>adr/0101</c> keeps that while
/// doubling it.</b> A Citizen leaves home at one Tick of the Day and leaves work at another, and both
/// are computed rather than armed: <see cref="CommuteRoster"/> is two partitions of the population,
/// <c>(derived AND rebuilt)</c>, costing no saved column and no per-Tick re-arm. What it is a
/// partition <em>on</em> has changed — it was the Citizen's id under a uniform window, and it is now
/// the Workplace's Shift start against the Citizen's own planned commute — but it is still a function
/// of saved state rather than an event that fires.
/// </para>
/// <para>
/// <b>The Day has a shape, and nothing here authors one.</b> Two peaks, a baseline through the middle
/// and a quiet night are what a spread of Shift start hours and an unequal spread of Shift lengths
/// look like from outside; there is no departure curve, no window and no peak dial. The morning is
/// sharp because a Workplace's staff share a start hour, and broad because they subtract their own
/// commutes from it; the evening is flatter because they do not share a Shift length. See
/// <c>adr/0101</c>, and <c>CONTEXT.md</c> → Shift.
/// </para>
/// <para>
/// <b>Tick 0 of the Day is 05:00</b> (<see cref="Ticks.DayBeginsAtHour"/>, read through
/// <see cref="Ticks.AtClock"/>). This class used to say the Day began at the peak and that the choice
/// was unobservable, which was true while nothing in the simulation asked the time. A Day with a quiet
/// night in it distinguishes its own ends, so the freedom is spent — deliberately, once, and not in a
/// Ruleset key.
/// </para>
/// <para>
/// 🔴 ⚠ <b>It said <em>midnight</em> until 2026-09-01, which is <c>adr/0101</c>'s own convention and
/// not a claim this class was making.</b> Two readers arrived that the ADR did not have: a run opened
/// with no start Tick begins at Tick 0, and under a sun that moves that meant every fresh run opened
/// in the dark — and a Day boundary at midnight cuts the night in half, so the quiet hours belong to
/// two Day numbers and no readout of <em>a Day</em> ever shows one. <b>What moved is a phase and not a
/// length</b>: a Day is still <see cref="Ticks.PerDay"/> Ticks and 24 hours, and every duration in
/// this file is untouched. A Shift starting at 06:00 now begins at Tick 85 of the Day where it began
/// at Tick 512, which is a design change under <c>05 §4</c> and not an optimisation.
/// </para>
/// <para>
/// <b>The evening leg is here, and the refusal it replaces was reasoning from an absence.</b> The
/// standing argument was that a return journey makes a Citizen's day a <em>schedule</em>, whose shape
/// is decided by <c>adr/0067</c>'s shopping and <c>adr/0032</c>'s school — both <em>unbuilt</em>, and
/// <c>adr/0070</c> says an unbuilt mechanism is not a design constraint, so that is the rule inverted.
/// A return commute is in any case the one journey a later generator cannot reshape: its endpoints are
/// fixed and already stored, and its occasion is the end of a Shift.
/// </para>
/// <para>
/// <b>Nobody can be in flight when their next departure comes round, and it is still the loader that
/// guarantees it — but the guarantee is now stated rather than accidental.</b> Under one journey a Day
/// the gap between departures was a whole Day and the Commute Budget bounded a journey in minutes, so
/// the overlap was arithmetically unreachable and nobody had to say so. With two journeys the gap is
/// the <b>Shift length</b>, so <c>RulesetLoader</c> refuses a minimum Shift at or below the Commute
/// Budget's ceiling. ⚠ <b>The old property was a happy accident of there being one journey and it read
/// as a design property</b>, which is the shape worth remembering: an invariant nothing enforces
/// survives exactly as long as the structure that made it free.
/// </para>
/// </remarks>
public sealed class CommuteEngine
{
    private readonly World _world;
    private readonly TripEngine _trips;
    private RouteBatch? _batch;
    private readonly TravelRequest[] _requests = new TravelRequest[RouteBatch.TripLimit];
    private int _requestCount;
    private int _workers = 1;
    public int RouteWorkerCount
    {
        get => _workers;
        set
        {
            ArgumentOutOfRangeException.ThrowIfLessThan(value, 1);
            ArgumentOutOfRangeException.ThrowIfGreaterThan(value, 8);
            if (_workers == value) { return; }
            _batch = value == 1 ? null : new RouteBatch(_world.Roads, value);
            _workers = value;
        }
    }
    public RouteBatchReading LastBatch => _batch is null ? default
        : new(_batch.Prepared, _batch.Used, _batch.Fallback);
    private readonly record struct TravelRequest(int Citizen, bool Homeward);

    /// <param name="world">The world whose Citizens commute.</param>
    /// <param name="trips">The one door a Trip is created through.</param>
    public CommuteEngine(World world, TripEngine trips)
    {
        ArgumentNullException.ThrowIfNull(world);
        ArgumentNullException.ThrowIfNull(trips);

        _world = world;
        _trips = trips;
    }

    /// <summary>Starts the commute of everybody whose departure phase is this Tick of the Day.</summary>
    /// <remarks>
    /// <para>
    /// <b>Two refusals, and both are silence rather than an exception.</b> A Ruleset with no
    /// <c>[jobs]</c> has no employment and therefore no commute; one with no <c>[trips]</c> has no
    /// crossing cost, and <see cref="TripEngine.Start"/> would price every junction at zero. Neither
    /// is a defect in a Ruleset — <c>rulesets/minimal.toml</c> was both for six slices — so a
    /// generator that threw would make an ordinary file unloadable. The refusal that <em>is</em> loud
    /// lives at the loader: <c>[jobs]</c> without a Commute Budget is rejected outright.
    /// </para>
    /// <para>
    /// <b>Walked in bucket order, which is slot order, which is why replay reproduces it.</b>
    /// <see cref="IndexList.InsertOrdered"/> keeps each bucket ascending by slot however it was
    /// filled, so the Trips of one Tick are created in the same sequence on a rebuild as on the run
    /// that saved it — and Trip ids, which the State Hash folds, come out the same.
    /// </para>
    /// </remarks>
    public void Generate(Ticks tick)
    {
        _batch?.ResetReading();
        if (!_world.Rules.Jobs.Runs || !_world.Rules.Trips.Runs)
        {
            return;
        }

        if (WorkSchedule.Runs(_world))
        {
            for (int who = 0; who < _world.Citizens.Rows.SlotCount; who++)
            {
                if (_world.Citizens.Rows.IsLive(who)
                    && (CitizenActivity)_world.Citizens.Activity[who] == CitizenActivity.AtWork
                    && !WorkSchedule.AwayTime(_world, who, tick))
                { QueueTravel(who, true, tick); }
            }
        }
        Flush(tick);
        int phase = (int)(tick.Raw % Ticks.PerDay);
        CitizenTable citizens = _world.Citizens;

        // Outbound before homeward, and the order is arbitrary but must be fixed: both walk in slot
        // order and both create Trips, so swapping them renumbers every Trip id the State Hash folds
        // on any Tick that carries both. It carries both often -- an early shift's return and a late
        // shift's departure share the middle of the Day, which is the all-day baseline this design
        // exists to produce.
        foreach (int citizen in _world.Commutes.Departing(citizens, phase))
        {
            if (!WorkSchedule.Runs(_world) || WorkSchedule.DepartsToday(_world, citizen, tick))
            {
                QueueTravel(citizen, homeward: false, tick);
            }
        }
        Flush(tick);

        foreach (int citizen in _world.Commutes.Returning(citizens, phase))
        {
            QueueTravel(citizen, homeward: true, tick);
        }
        Flush(tick);
    }

    /// <summary>Starts one leg of one Citizen's commute, in whichever direction.</summary>
    /// <remarks>
    /// <b>One method for both directions rather than two loops that drifted.</b> The endpoints are the
    /// same pair read in the opposite order, and every other term -- the mode, the purpose, the
    /// refusals -- is identical, so a second copy would be two places for the Commute Budget to be
    /// applied differently.
    /// </remarks>
    public void Resume(int citizen, Ticks tick)
    {
        if (WorkSchedule.OnDuty(_world, citizen, tick)) { Travel(citizen, false, tick); }
    }

    private void QueueTravel(int citizen, bool homeward, Ticks tick)
    {
        if (_batch is null || _world.Roads.Nodes.Rows.SlotCount < 256)
        { Travel(citizen, homeward, tick); return; }
        _requests[_requestCount++] = new(citizen, homeward);
        if (_requestCount == _requests.Length) { Flush(tick); }
    }

    private void Flush(Ticks tick)
    {
        if (_requestCount == 0) { return; }
        // Scheduling overhead has no useful work to amortize in a tiny window.
        RouteBatch? batch = _requestCount >= 8 ? _batch : null;
        try
        {
            if (batch is not null)
            {
                batch.Clear();
                for (int i = 0; i < _requestCount; i++)
                {
                    var request = _requests[i];
                    if (TryJourney(request.Citizen, request.Homeward, out int from, out int to, out TravelMode mode))
                    { _trips.PrepareRoutes(batch, i, request.Citizen, from, to, mode); }
                }
                batch.Run();
            }
            for (int i = 0; i < _requestCount; i++)
            {
                var request = _requests[i];
                Travel(request.Citizen, request.Homeward, tick, batch, i);
            }
        }
        finally { _requestCount = 0; }
    }

    private bool TryJourney(int citizen, bool homeward, out int origin, out int destination, out TravelMode mode)
    {
        origin = destination = -1; mode = default;
        CitizenTable citizens = _world.Citizens;

        // ⚠ WHERE THEY ARE, and it is checked first because it is the cheapest test here and because
        // the roster does not know. Departing() and Returning() partition by the Day's PHASE, so both
        // lists fire on a Citizen wherever they happen to be standing -- and until Activity had a
        // writer the only observable was a Trip count, in which a journey home from home is a Trip
        // like any other. Measured on minimal.toml at 2,000 Citizens over one Day: 163 journeys home
        // from home and 69 to work from work, against 369 honest departures.
        //
        // Being in the wrong place is not itself a defect. adr/0081 assigns employment on a cadence,
        // so somebody hired after their outbound phase has passed meets their HOMEWARD phase first --
        // 149 were hired during the measured Day. adr/0101 anchors both journeys on the Shift and
        // says nothing about the Citizen who missed the first one, so they wait for tomorrow morning
        // rather than being given a journey they never earned.
        //
        // A Citizen mid-journey is excluded by the same test, which is the second thing it buys: a
        // roster phase arriving while somebody is still walking would otherwise start a second Trip
        // under the first.
        if (!homeward && CivicEngine.TooIllToWork(_world, citizen)) { return false; }
        var standing = (CitizenActivity)citizens.Activity[citizen];

        if (standing != (homeward ? CitizenActivity.AtWork : CitizenActivity.AtHome))
        {
            return false;
        }

        // Two hops as of milestone 27 task 7: a Workplace is a Business, and a Business sits in
        // premises. An employer with no premises has nowhere to travel to -- a founder before
        // placement (adr/0146, adr/0147) -- and that is a Citizen with a job and no journey rather
        // than a defect.
        if (!_world.Businesses.Rows.TryResolve(citizens.Workplace[citizen], out int employer)
            || !_world.Buildings.Rows.TryResolve(
                _world.Businesses.Building[employer], out int workplace))
        {
            return false;
        }

        int home = HomeOf(citizen);

        // A Citizen with a job and no home. Not a defect and not a Trip: the Unplaced Pool holds
        // Households that have nowhere to live, and adr/0069 makes housing them a mechanism of its
        // own that runs at its own pace. Walking from nowhere is not the honest degradation.
        if (home < 0)
        {
            return false;
        }

        mode = _world.ModeOf(citizen);
        (origin, destination) = homeward ? (workplace, home) : (home, workplace);

        return true;
    }

    private void Travel(int citizen, bool homeward, Ticks tick, RouteBatch? batch = null, int index = 0)
    {
        if (!TryJourney(citizen, homeward, out int origin, out int destination, out TravelMode mode)) { return; }
        CitizenTable citizens = _world.Citizens;

        // Set BEFORE Start rather than after, and it is not a style choice: every refusal inside
        // Start resolves through World.ResolveTrip on the spot, so a journey that is never made
        // has already been read back and reverted by the time Start returns. Writing it afterwards
        // would stamp "travelling" onto somebody standing still.
        citizens.Activity[citizen] = (byte)(homeward
            ? CitizenActivity.TravellingHome
            : CitizenActivity.TravellingToWork);

        if (batch is null) { _trips.Start(citizen, origin, destination, mode, TripPurpose.Commute, tick); }
        else { _trips.StartPrepared(citizen, origin, destination, mode, tick, batch, index); }
    }

    /// <summary>The Building a Citizen lives in, or <c>-1</c> if their Household is unplaced.</summary>
    private int HomeOf(int citizen)
    {
        if (!_world.Households.Rows.TryResolve(
                _world.Citizens.HouseholdOf[citizen], out int household))
        {
            return -1;
        }

        return _world.Buildings.Rows.TryResolve(
            _world.Households.Dwelling[household], out int building)
            ? building
            : -1;
    }
}
