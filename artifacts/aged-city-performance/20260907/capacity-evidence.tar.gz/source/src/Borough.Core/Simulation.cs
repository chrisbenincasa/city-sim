using Borough.Core.Arithmetic;
using Borough.Core.Determinism;
using Borough.Core.Entities;
using Borough.Core.Input;
using Borough.Core.Movement;
using Borough.Core.Persistence;
using Borough.Core.Quantities;
using Borough.Core.Rules;
using Borough.Core.Space;
using Borough.Core.Tables;

namespace Borough.Core;

/// <summary>
/// <c>step(inputs)</c>: one world, one Tick counter, and the eight phases in order.
/// </summary>
/// <remarks>
/// <para>
/// <b>The simulation is a pure function of its inputs</b> (<c>02 §1</c>). It has no concept of
/// wall-clock time, no camera, no renderer and no filesystem, and the host decides when to advance
/// the Tick. That is what makes fast-forward, headless testing and replay free rather than features
/// somebody has to build.
/// </para>
/// <para>
/// <b>This is separate from <see cref="Entities.World"/> because storage and time are separate
/// things.</b> The World is the tables and the cross-table operations that keep them consistent; the
/// Simulation is what advances them. Keeping the Tick counter out of the World also keeps it out of
/// the State Hash's composition, where it does not belong: two worlds identical in every row are
/// identical worlds, and the Tick they were reached on is a property of the run.
/// </para>
/// <para>
/// The caller owns Step. Commute route searches may use workers; all world mutations remain on
/// the caller, and each search batch completes before its results are consumed.
/// </para>
/// </remarks>
public sealed class Simulation
{
    private readonly World _world;
    private readonly WorldKey _key;
    private readonly RuleEngine _rules;
    private readonly ZoneRuleEngine _zoning;
    private readonly PolicyEngine _policies;
    private readonly WageEngine _wages;
    private PayrollReading _lastPayroll;
    private readonly LifeStageEngine _lifeStages;
    private LifeStageReading _lastLifeStages;
    private readonly DisasterEngine _disasters;
    private DisasterReading _lastDisasters;
    private readonly PlacementEngine _placement;
    private readonly EmploymentEngine _employment;
    private readonly TripEngine _trips;
    private readonly CommuteEngine _commutes;
    private readonly ServiceEngine _services;
    private readonly RulesetCatalogue _rulesets;

    // Reusable search state for every walk this simulation resolves. It is not simulation state and
    // folds nothing: WalkScratch.Begin grows its arrays and bumps a generation stamp rather than
    // clearing, so holding one costs a high-water mark of nodes and saves a whole allocation per Leg.

    private ISaveSink? _saveDue;
    private WorldSnapshot? _snapshot;

    private TickPhase _phase = TickPhase.Commit;

    // Optional diagnostics; the observer owns timing and must not mutate the simulation.
    public Action<TickPhase>? PhaseCompleted { get; set; }
    private ulong _inForce;
    private bool _opened;
    private int _reloads;
    private RulesetDegradation _degradation;

    /// <param name="world">The tables this advances. Not copied; the Simulation does not own it.</param>
    /// <param name="key">The world seed, already folded. The first coordinate of every draw.</param>
    public Simulation(World world, WorldKey key)
        : this(world, key, RulesetCatalogue.None)
    {
    }

    /// <inheritdoc cref="Simulation(World, WorldKey)"/>
    /// <param name="world">The tables this advances. Not copied; the Simulation does not own it.</param>
    /// <param name="key">The world seed, already folded. The first coordinate of every draw.</param>
    /// <param name="rulesets">
    /// Every Ruleset this session references, by content hash, opening one first. Slice 8's reload
    /// resolves a transition out of this and never out of a file.
    /// </param>
    /// <remarks>
    /// <b>Supplied up front because <c>Core</c> cannot turn a hash into Rules</b> — see
    /// <see cref="RulesetCatalogue"/>. A session that never reloads passes
    /// <see cref="RulesetCatalogue.None"/> and behaves exactly as it did before slice 8, which is what
    /// keeps every existing golden baseline meaningful.
    /// </remarks>
    public Simulation(World world, WorldKey key, RulesetCatalogue rulesets)
    {
        ArgumentNullException.ThrowIfNull(world);
        ArgumentNullException.ThrowIfNull(rulesets);

        if (rulesets.Count > 0 && !ReferenceEquals(rulesets.Opening, world.Rules))
        {
            // The catalogue's first entry is what the world opened with, and a catalogue that
            // disagreed would make the first reload swap *away* from Rules the city had never been
            // running — a divergence with no symptom, because both Rulesets load and both run.
            throw new ArgumentException(
                "the catalogue's opening Ruleset is not the one this World holds. The first entry "
                + "names the Rules the world was created with; a reload is a transition away from "
                + "them.",
                nameof(rulesets));
        }

        _world = world;
        _key = key;
        _rules = new RuleEngine(world, key);
        _zoning = new ZoneRuleEngine(world, key);
        _policies = new PolicyEngine(world, key);
        _wages = new WageEngine(world, key);
        _lifeStages = new LifeStageEngine(world);
        _employment = new EmploymentEngine(world, key);

        // No WorldKey: nothing in Phase 4 draws. A Traveller advances when its Leg's arrival Tick has
        // come, which is arithmetic over state the log already determines, so there is no decision here
        // for a purpose_tag to separate. If one ever appears, it needs its own tag (BOR0801-BOR0803).
        _trips = new TripEngine(world);

        // Ahead of the Trip engine until milestone 11 task 6, and moved here because placement now
        // starts the move-in Trip. Construction order is not composition order -- the State Hash
        // folds World._tables, which nothing here touches.
        _disasters = new DisasterEngine(world, key);
        _placement = new PlacementEngine(world, key, _trips);
        _commutes = new CommuteEngine(world, _trips);
        _civic = new CivicEngine(world, _trips, _commutes);
        _services = new ServiceEngine(world, _trips, _civic);
        _shopping = new ShoppingEngine(world, _trips, _commutes);
        _rulesets = rulesets;
    }

    /// <summary>The tables this Simulation advances.</summary>
    public World World => _world;

    /// <summary>The Bin Rule interpreter: Phase 1 collects, Phase 2 evaluates, Phase 3 applies.</summary>
    /// <remarks>
    /// <b>Owned here rather than by the <see cref="Entities.World"/>, unlike the invariant registry.</b>
    /// The registry holds claims about a world and a hand-built test world has the same ones; the
    /// engine holds a Tick's worth of scratch, which only means anything inside a Tick. Putting it on
    /// the World would have made the buffers look like state, which is precisely what they must not be.
    /// </remarks>
    public RuleEngine Rules => _rules;

    /// <summary>The Sweep Rule interpreter: Zone Rules trigger, sample and act, all in phase 6.</summary>
    /// <remarks>
    /// <b>A second engine rather than a mode of the first, which is <c>adr/0033</c> honoured in the
    /// code layout.</b> The two families share the word <em>Rule</em> and nothing else structural: one
    /// is woken by the Event Wheel and settled against contention, the other is polled on an interval
    /// and acts where it runs. A single class that branched on family would make moving a mechanism
    /// between them look like a flag, which is exactly what the ADR says it is not.
    /// </remarks>
    public ZoneRuleEngine Zoning => _zoning;

    /// <summary>
    /// <c>02 §5.2</c> step 2: the Unplaced Pool draining into standing vacancy, in phase 6 ahead of
    /// <see cref="Zoning"/>.
    /// </summary>
    /// <remarks>
    /// <b>A third engine rather than a step inside the second, and the reason is not symmetry.</b>
    /// Placement is not a Rule of either family — nothing declares it, no Ruleset chooses whether a
    /// city houses people, and it acts on Households where a Zone Rule acts on Lots. Folding it into
    /// <see cref="ZoneRuleEngine"/> would put a mechanism the Ruleset does not author inside the class
    /// that exists to interpret what the Ruleset does author, and would re-create the coupling
    /// <c>adr/0069</c> exists to break: construction and placement doing each other's jobs.
    /// </remarks>
    public PlacementEngine Placement => _placement;

    /// <summary>
    /// The Attended Service pass, for its three counters. <b>What it counted on the Tick just
    /// stepped</b>, so it is meaningful only on a Day boundary and zero on the other 2,047.
    /// </summary>
    /// <remarks>
    /// <b>Read the same way <see cref="LastLifeStages"/> is, and it carries that field's trap.</b>
    /// <c>Step</c> runs Tick <c>T</c> and then advances, so <see cref="Tick"/> reads <c>T + 1</c> by
    /// the time control comes back — and a caller gating on <c>Tick % PerDay == 0</c> samples one
    /// Tick <em>before</em> each boundary and reads zero for ever. ***A level is the same either side
    /// of a boundary and a flow is not***, which is what made that mistake invisible in every other
    /// dump and fatal in <c>StageDump</c>.
    /// </remarks>
    public ServiceEngine Services => _services;
    private readonly CivicEngine _civic;
    public CivicEngine Civic => _civic;

    /// <summary>
    /// <c>adr/0081</c>: a Citizen with no Workplace taking one near home, in phase 6 behind
    /// <see cref="Placement"/>.
    /// </summary>
    /// <remarks>
    /// <b>A fourth engine on <see cref="Placement"/>'s reasoning exactly</b>, and behind it on
    /// <see cref="Placement"/>'s ordering argument read one step further: a commute is anchored at a
    /// dwelling, so somebody housed this Tick can look for work on the same Tick rather than waiting a
    /// whole interval for an address they already have. The reverse order would make the delay between
    /// being housed and being employed an artefact of phase ordering, which is the class of coupling
    /// <c>02 §1.1</c> calls the determinism contract and asks to be stated rather than inherited.
    /// </remarks>
    public EmploymentEngine Employment => _employment;

    /// <summary>
    /// The Sweep family's second member: Policies sweep a population and move money, in phase 6
    /// <em>ahead of</em> <see cref="Placement"/>.
    /// </summary>
    /// <remarks>
    /// <b>A fifth engine, and the first that runs in front of the other three rather than behind
    /// them.</b> Placement, employment and the Zone Rules each read the world the pass before it
    /// left; a Policy <em>changes what an actor holds</em>, so it belongs at the head of the phase
    /// for the reason phase 5 precedes phase 6 — growth this Tick sees the diffusion this Tick, and a
    /// Household paid this Tick is judged on what it holds now. Nothing downstream reads a balance
    /// yet, which is why the ordering is stated here rather than discovered later.
    /// </remarks>
    public PolicyEngine Policies => _policies;

    /// <summary>What the most recent payday moved, or zeroes on a Tick that was not one.</summary>
    /// <remarks>
    /// <b>The last reading rather than a total</b>, so an instrument samples it and nothing
    /// accumulates across a run (<c>adr/0006</c>). ⚠ <b>It is only non-zero on a Day boundary</b>,
    /// and only then when some trade's payday fell on that Day.
    /// </remarks>
    public PayrollReading LastPayroll => _lastPayroll;

    /// <summary>What the last Life Stage sweep did. Zero on any Tick but a Day's first.</summary>
    public LifeStageReading LastLifeStages => _lastLifeStages;

    /// <summary>What the last Tick's Disaster sweep did. Every field is a delta, not a total.</summary>
    public DisasterReading LastDisasters => _lastDisasters;

    /// <summary>Tick phase 4, and the Trip Fate counters the Census drains.</summary>
    private readonly ShoppingEngine _shopping;
    public ShoppingEngine Shopping => _shopping;
    public TripEngine Trips => _trips;
    /// <summary>Commute search concurrency limit; change only between Steps on the owning caller.</summary>
    public int RouteWorkerCount { get => _commutes.RouteWorkerCount; set => _commutes.RouteWorkerCount = value; }
    public RouteBatchReading LastRouteBatch => _commutes.LastBatch;

    /// <summary>The world seed, as <see cref="Randomness.Draw"/>'s first coordinate.</summary>
    public WorldKey Key => _key;

    /// <summary>
    /// The Tick about to run. Starts at zero and advances once per <see cref="Step"/>.
    /// </summary>
    /// <remarks>
    /// An unsigned counter, per <c>CONTEXT.md</c>. At the reference rate of 16 Ticks/s a
    /// <see cref="ulong"/> outlasts any session by a margin with no useful name, so nothing in the
    /// core checks it for overflow.
    /// <para>
    /// <b>The world holds it, and this is a view of it.</b> It was a private field here, which meant a
    /// second Simulation over the same world reported a Tick of zero and every invariant that took a
    /// Tick from its caller could be told the wrong one — see
    /// <see cref="Entities.ClockTable"/> for the three mechanisms that paid for that before it moved.
    /// A Simulation is the loop; the Tick is state.
    /// </para>
    /// </remarks>
    public Ticks Tick => _world.Tick;

    /// <summary>The phase last entered. For the crash artifact, which reports where a panic landed.</summary>
    public TickPhase Phase => _phase;

    /// <summary>
    /// Whether to prove, every Tick, that <see cref="TickPhase.Decide"/> wrote nothing.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>A runtime switch rather than a build configuration.</b> The obvious implementation is
    /// <c>#if DEBUG</c>, and it is backwards for the same reason <c>02 §10</c> gives about the
    /// invariant tiers: the runs that surface this class of bug are headless balance runs, millions
    /// of Ticks long, in <b>release</b>. A guard that compiles out of the build where the bug appears
    /// is a guard aimed at the wrong build.
    /// </para>
    /// <para>
    /// ⚠ <b>OFF by default since 2026-08-30.</b> It folds every column of every table twice per Tick
    /// — <c>O(world)</c> against a phase meant to be <c>O(woken)</c> — so a default nobody named cost
    /// <b>43% of the assertion tier</b>, 5m24s against 55s on <c>FoundingTests</c>. Ask for it;
    /// <c>Borough.Headless</c> does.
    /// </para>
    /// </remarks>
    public bool VerifyDecideWritesNothing { get; set; }

    /// <summary>
    /// Advances the world by one Tick, running all eight phases in order.
    /// </summary>
    /// <remarks>
    /// <b>The ordering is the determinism contract</b> (<c>02 §1.1</c>), which is why the calls are
    /// written out straight rather than driven from a table that something could reorder at runtime.
    /// </remarks>
    public void Step(in TickInput input)
    {
        Ticks tick = _world.Tick;

        Reload(input, tick);
        ApplyInput(input, tick);
        PhaseCompleted?.Invoke(TickPhase.Input);
        Wake(tick);
        PhaseCompleted?.Invoke(TickPhase.Wake);
        Decide(tick);
        PhaseCompleted?.Invoke(TickPhase.Decide);
        Settle(tick);
        PhaseCompleted?.Invoke(TickPhase.Settle);
        Move(tick);
        PhaseCompleted?.Invoke(TickPhase.Move);
        Layers(tick);
        PhaseCompleted?.Invoke(TickPhase.Layers);
        Growth(tick);
        PhaseCompleted?.Invoke(TickPhase.Growth);
        Commit(tick);
        PhaseCompleted?.Invoke(TickPhase.Commit);

        _world.Advance();

        // The save, and it is after Advance rather than at the end of Commit for a reason measured
        // rather than argued -- see TakeSaveIfDue. Advance is the clock increment, and the clock has
        // been saved state since adr/0058.
        TakeSaveIfDue();
    }

    /// <summary>How many times the Ruleset in force has changed since this Simulation started.</summary>
    /// <remarks>
    /// <b>A count, for <c>RulesetInForce.Refusals</c>'s reason turned the other way up.</b> That one
    /// climbs when a designer is fighting the file format; this one climbs when a designer is
    /// *tuning*, which is <c>adr/0015</c>'s success condition rather than its failure one. It is also
    /// what a crash artifact needs to say how many Rulesets a session was played against.
    /// </remarks>
    public int Reloads => _reloads;

    /// <summary>The content hash of the Ruleset in force, or 0 before the first Tick.</summary>
    public ulong RulesetInForce => _inForce;

    /// <summary>
    /// What the most recent reload cost the city: Buildings derelicted, Bins dropped, Rules re-armed.
    /// </summary>
    /// <remarks>
    /// <b>The logged warning <c>02 §4.3</c> and <c>adr/0015</c> both ask for, in the only currency
    /// <c>Core</c> may use</b> (<c>adr/0002</c>). It is the <em>latest</em> transition, and it is a
    /// different question from the one <see cref="Entities.World.RulesetTrail"/> answers rather than a
    /// weaker version of it: this is what the shell warns about now, that is what a diagnosis three
    /// patches later reads. The trail is world state because <c>05 §7</c> puts it in the save; this is
    /// a Simulation's, because a warning is about the run.
    /// </remarks>
    public RulesetDegradation LastReload => _degradation;

    /// <summary>
    /// The top of Phase 0: put a different Ruleset in force, if this Tick names one.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Before the commands, not after, and a Tick has exactly one Ruleset.</b> That is what
    /// <c>InputLog.RulesetHashAt(tick)</c>'s signature already promises — it answers per Tick, not per
    /// command — so the commands in the Tick that reloads are applied under the **new** Rules. The
    /// alternative reading, swap after, would make a Tick's meaning depend on where in the Tick you
    /// asked.
    /// </para>
    /// <para>
    /// <b>There is no new verb, and <c>Command</c> was not widened.</b> A reload is a *transition*
    /// rather than an event: <c>TickInput.RulesetHash</c> is populated every Tick and was read by
    /// nothing until now, and <c>Command</c> is 12 bytes and could not have carried a hash anyway. The
    /// door argument is satisfied rather than weakened — <c>TickInput</c> **is** Phase 0's input, so
    /// nothing reaches in from outside a Tick and a replay reproduces the transition by construction.
    /// </para>
    /// <para>
    /// <b>The first Tick establishes the hash in force rather than swapping.</b> A World is
    /// constructed with its opening Ruleset and the log's first Tick names it; treating that as a
    /// transition would make every session that ever ran reload on Tick 0.
    /// </para>
    /// </remarks>
    private void Reload(in TickInput input, Ticks tick)
    {
        _phase = TickPhase.Input;

        if (!_opened)
        {
            _inForce = input.RulesetHash;
            _opened = true;
            return;
        }

        if (input.RulesetHash == _inForce)
        {
            return;
        }

        if (!_rulesets.TryResolve(input.RulesetHash, out Ruleset replacement))
        {
            // adr/0015's polarity: its revisit trigger names *silently ignoring* as the failure mode,
            // so a transition this session cannot resolve says so rather than running on regardless.
            throw new InvalidOperationException(
                $"Tick {tick.Raw} names Ruleset 0x{input.RulesetHash:X16} and this session was given "
                + $"{_rulesets.Count} Ruleset(s), none of which is it. A reload is resolved out of "
                + "the catalogue supplied to the Simulation, because Core cannot read a file.");
        }

        // The degradations live in the World because they are a pass over its rows, and the residual
        // refusal lives with them for the same reason -- what a family change breaks is the stock in
        // the Bins, which is state rather than shape. Nothing is caught here: a refused reload leaves
        // the previous Ruleset live by having changed nothing, and the throw is the diagnosis.
        _degradation = _world.Adopt(replacement, input.RulesetHash, tick, _key);
        _inForce = input.RulesetHash;
        _reloads++;
    }

    /// <summary>Phase 0 — apply the player's commands.</summary>
    /// <remarks>
    /// <b>Serial, and the only door into the simulation.</b> Everything that affects simulation state
    /// enters here, which is what makes the Input Log a complete description of a session. A mechanism
    /// that reaches into the world from outside a Tick is not merely untidy — it is a state change no
    /// replay can reproduce and no State Hash divergence can explain.
    /// </remarks>
    private void ApplyInput(in TickInput input, Ticks tick)
    {
        _phase = TickPhase.Input;

        foreach (Command command in input.Commands)
        {
            Apply(command, tick);
        }
    }

    /// <summary>Applies one command. The verb table of <c>01 §2</c>, as far as it is built.</summary>
    /// <remarks>
    /// <b>An unknown verb throws rather than being skipped.</b> Skipping it would produce a run that
    /// diverges from the log that describes it while reporting success, which is the one outcome this
    /// slice exists to make impossible.
    /// </remarks>
    private void Apply(Command command, Ticks tick)
    {
        switch (command.Kind)
        {
            case CommandKind.Zone:
                // 02 §2.2: Lots are **generated, not painted**. Until 5a-bis this line created exactly
                // one Lot at the command's coordinates, and said so -- there was no Street network to
                // carve against, so painting a *region* would have stood in for more of 5a than
                // painting one did, and every Lot it invented would have been one the real subdivider
                // would have refused.
                //
                // Now the verb zones the **block** the named Tile falls in, and the subdivider carves
                // it against its own four faces. A block with no Street on any face yields **no Lots
                // at all**, which is that section's third rule and the whole of what makes a bad
                // street layout punish the player mechanically rather than through a penalty number.
                LotSubdivider.SubdivideAt(_world, command.East, command.North, command.Zone);
                break;

            case CommandKind.Connect:
                // 01 §2's fifth verb, declared since slice 5 and thrown until now. adr/0077 settles
                // what it is: one Street Segment on the lattice edge leaving the named intersection.
                ApplyConnect(command);
                break;

            case CommandKind.Populate:
                // Spike S0's verb, and one of the two here that are an instrument rather than a
                // player's. It is applied like any other because that is the point of it: a
                // population that arrived any other way would be outside the log that claims to
                // describe the session.
                SyntheticCity.PopulateInto(_world, _key, tick);
                break;

            case CommandKind.Ground:
                // adr/0090's generator remit as a verb -- terrain, Woodland, water and the Hazard
                // Regions, and nothing that stands on them. It is Populate's ground half without
                // Populate's lattice, Lots and people, and it is what makes the world that ADR
                // describes reachable: before the split the only worlds available were a generated
                // city or a bare map, and the design's own world was neither.
                //
                // ⚠ AN ALTERNATIVE TO Populate AND NOT A PREDECESSOR. PopulateInto lays the ground
                // itself, so a world that took this verb refuses that one by name -- see
                // SyntheticCity.RefuseIfGrounded, which asks what is standing rather than carrying
                // a flag.
                SyntheticCity.GroundInto(_world, _key);
                break;

            case CommandKind.People:
                // Ground's other half, and the verb that makes a player-built world liveable. Ground
                // lays terrain, Woodland, water and hazard and stops there, so a world reached that
                // way gets its Streets from Connect and its Lots from Zone -- and then nothing was
                // ever built on them, because the chain is Households -> the Unplaced Pool ->
                // placement -> Buildings and an empty world has an empty Pool. plans/0045 row 21.
                //
                // ⚠ IT IS Populate's PEOPLE HALF AND NOT A SECOND Populate. What separates the two
                // is the LAND: Populate lays the lattice and carves the Lots itself, and this builds
                // on whatever is standing. So a world takes Populate, or it takes Ground and this.
                //
                // ⚠ AND IT DOES NOT EVALUATE THE DISTRICTS, WHERE PopulateInto DOES. That call is in
                // PopulateInto rather than at its Command because most of the suite populates a world
                // directly and never steps it; a command applies in phase 0 of a real Tick, and
                // adr/0134's re-evaluation is phase 6's own cadence on the city this leaves standing.
                ApplyPeople(tick);
                break;

            case CommandKind.Trip:
                // adr/0080's verb. Phase 4 is built ahead of anything that generates a Trip, because
                // every generator the corpus names is unmilestoned -- so a Trip enters through the log
                // exactly as a population does, and for the same reason: what arrives any other way is
                // a state change no replay reproduces.
                ApplyTrip(command, tick);
                break;

            case CommandKind.Arrive:
                // adr/0128's door. The gate ships at 11 and what decides to arrive ships at 16, so
                // the only thing that admits anybody is a command -- Populate's position, taken for
                // Populate's reason.
                ApplyArrive(command, tick);
                break;

            case CommandKind.Demolish:
                // 01 §2's sixth verb, and adr/0091's. Over abandoned stock only -- clearing occupied
                // ground is a compulsory purchase whose price that ADR refuses to compose, so the
                // half that could ship is the half with nobody left in it to compensate.
                ApplyDemolish(command, tick);
                break;

            case CommandKind.Govern:
                // 01 section 2's fourth verb, and the first whose effect outlives the command: what
                // it sets is saved and hashed state in PolicyTable, not a write back into Ruleset
                // data a reload would undo.
                ApplyGovern(command);
                break;

            case CommandKind.Service:
                // 01 section 2's third verb, and the design's one acknowledged placement exception:
                // pillar 3 is govern-don't-place, and a school appearing wherever the simulation
                // likes is bad play. adr/0032 is what let it ship -- a Service needs no catchment
                // key, because coverage is composed from the reachability the Trips already use.
                ApplyService(command, tick);
                break;

            case CommandKind.None:
            default:
                throw new InvalidOperationException(Explain(Refusal.VerbNotApplied, command));
        }
    }

    /// <summary>
    /// <b>Why this command would not apply, as a number</b> — <see cref="Refusal.None"/> when it
    /// would.
    /// </summary>
    /// <remarks>
    /// <para>
    /// 🔴 <b>The applier and this answer are ONE predicate, and that is the whole of the design.</b>
    /// Each verb's checks moved into a <c>Refuse*</c> method that returns a code and hands back what
    /// it resolved on the way; <see cref="Apply"/> throws on a non-zero code and this returns it. A
    /// front end asking <em>would this be refused</em> is therefore asking the code that refuses,
    /// rather than a paraphrase of it that is free to drift — <c>plans/0012</c> <b>Cause 1</b>, which
    /// the shell had already committed three times over.
    /// </para>
    /// <para>
    /// ⚠ <b>It is a query and writes nothing</b>, so a caller may ask it every frame; and it is
    /// <c>O(Lots)</c> for <c>Trip</c>, <c>Demolish</c> and <c>Service</c>, because resolving a Tile
    /// to what stands on it is a scan and there is no index over Lots. ***That is the applier's own
    /// cost paid twice rather than a new one***, and it is paid per click.
    /// </para>
    /// <para>
    /// ⚠ <b>An answer of <see cref="Refusal.None"/> is good for exactly as long as the world stands
    /// still.</b> A command applies at the top of a Tick, so a caller that asks, steps, and then
    /// sends is asking about a city that no longer exists. The shell asks and queues in one act, and
    /// nothing steps in between.
    /// </para>
    /// <para>
    /// ⚠ <b><c>Zone</c> and <c>Populate</c> can be refused by nothing and that is not an oversight.</b>
    /// A block with no Street on any face yields no Lots — <c>02 §2.2</c>'s third rule, and the
    /// mechanism by which a bad street layout punishes the player. ***It is an outcome and not a
    /// refusal***, and a front end that greyed the click out would be hiding the lesson.
    /// </para>
    /// </remarks>
    public Refusal Refuses(Command command) => command.Kind switch
    {
        CommandKind.Zone or CommandKind.Populate => Refusal.None,
        CommandKind.Connect => RefuseConnect(command, out _),
        CommandKind.Trip => RefuseTrip(command, out _, out _, out _),
        CommandKind.Arrive => RefuseArrive(command, out _),
        CommandKind.Govern => RefuseGovern(command),
        CommandKind.Demolish => RefuseDemolish(command, out _),
        CommandKind.Service => RefuseService(command, out _, out _),
        CommandKind.People => RefusePeople(),
        _ => Refusal.VerbNotApplied,
    };

    /// <inheritdoc cref="ApplyConnect"/>
    private Refusal RefuseConnect(Command command, out ConnectPayload payload)
    {
        payload = ConnectPayload.Decode(command.Zone);

        return payload.Kind != RoadKind.Street ? Refusal.ConnectRoadKindIsNotStreet
            : _world.Roads.Streets.BlockTiles <= 0 ? Refusal.ConnectWorldHasNoLattice
            : Refusal.None;
    }

    /// <inheritdoc cref="ApplyTrip"/>
    private Refusal RefuseTrip(Command command, out int origin, out int destination, out int citizen)
    {
        origin = -1;
        destination = -1;
        citizen = -1;

        if (!_world.Rules.Trips.Runs)
        {
            return Refusal.TripRulesetStatesNoTrips;
        }

        int block = _world.Roads.Streets.BlockTiles;

        if (block <= 0)
        {
            return Refusal.TripWorldHasNoLattice;
        }

        TripPayload payload = TripPayload.Decode(command.Zone);
        int column = _world.Roads.Streets.Lattice.LineAt(command.East.Raw);
        int row = _world.Roads.Streets.Lattice.LineAt(command.North.Raw);

        origin = OccupiedBuildingIn(column, row);
        destination = OccupiedBuildingIn(column + payload.BlocksEast, row + payload.BlocksNorth);

        if (origin < 0 || destination < 0)
        {
            return Refusal.TripBlockHoldsNobody;
        }

        if (origin == destination)
        {
            return Refusal.TripEndpointsAreOneBuilding;
        }

        citizen = FirstResidentOf(origin);

        return citizen < 0 ? Refusal.TripOriginHoldsNoCitizen : Refusal.None;
    }

    /// <inheritdoc cref="ApplyArrive"/>
    private Refusal RefuseArrive(Command command, out int gate)
    {
        gate = GateOn(command.East, command.North);

        return gate < 0 ? Refusal.ArriveNoGateOnThatTile : Refusal.None;
    }

    /// <inheritdoc cref="ApplyGovern"/>
    private Refusal RefuseGovern(Command command)
    {
        int policy = command.Zone;

        return policy >= _world.Rules.Policies.Length ? Refusal.GovernNoSuchPolicy
            : policy >= _world.Policies.Rows.SlotCount ? Refusal.GovernPolicyNotInThisWorld
            : _world.Policies.Key[policy] == 0 ? Refusal.GovernPolicyHasNoName
            : Refusal.None;
    }

    /// <inheritdoc cref="ApplyDemolish"/>
    private Refusal RefuseDemolish(Command command, out int building)
    {
        building = BuildingOn(command.East, command.North);

        return building < 0 ? Refusal.DemolishNoBuildingOnThatTile
            : !_world.Buildings.IsAbandoned(building) ? Refusal.DemolishBuildingIsOccupied
            : Refusal.None;
    }

    /// <inheritdoc cref="ApplyService"/>
    private Refusal RefuseService(Command command, out byte kind, out int lot)
    {
        kind = (byte)command.Zone;
        lot = -1;

        if (!_world.Rules.Declares(kind))
        {
            return Refusal.ServiceKindNotDeclared;
        }

        if (_world.Rules.Kind(kind).Serves == Need.None)
        {
            return Refusal.ServiceKindServesNothing;
        }

        lot = VacantLotOn(command.East, command.North);

        return lot < 0 ? Refusal.ServiceNoVacantLotOnThatTile : Refusal.None;
    }

    /// <inheritdoc cref="ApplyPeople"/>
    /// <remarks>
    /// ⚠ <b>The two arms are <c>SyntheticCity.PeopleInto</c>'s own two throws, in its order.</b> That
    /// method guards itself and will go on doing so — it is called directly by half the suite — so
    /// this is a second reader of the same two facts rather than a second rule. ***What it buys is a
    /// front end that declines the click***: an exception out of phase 0 aborts a Tick half way, and
    /// on this verb both failures are things a hand at the keyboard reaches in the ordinary course of
    /// playing — populating twice, or populating before zoning anything.
    /// </remarks>
    private Refusal RefusePeople() =>
        _world.Citizens.Rows.LiveCount != 0 ? Refusal.PeopleWorldAlreadyHasAPopulation
        : _world.Lots.Rows.LiveCount <= 0 ? Refusal.PeopleWorldHasNoLots
        : Refusal.None;

    /// <summary>The refusal as a sentence for a <b>crash artefact</b>, which is a different reader.</summary>
    /// <remarks>
    /// <para>
    /// ⚠ <b>This is not the leak <c>CLAUDE.md</c> names and the distinction is the whole point.</b>
    /// That rule is about a method returning <em>a formatted string because a panel wanted one</em>;
    /// nothing here is returned. These compose the message of an exception that ends the run, whose
    /// reader is whoever is holding the log — so it names the ADR, the successor mechanism and the
    /// Ruleset key, none of which belongs on a player's screen. ***A player's sentence is the shell's
    /// and is built from <see cref="Refusal"/>*** (<see cref="Refuses"/>).
    /// </para>
    /// <para>
    /// ⚠ <b>Every word below was already in this file</b>, moved rather than written. What changed is
    /// that the message is now selected by the same code the guard reads, so the two cannot describe
    /// different rules.
    /// </para>
    /// </remarks>
    private string Explain(Refusal refusal, Command command) => refusal switch
    {
        Refusal.VerbNotApplied =>
            $"command kind {(ushort)command.Kind} is declared but not applied in this slice.",

        Refusal.ConnectRoadKindIsNotStreet =>
            $"connect names road kind {(int)ConnectPayload.Decode(command.Zone).Kind}, and only "
            + "Street is applied. adr/0077 defers Arterials and Junction pieces by name: an Arterial "
            + "is a spline with many control points and is not one command, and a Junction piece "
            + "needs the authored library adr/0014 calls content. Neither is missing by oversight.",

        Refusal.ConnectWorldHasNoLattice =>
            "connect names a Street lattice this world does not have. The spacing comes from "
            + "the Ruleset's [roads] block_tiles, and a Ruleset that declares no [roads] is a "
            + "world with no road network to edit.",

        Refusal.TripRulesetStatesNoTrips =>
            "trip is commanded against a Ruleset that declares no [trips] table, so what a "
            + "crossing costs and where the Commute Budget falls are both unauthored. The verb "
            + "refuses rather than costing the journey at zero, because zero is a legitimate "
            + "crossing cost -- a city where the shop opposite is the shop next door -- and a "
            + "placeholder inside the range of legitimate answers cannot announce itself.",

        Refusal.TripWorldHasNoLattice =>
            "trip names a Street lattice this world does not have. A Building's Access Point is "
            + "derived through its Lot, a Lot is carved out of a block, and the spacing comes from "
            + "the Ruleset's [roads] block_tiles -- so a Ruleset declaring no [roads] is a world "
            + "in which nobody has an address to travel between.",

        Refusal.TripBlockHoldsNobody => TripBlocks(command),

        Refusal.TripEndpointsAreOneBuilding =>
            "trip names one Building as both endpoints. A Trip to where you already are is not a "
            + "degenerate Trip, it is a command with a wrong payload -- the block delta is zero, or "
            + "both blocks resolved to the same Building because only one is occupied.",

        Refusal.TripOriginHoldsNoCitizen =>
            "trip names an origin Building with no Citizen in it. A Traveller is a cursor over a "
            + "Citizen's journey (adr/0075) and there is nobody here to be one.",

        Refusal.ArriveNoGateOnThatTile =>
            $"arrive names Tile ({command.East.Raw}, {command.North.Raw}), where no Outside "
            + "Connection stands. The verb refuses rather than admitting anybody through the "
            + "nearest gate, because the edge a Household entered by selects its Hinterland "
            + "(adr/0088) -- so a substituted gate does not misplace an arrival, it changes "
            + "which market it came from.",

        Refusal.GovernNoSuchPolicy =>
            $"Govern names Policy {command.Zone} and this Ruleset declares "
            + $"{_world.Rules.Policies.Length}. A Policy is named by its position in declaration "
            + "order, and the Ruleset in force at the Tick a command is applied is what that "
            + "position is resolved against.",

        Refusal.GovernPolicyNotInThisWorld =>
            $"Govern names Policy {command.Zone} and this world holds "
            + $"{_world.Policies.Rows.SlotCount} governable row(s). The table is sized at world "
            + "creation and PolicyTable.Adopt never resizes it, so a Policy that arrived on a "
            + "reload which grew the set cannot be governed in this world.",

        Refusal.GovernPolicyHasNoName =>
            $"Govern names Policy {command.Zone} and that [[policy]] table states no name. A governed "
            + "amount is saved state that has to survive a reload, and a name is the only thing "
            + "that survives a renumbering — see Ruleset.PolicyKeys. Name the table to govern it.",

        Refusal.DemolishNoBuildingOnThatTile =>
            $"demolish names Tile ({command.East.Raw}, {command.North.Raw}), where no Building "
            + "stands. The verb refuses rather than clearing the nearest one, because "
            + "[lots] lots_per_segment is five and a substituted target is somebody else's "
            + "house -- a mistyped command must not be indistinguishable from the demolition "
            + "somebody meant.",

        Refusal.DemolishBuildingIsOccupied =>
            $"demolish names Tile ({command.East.Raw}, {command.North.Raw}), where a Building "
            + "still stands occupied. adr/0091 makes clearing occupied ground a COMPULSORY "
            + "PURCHASE paid at market value from the land value Map Layer to whoever is "
            + "displaced, and refuses to compose that price -- so the successor is named and "
            + "unbuilt rather than missing, and it is blocked on the land value target. "
            + "Abandoned stock is the half that needs no compensation, because there is nobody "
            + "left in it to compensate.",

        Refusal.ServiceKindNotDeclared =>
            $"service names Building kind {(byte)command.Zone}, which this Ruleset does not declare. "
            + "The kind is the verb's whole payload beside the Tile, so an id nothing declares is a "
            + "command with no subject rather than a placement to fall back from.",

        Refusal.ServiceKindServesNothing =>
            $"service names Building kind {(byte)command.Zone}, which declares no `serves` key and is "
            + "therefore not a service Building. 01 section 5 makes this verb the design's ONE "
            + "placement exception -- the player places service Buildings and only those -- so "
            + "an ordinary kind is refused here rather than placed. Every other kind reaches the "
            + "ground through a Zone Rule, which is the city filling in a permission set the "
            + "player painted.",

        Refusal.ServiceNoVacantLotOnThatTile =>
            $"service names Tile ({command.East.Raw}, {command.North.Raw}), where there is no "
            + "vacant Lot. The Tile is matched exactly rather than resolved to the block, on "
            + "demolish's reasoning: [lots] lots_per_segment is five, so `the Lot in this block` "
            + "names up to twenty of them, and a school landing on a neighbour's plot because "
            + "the click resolved to the first is worse than a refusal. A Lot holding a Building "
            + "-- a standing one or an adr/0091 shell -- is not vacant; demolish first.",

        Refusal.PeopleWorldAlreadyHasAPopulation =>
            "people is commanded on a world that already holds one, and a synthetic population is "
            + "not something to add a second of. It is world creation, so it belongs at Tick 0 and "
            + "once -- a second application builds a city of twice the configured size into tables "
            + "sized from that configuration, which is a run that answers the sizing question with "
            + "the wrong number and reports success.",

        Refusal.PeopleWorldHasNoLots =>
            "people is commanded on a world with no Lots, so there is nowhere to put anybody. A city "
            + "reached through CommandKind.Ground gets its Streets from Connect and its Lots from "
            + "Zone, which carves against the Street faces that are standing -- so lay the Streets, "
            + "zone the blocks, then populate. It refuses rather than making no rows, because a "
            + "populator that answers the sizing question with an empty world and reports success is "
            + "the one outcome nothing downstream can tell from a small city.",

        _ => $"command kind {(ushort)command.Kind} was refused with reason {(ushort)refusal}, which "
            + "this build has no diagnosis for.",
    };

    /// <summary>The two block coordinates a refused <c>Trip</c> named, spelled out.</summary>
    private string TripBlocks(Command command)
    {
        TripPayload payload = TripPayload.Decode(command.Zone);
        int column = _world.Roads.Streets.Lattice.LineAt(command.East.Raw);
        int row = _world.Roads.Streets.Lattice.LineAt(command.North.Raw);

        return $"trip from block ({column}, {row}) to block ({column + payload.BlocksEast}, "
            + $"{row + payload.BlocksNorth}) names a block with no occupied Building in it. The "
            + "verb refuses rather than substituting a nearby one, because a substituted endpoint "
            + "makes a mistyped command indistinguishable from the Trip somebody meant.";
    }

    /// <summary>
    /// Lays or bulldozes one Street, then re-parcels what the edit changed.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>This is the first thing in the project that edits the Road Graph in a running world</b>, and
    /// therefore the first thing that has ever driven <c>adr/0012</c>'s per-Segment Epoch by anything
    /// a player did. Until now the Epoch was exercised by unit tests and by nothing else, because the
    /// generator runs at world creation.
    /// </para>
    /// <para>
    /// <b>Re-subdivision runs only when the graph actually changed</b>, which is what makes a repeated
    /// <c>connect</c> free. A log replays a player's clicks, and a player clicking a Tile that already
    /// has a road on it is an ordinary event rather than an error to die on.
    /// </para>
    /// <para>
    /// <b>Anything that is not a Street is refused by name.</b> An Arterial is a spline with many
    /// control points and is not one command at all; a Junction piece needs a piece library
    /// (<c>adr/0014</c>: <em>"content with three faces each"</em>). Both are deferred with a named
    /// successor rather than silently missing, which is the distinction <c>adr/0070</c> exists to
    /// keep — only a <em>refused</em> absence is evidence a later sitting may reason from.
    /// </para>
    /// </remarks>
    private void ApplyConnect(Command command)
    {
        Refusal refusal = RefuseConnect(command, out ConnectPayload payload);

        if (refusal != Refusal.None)
        {
            throw new InvalidOperationException(Explain(refusal, command));
        }

        // Snapped down to the lattice, which is what adr/0014's "Streets snap to the grid" means once
        // the graph is nodes at intersections rather than Tiles: the player names a place and the
        // edit lands on the edge leaving the intersection at or below it.
        //
        // ⚠ THE SNAP IS THE LATTICE'S OWN and no longer a divide, so a player's click lands on the
        // line below it however the lines are spaced. StreetGrid.IntersectionTile's remark -- the
        // snap stays the city's and the aim stays the hand's -- is what makes that safe: the shell
        // aims with NearestEdge and addresses with IntersectionTile, and both read this lattice.
        int column = _world.Roads.Streets.Lattice.LineAt(command.East.Raw);
        int row = _world.Roads.Streets.Lattice.LineAt(command.North.Raw);

        bool changed = payload.Action == ConnectAction.Lay
            ? _world.Roads.LayStreet(column, row, payload.Axis)
            : _world.Roads.BulldozeStreet(column, row, payload.Axis);

        if (!changed)
        {
            return;
        }

        // The graph edit has already rebuilt the Street lattice; frontage follows it, and only then
        // can the subdivider tell which Lots have lost their Street and which faces have gained one.
        _world.Frontage.Rebuild(_world.Lots, _world.Roads.Streets);

        // The Parking Shed's supply index is keyed on Segment slots, so a graph edit invalidates it
        // for the same reason it invalidates frontage -- and it must be rebuilt BEFORE the subdivider
        // runs, because resubdividing condemns Buildings and a condemnation unlists their Car Parks.
        // ⚠ Bulldozing frees the Segment row, which severs every Car Park Address naming it, and
        // CarParkResidency.Remove finds a Car Park's list *through* that Address -- so an unlist
        // attempted after the sever silently does nothing and leaves the row listed as it is freed.
        // The recycled slot is then inserted into the same list twice, which self-links it. This is
        // where BuildingsInCells' shape stops being a guide: a Cell never goes away, and a Segment
        // does.
        _world.CarParksOnSegments.Rebuild(_world.CarParks, _world.Roads.Segments);

        LotSubdivider.Resubdivide(_world);
    }

    /// <summary>
    /// <c>adr/0080</c>'s verb: put one Citizen on the road between two Buildings the operator names.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Every refusal here is a refusal rather than a degradation</b>, on the <c>Scope.Pool</c> and
    /// <c>--zones</c> precedent. A command naming an empty block could plausibly be answered with
    /// <em>the nearest Building instead</em>, and that answer would make an operator's typo indis­tin­guish­able
    /// from a Trip they meant — which is the whole class of defect a commanded Trip exists to avoid.
    /// </para>
    /// <para>
    /// <b>What is <em>not</em> a refusal is a Building with no front door.</b> <c>adr/0079</c> settles
    /// that a Building outlives its frontage and an Address that has none is <em>a hole the Trip model
    /// reports</em> — so that is a Trip whose Fate is <see cref="TripFate.NoRouteFound"/>, and it is the
    /// case this verb exists to be able to produce on demand.
    /// </para>
    /// <para>
    /// <b>The crossing cost and the Commute Budget are read from the <c>[trips]</c> table</b>
    /// (5b-bis task 3), which is what turns this from a Trip that is always made into a Trip that can
    /// be refused. A Ruleset declaring no <c>[trips]</c> is refused outright rather than costed at
    /// zero: zero is a legitimate crossing cost — <c>adr/0074</c>'s rung 1, what the corpus had by
    /// omission — so a zero standing in for <em>nobody has authored one</em> is the placeholder
    /// session F named, indistinguishable from a decision.
    /// </para>
    /// <para>
    /// <b>A city with no Commute Budget refuses nothing for its length</b>, which is what an omitted
    /// <c>commute_budget_minutes</c> states. That is the city whose cost distribution this milestone
    /// has to measure before the number can be chosen, so
    /// <see cref="TripFate.ExceededCommuteBudget"/> is reachable here and unreached until a Ruleset
    /// states one.
    /// </para>
    /// </remarks>
    private void ApplyTrip(Command command, Ticks tick)
    {
        Refusal refusal = RefuseTrip(command, out int origin, out int destination, out int citizen);

        if (refusal != Refusal.None)
        {
            throw new InvalidOperationException(Explain(refusal, command));
        }

        // The Citizen's own mode, not a walk. adr/0080 demotes this command to a test affordance
        // rather than the only door, and an affordance that travels differently from the city it is
        // probing is an instrument measuring itself.
        TravelMode mode = _world.ModeOf(citizen);

        _trips.Start(citizen, origin, destination, mode, TripPurpose.Commanded, tick);
    }

    /// <summary>
    /// The first occupied Building in a block of the Street lattice, or <c>-1</c> if it holds none.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⚠ <b>This is an <c>O(Lots)</c> scan, and it is the call site of the query milestone 5b-bis has
    /// to build.</b> There is no index from a place to the Buildings near it anywhere in
    /// <c>Borough.Core</c> — <see cref="Space.CellResidency"/> indexes Map Layer cells rather than
    /// entities, and <see cref="Space.Frontage"/> maps a Lot to its Segment in one direction only. The
    /// §A sitting found that all three candidate Trip generators need one and no document had named it
    /// (<c>adr/0081</c>).
    /// </para>
    /// <para>
    /// <b>It is affordable here for a reason that will not survive a generator.</b> This runs in Phase 0,
    /// once per command a human wrote, so the scan is paid per keystroke rather than per Tick. A
    /// generator runs per Household per occasion, and the same scan there is <c>O(Lots x Households)</c>
    /// — which is why the index is 5b-bis's <em>first</em> task rather than a detail inside its
    /// generator. <b>Left deliberately un-optimised</b>: a local index built here would remove the
    /// pressure that gets the shared one built, which is <c>adr/0073</c>'s finding exactly.
    /// </para>
    /// <para>
    /// <b>Slot order is a deterministic total order and the scan takes the first match</b>, which is the
    /// discipline <see cref="World"/>'s own rebuild loops use. It is not an identity — nothing stores
    /// the slot — so <c>BOR0206</c> is not in play.
    /// </para>
    /// </remarks>
    private int OccupiedBuildingIn(int column, int row)
    {
        BlockLattice lattice = _world.Roads.Streets.Lattice;
        LotTable lots = _world.Lots;

        for (int slot = 0; slot < lots.Rows.SlotCount; slot++)
        {
            if (!lots.Rows.IsLive(slot) || lots.IsVacant(slot))
            {
                continue;
            }

            if (lattice.LineAt(lots.East[slot].Raw) == column
                && lattice.LineAt(lots.North[slot].Raw) == row)
            {
                return lots.BuildingOn(slot);
            }
        }

        return -1;
    }

    /// <summary>
    /// Admits up to the requested number of Households through the gate at the named Tile.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>A Tile with no gate on it throws, and a gate that is full does not.</b> The two failures
    /// are different in kind: naming the wrong place is a command with a wrong payload, and
    /// <c>ApplyTrip</c>'s refusals are written against exactly that — ***a substituted endpoint makes
    /// a mistyped command indistinguishable from the one somebody meant***. A gate admitting fewer
    /// than were asked for is <c>[[building]] arrivals_per_day</c> binding, which is the mechanism
    /// working and the thing <c>plans/0002</c> §D1 wants to be able to read.
    /// </para>
    /// <para>
    /// <b>The Tile is matched against the Lot exactly rather than against the block it falls in</b>,
    /// which is where this parts company from <see cref="OccupiedBuildingIn"/>. On the shipped
    /// lattice <b>one block carries two edges</b> — <c>SyntheticCity.CarveEdgeBlock</c> puts the west
    /// and south gates in the block at the origin — so *the gate in this block* names two Buildings
    /// standing in two different Hinterlands, and picking either would be inventing the answer to
    /// which market the arrivals came from.
    /// </para>
    /// <para>
    /// <b>A zero count is a command that does nothing, and it is not refused.</b> The loop runs no
    /// iterations. That is deliberate on <c>ApplyConnect</c>'s terms — a log replays what happened,
    /// and a verb that dies on a degenerate payload makes a replay less faithful than the session it
    /// describes.
    /// </para>
    /// </remarks>
    private void ApplyArrive(Command command, Ticks tick)
    {
        ArrivePayload payload = ArrivePayload.Decode(command.Zone);

        Refusal refusal = RefuseArrive(command, out int gate);

        if (refusal != Refusal.None)
        {
            throw new InvalidOperationException(Explain(refusal, command));
        }

        Handle<Building> handle = _world.Buildings.Rows.At(gate);

        for (int i = 0; i < payload.Households; i++)
        {
            // Stops on the first refusal rather than trying the rest. The only refusal reachable
            // here is the daily ceiling -- the gate resolved a line above -- and a ceiling that has
            // bound once binds for the remainder of the Day.
            if (!_world.TryArrive(handle, payload.LifeStage, payload.Citizens, tick, out _))
            {
                break;
            }
        }
    }

    /// <summary>
    /// Sets one declared Policy's amount, for as long as this world stands.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Two refusals, and both are about identity rather than about the number.</b> An index past
    /// the declared set names no Policy at all; a Policy whose <c>[[policy]]</c> table states no
    /// <c>name</c> keys to zero, and a governed row that cannot be matched across a reload would
    /// re-attach to whatever landed at its index next. ***The second is refused here rather than at
    /// the loader***, because requiring a name of every Ruleset would buy a refusal for a case no
    /// shipped file writes.
    /// </para>
    /// <para>
    /// ⚠ <b>The amount is not validated and must not be.</b> A Policy's transfer states a direction
    /// (<c>from</c> and <c>to</c>), so a quantity cannot leak whatever its size, and a levy a player
    /// has set ruinously high is a city they have governed badly rather than an input the simulation
    /// should decline. <c>adr/0015</c>'s acceptance test is that a rate moves freely.
    /// </para>
    /// </remarks>
    private void ApplyGovern(Command command)
    {
        Refusal refusal = RefuseGovern(command);

        if (refusal != Refusal.None)
        {
            throw new InvalidOperationException(Explain(refusal, command));
        }

        _world.Policies.Govern(command.Zone, command.East.Raw);
    }

    /// <summary>
    /// Clears an abandoned Building off the Lot at exactly the named Tile.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>The first player act in this design that removes a Building</b>, and
    /// <c>adr/0091</c>'s sixth verb arriving over the narrow half of its own scope. The wide half —
    /// clearing ground somebody still lives on — is a <b>compulsory purchase</b> that pays market
    /// value read off the land value Map Layer, and that ADR settles the shape while deliberately
    /// refusing the composition. So it is blocked on the land value target, which is a named hole in
    /// <c>MapLayers</c>, and not on anything here.
    /// </para>
    /// <para>
    /// <b>A standing Building is refused by name with its successor beside it</b>, which is
    /// <c>adr/0070</c>'s discipline rather than caution: an absence a later sitting may reason from
    /// has to read <em>refused-for-now</em> rather than <em>silently missing</em>, and those are
    /// different premises. ⚠ <b>The alternative — demolishing it for free — is the one thing this
    /// must not do</b>, because a free bulldozer is a verb no part of the city governs, and
    /// <c>adr/0091</c>'s whole argument is that the price is what makes clearing a decision.
    /// </para>
    /// <para>
    /// <b>Nothing is paid here and nothing is owed</b>: the Building is empty by construction, so
    /// there is no Household to compensate and no [`adr/0024`] transfer to conserve. ⚠ <b>That is
    /// what makes this half shippable and is also its limit</b> — this verb can never be the one a
    /// player uses on a district they want to redevelop.
    /// </para>
    /// <para>
    /// <b>It is a shortcut through <c>adr/0172</c>'s clock and not a replacement for it.</b> A shell
    /// falls on its own after <c>[[building]] collapses_after_days</c>; this takes the Lot back
    /// sooner. ***A player is not a sink and this verb does not make one*** — the measurement that
    /// settled that is in the ADR, and it is a city that dies with every invariant green.
    /// </para>
    /// <para>
    /// <b>Repeating it is free rather than fatal</b>, on <see cref="ApplyConnect"/>'s reasoning: a log
    /// replays a player's clicks, and clicking a Lot whose shell has already fallen — on its own
    /// clock, between the click and the replay — is an ordinary event. ⚠ <b>The refusals below are
    /// the ones that mean the command named the wrong place</b>, which is the distinction
    /// <see cref="ApplyTrip"/> draws and this inherits.
    /// </para>
    /// </remarks>
    private void ApplyDemolish(Command command, Ticks tick)
    {
        Refusal refusal = RefuseDemolish(command, out int building);

        if (refusal != Refusal.None)
        {
            throw new InvalidOperationException(Explain(refusal, command));
        }

        _world.DestroyBuilding(_world.Buildings.Rows.At(building), tick);
    }

    /// <summary>
    /// Raises Buildings, Households and Citizens on whatever Lots stand — <c>CommandKind.People</c>.
    /// </summary>
    /// <remarks>
    /// <b>The whole of it is one call, and that is the point of the row that added it.</b>
    /// <c>SyntheticCity.PeopleInto</c> was split out of <c>PopulateInto</c> on 2026-08-15 for exactly
    /// this case and its own remark named it — <em>"a city whose Streets were laid by
    /// <c>CommandKind.Connect</c> wants the people half without the land half and could not ask for
    /// it"</em> — and then nothing outside the test suite could ask, because there was no verb. The
    /// guard above it is the shell's rather than the city's: the city throws either way.
    /// </remarks>
    private void ApplyPeople(Ticks tick)
    {
        Refusal refusal = RefusePeople();

        if (refusal != Refusal.None)
        {
            throw new InvalidOperationException(
                Explain(refusal, new Command(CommandKind.People, default, default)));
        }

        SyntheticCity.PeopleInto(_world, _key, tick);
    }

    /// <summary>
    /// Raises one service Building on the vacant Lot at exactly the named Tile.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>The design's one placement exception, and it is narrow on purpose.</b> <c>01 §5</c>:
    /// <em>"Pillar 3 is govern-don't-place, and a fire station appearing wherever the simulation
    /// likes is bad play — so the player places service Buildings, and <b>only those</b>."</em> A
    /// kind that serves no Need is refused by name here, which is what keeps the exception from
    /// becoming a general <em>place any Building</em> verb by the back door.
    /// </para>
    /// <para>
    /// ⚠ <b>It does not consult the Lot's Zone, and that is the exception being an exception.</b>
    /// Every other route to a standing Building goes through a Zone Rule, which builds only where the
    /// permission set admits its kind — the player paints permissions and the city fills them in.
    /// This verb is the one place a Building arrives because somebody put it there, so asking a
    /// permission set would be asking the player to zone for a school before placing one, which is
    /// two verbs for one decision.
    /// </para>
    /// <para>
    /// <b>Every refusal is a throw and none is a silent no-op</b>, on <c>ApplyDemolish</c>'s rule: a
    /// command in an Input Log is a thing somebody did, and a verb that quietly declines leaves a
    /// replay that diverges from the session with nothing in the artefact to say why.
    /// </para>
    /// </remarks>
    private void ApplyService(Command command, Ticks tick)
    {
        Refusal refusal = RefuseService(command, out byte kind, out int lot);

        if (refusal != Refusal.None)
        {
            throw new InvalidOperationException(Explain(refusal, command));
        }

        _world.CreateBuilding(_world.Lots.Rows.At(lot), kind, tick, _key);
    }

    /// <summary>The vacant Lot at exactly this Tile, or <c>-1</c>.</summary>
    /// <remarks>
    /// <b><see cref="BuildingOn"/>'s complement, and exact for the same reason.</b> The two together
    /// are the whole of how a Tile resolves to ground in this file: one finds what stands there and
    /// one finds room, and neither will substitute a neighbour.
    /// </remarks>
    private int VacantLotOn(Tiles east, Tiles north)
    {
        LotTable lots = _world.Lots;

        for (int slot = 0; slot < lots.Rows.SlotCount; slot++)
        {
            if (lots.Rows.IsLive(slot)
                && lots.IsVacant(slot)
                && lots.East[slot].Raw == east.Raw
                && lots.North[slot].Raw == north.Raw)
            {
                return slot;
            }
        }

        return -1;
    }

    /// <summary>
    /// The Building standing on the Lot at exactly this Tile, or <c>-1</c>.
    /// </summary>
    /// <remarks>
    /// <b><see cref="GateOn"/> without the kind test</b>, and exact for its reason rather than by
    /// analogy: a block carries up to twenty Lots, so <em>the Building in this block</em> is not a
    /// thing a verb that removes one may resolve.
    /// </remarks>
    private int BuildingOn(Tiles east, Tiles north)
    {
        LotTable lots = _world.Lots;

        for (int slot = 0; slot < lots.Rows.SlotCount; slot++)
        {
            if (!lots.Rows.IsLive(slot)
                || lots.IsVacant(slot)
                || lots.East[slot].Raw != east.Raw
                || lots.North[slot].Raw != north.Raw)
            {
                continue;
            }

            int building = lots.BuildingOn(slot);

            if (building >= 0)
            {
                return building;
            }
        }

        return -1;
    }

    /// <summary>
    /// The Outside Connection standing on the Lot at exactly this Tile, or <c>-1</c>.
    /// </summary>
    /// <remarks>
    /// <b>Exact rather than nearest, and gate-kinded rather than merely occupied.</b> Both narrowings
    /// are load-bearing: the origin block carries two gates on the shipped lattice, and an ordinary
    /// dwelling standing at the named Tile is a different Building from the one the command meant.
    /// </remarks>
    private int GateOn(Tiles east, Tiles north)
    {
        LotTable lots = _world.Lots;

        for (int slot = 0; slot < lots.Rows.SlotCount; slot++)
        {
            if (!lots.Rows.IsLive(slot)
                || lots.IsVacant(slot)
                || lots.East[slot].Raw != east.Raw
                || lots.North[slot].Raw != north.Raw)
            {
                continue;
            }

            int building = lots.BuildingOn(slot);

            if (building >= 0 && _world.IsOutsideConnection(_world.Buildings.Kind[building]))
            {
                return building;
            }
        }

        return -1;
    }

    /// <summary>
    /// The first Citizen living in a Building, or <c>-1</c> if nobody does.
    /// </summary>
    /// <remarks>
    /// Two intrusive lists deep — a Building's Households, then a Household's members — and taking the
    /// head of each, because both are kept in slot order by <c>InsertOrdered</c> and the head is
    /// therefore a stable choice rather than an arbitrary one.
    /// </remarks>
    private int FirstResidentOf(int building)
    {
        int household = _world.Occupants.PeekFront(building);

        return household < 0 ? -1 : _world.Members.PeekFront(household);
    }

    /// <summary>Phase 1 — drain the Event Wheel bucket for this Tick.</summary>
    /// <remarks>
    /// <para>
    /// <b>Serial, and the only phase that takes rows off the Wheel.</b> Slice 7's wheel carries Rule
    /// Instances, and it still does. ⚠ <b>The sentence here used to add that <em>every Citizen already
    /// carries the <c>next_event_tick</c> it will be bucketed by, declared in slice 4</em>, and that
    /// column was DELETED in <c>plans/0046</c> stage 1</b> — written once at creation, read by
    /// nothing, and standing in the State Hash for eleven slices. ***A declared column is not a
    /// half-built mechanism, it is a note somebody left***, and this comment is how it kept reading
    /// as the former.
    /// </para>
    /// <para>
    /// ⚠ <b>The cascade runs first, and the ordering is the coarse wheel's one load-bearing
    /// requirement.</b> <see cref="EventWheel.Cascade"/> moves a Day's long sleepers down onto the fine
    /// wheel; a sleep ending at exactly midnight lands in the fine bucket this Tick is about to drain,
    /// so cascading first fires it on the Tick it was armed for and cascading second loses it for a
    /// whole further period. ***Reversing these two lines is a silent Day-long delay on one arming in
    /// 2,048*** — <c>CoarseWheelTests.A_sleep_ending_at_midnight_fires_at_midnight</c> holds it.
    /// </para>
    /// </remarks>
    private void Wake(Ticks tick)
    {
        _phase = TickPhase.Wake;

        _world.Wheel.Cascade(tick);
        _rules.CollectDue(tick);
    }

    /// <summary>
    /// Phase 2 — evaluate Rules and Needs against the Past, emitting intents and writing nothing.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Writing nothing is the load-bearing property</b> (<c>adr/0037</c>): it is what permits every
    /// entity table to be single-buffered, so the Past is <em>the state as of the start of this
    /// Tick</em> rather than a second copy of the world. The guard below is that claim checked instead
    /// of trusted — see <see cref="VerifyDecideWritesNothing"/>.
    /// </para>
    /// <para>
    /// <b>The intents it will emit are not table state</b>, so they are outside what the guard folds.
    /// That is the correct boundary: an intent is a proposal that Phase 3 may reject, and a phase that
    /// could not write its own proposals could not propose anything.
    /// </para>
    /// </remarks>
    private void Decide(Ticks tick)
    {
        _phase = TickPhase.Decide;

        if (!VerifyDecideWritesNothing)
        {
            DecideCore(tick);
            return;
        }

        ulong before = FoldEverything();
        DecideCore(tick);
        ulong after = FoldEverything();

        if (before != after)
        {
            throw new InvalidOperationException(
                $"Decide wrote to the world on Tick {tick.Raw}. Phase 2 is read-only (adr/0037): "
                + "every entity table is single-buffered because of it.");
        }
    }

    /// <summary>The read-only half of Phase 2: evaluate every Rule the Wheel handed us.</summary>
    private void DecideCore(Ticks tick) => _rules.Evaluate(tick);

    /// <summary>Phase 3 — apply intents in shuffle order, re-checking atomicity.</summary>
    /// <remarks>
    /// Serial and sorted. Contested outcomes are settled by a counter-based shuffle rather than by
    /// arrival or by entity id (<c>02 §8</c> rule 5), because ordering by id is <em>biased</em> — the
    /// same Building would win every contested draw for the life of the city.
    /// </remarks>
    private void Settle(Ticks tick)
    {
        _phase = TickPhase.Settle;

        _rules.Apply(tick);
    }

    /// <summary>Phase 4 — generate journeys, advance Travellers and accrue attendance.</summary>
    /// <remarks>Commute searches may run in parallel; generators and world writes remain ordered.</remarks>
    private void Move(Ticks tick)
    {
        _phase = TickPhase.Move;

        // Generation before advance, and the ordering is what makes a sub-Tick walk arrive on the Tick
        // it departed rather than a Tick later. adr/0071: travel time is sub-Tick, so a walk across the
        // street genuinely costs less than one integration step, and a phase that advanced first would
        // hold such a Trip in flight for a whole Tick for no reason in the city.
        _civic.Step(tick);
        _shopping.Step(tick);
        _commutes.Generate(tick);

        // adr/0032's Attended Services, and BEHIND the commute rather than in front of it. Both
        // create Trips and both walk in slot order, so the ordering is arbitrary and must be fixed:
        // swapping them renumbers every Trip id the State Hash folds on any Tick carrying both, and
        // midnight carries both. Behind, because the commute is the older generator and moving it
        // would re-spell every committed golden baseline for nothing.
        _services.Attend(tick);

        // Serially, though the phase permits parallel. Phases.Runs states that permission as an upper
        // bound rather than an instruction, and plans/0021 task 5 says to take it as one: a parallel
        // Phase 4 is one of adr/0037's two double-buffered tables, and neither the buffering nor the
        // measurement that would justify it exists.
        _trips.Advance(tick);
        WorkSchedule.Accrue(_world, tick);
    }

    /// <summary>Phase 5 — Map Layer diffusion for whatever is scheduled this Tick.</summary>
    /// <remarks>
    /// <para>
    /// Permitted parallel, and <c>adr/0037</c>'s other double-buffered table — the first one in the
    /// project to declare <c>Buffering.TwoCopies</c>. This build runs it serially, which
    /// <c>Phases.Runs</c> states: permission is an upper bound.
    /// </para>
    /// <para>
    /// <b>It costs nothing on the overwhelming majority of Ticks, by construction.</b> The schedule is
    /// staggered — pollution on <c>tick % 64 == 0</c>, land value every 256 offset by 16 — so 63 Ticks
    /// in 64 do no convolution at all, and the two Layers never land on the same Tick. That is
    /// <c>05 §9</c>'s third multiplier: a spike every 64 Ticks is a visible stutter, and the same work
    /// spread over those 64 Ticks is not.
    /// </para>
    /// <para>
    /// <b>The cadence is hash-bearing, which makes it the designer's number and not the profiler's</b>
    /// (<c>adr/0044</c>). It decides when a source becomes visible to a Rule that reads the Cell, so
    /// two worlds differing only in the period produce two hash traces — <c>05 §4</c>'s test, run
    /// rather than argued, because under <c>adr/0043</c> the claim was <em>measurable</em> and the
    /// machine that settles it is this one. It stays ordinary hot-reloadable Ruleset data, which is
    /// why the schedule arrives as a constructor argument of the <c>World</c> rather than a constant
    /// here: a number embedded in an <c>if</c> has no name, and a number with no name is one nobody
    /// runs the hash rule against.
    /// </para>
    /// </remarks>
    private void Layers(Ticks tick)
    {
        _phase = TickPhase.Layers;

        _world.Layers.Step(tick, _world.Roads, _world.Rules.Terrain, _world.Shore);
    }

    /// <summary>Phase 6 — Zone Rules sample Lots; Buildings with accumulated failure decline.</summary>
    /// <remarks>
    /// <para>
    /// Serial, and the whole of a Sweep Rule's Tick. <b>That it is one phase rather than three is the
    /// difference <c>adr/0033</c> is about</b>: a Bin Rule's proposal survives phase 2 only to be
    /// re-checked and possibly refused in phase 3, whereas a Zone Rule's effect exists the instant it
    /// acts. Nothing here proposes, so nothing here can be outbid.
    /// </para>
    /// <para>
    /// <b>It runs after phase 5 and that ordering is a decision.</b> A Zone Rule's predicates read
    /// Map Layer values, so growth this Tick sees the diffusion this Tick — a Building placed on a
    /// Cell whose pollution rose in phase 5 is judged against the risen figure and not the stale one.
    /// Reversing the two would make growth lag the environment by a whole Tick on the 1-in-64 Ticks a
    /// Layer moves, which is a difference no readout could explain.
    /// </para>
    /// </remarks>
    private void Growth(Ticks tick)
    {
        _phase = TickPhase.Growth;

        // adr/0069, and the ORDER is the decision rather than the presence. 02 §1.1 calls the phase
        // ordering the determinism contract, and this line is inside a phase rather than beside it:
        // placement drains the Pool into standing vacancy first, so the Pool a Zone Rule then reads is
        // the RESIDUAL -- the Households the existing stock could not house. That is what makes the
        // create predicate a statement about vacancy rather than about population, and it is what
        // replaces the self-limiting property construction used to supply by housing one itself.
        // Ahead of everything else in the phase, and the ORDER is the decision. A Policy moves what
        // an actor holds, so the three passes behind it respond to the city it just changed rather
        // than to last Tick's -- phase 5 -> phase 6's own argument, one level in. Nothing downstream
        // reads a balance today, which is exactly why this is the cheap moment to fix it.
        // AHEAD OF THE POLICIES, and the order is the decision rather than the presence -- the
        // paragraph above says so about this line's neighbour and it is truer here, because these two
        // move the same money out of the same Bins on the same Tick. Payroll first means a Business
        // pays its people out of what it earned and is levied on what is left; policies first would
        // levy the gross and let a shop be taxed into being unable to pay wages it had the money for
        // when the Tick began. ***Both are defensible cities and only one of them is this one.***
        //
        // ⚠ It is silent on nine of the shipped Rulesets: no trade there declares wage_per_day, so
        // the walk finds no employer with a rate and moves nothing.
        // FIRST IN THE PHASE, AHEAD OF EVERYTHING, and the order is the decision rather than the
        // presence. A Disaster is world-scheduled -- it owes nothing to the city and nothing the city
        // does can move it (01 §5.3) -- so running it before the four passes that follow means each of
        // them responds to the ground as it is now rather than to the ground as it was at midnight. A
        // Household unhoused by a flood on this line reaches the Unplaced Pool in time for placement
        // to rehouse it on the same Tick, and a Lot the water vacated is a Lot the Zone Rules can
        // build on. Behind them instead, every one of those would lag by a Tick.
        //
        // ⚠ It is silent on every shipped Ruleset but flooded.toml, which is the only one declaring
        // [disasters] -- the sweep returns before it looks at a row.
        _lastDisasters = _disasters.Sweep(tick);

        _lastPayroll = _wages.Sweep(tick);

        // AHEAD OF PLACEMENT and behind payroll, and only the first half is a decision. A stage
        // change is what makes a Household want a different dwelling (adr/0011: household life stage
        // is one of the primary drivers of residential mobility), so transitioning before the
        // placement pass means a Household that changed stage this Day is considered in the stage it
        // is now in rather than the one it left at midnight. ⚠ Nothing reads a stage yet, so the
        // ordering buys nothing today and is written where it will be right rather than where it is
        // currently indistinguishable.
        //
        // ⚠ It is silent on every shipped Ruleset: none declares [[life_stage]], so DeclaresLifeStages
        // is false and the sweep returns before it looks at a bucket.
        _lastLifeStages = _lifeStages.Sweep(tick);

        _policies.Sweep(tick);

        _rules.SweepNeeds(tick);

        _placement.Place(tick);

        // adr/0081, and behind placement rather than in front of it: a commute is anchored at a
        // dwelling, so a Household housed a line above can look for work on the same Tick. Ahead of
        // the Zone Rules for a second reason of its own -- a Building condemned this Tick should not
        // acquire a worker first, and taking a job in a doomed Building is a churn nothing reports.
        _employment.Assign(tick);

        _zoning.Sweep(tick);

        // adr/0134's re-evaluation, LAST in the phase and after the Zone Rules, because the field it
        // reads is a count of Buildings and this is the line after which that count is settled for the
        // Tick. Placing it earlier would derive the Districts of the city as it was before this Tick's
        // growth, which is phase 5 -> phase 6's own argument arriving one phase further on.
        //
        // IN PHASE 6 AND NOT PHASE 5, though phase 5 is where the other cadenced field update lives.
        // A Map Layer diffuses a field that phase 6 then READS; this derives a structure FROM what
        // phase 6 writes. Same shape, opposite direction, and putting it beside the Layers would make
        // every District lag its own city by a Tick on the Ticks that matter. adr/0134 is explicit that
        // this cadence is not [layers]'.
        if (_world.Rules.Districts.RevisitsOn(tick))
        {
            _world.EvaluateDistricts();
        }

        // adr/0135's Day-boundary reprice, and LAST because it must price the Pools the Tick actually
        // ends with. The line above can open a Pool, destroy one, or hand a dying District's stock to
        // its heir -- and a price computed before that would be a price for a level that changed
        // afterwards. FitDistrictPools' own argument, one line further on.
        //
        // NO WHEEL, and no dependency on milestone 18. "Recomputed each Day" is a modulo over
        // Ticks.PerDay, which this build already takes in two other places; 18's wheel exists so that
        // MANY Day countdowns can share a structure, and one recompute per Good needs none of it.
        // adr/0135 records that the dependency was inferred from a cadence's units rather than read
        // off a symbol.
        if (_world.Rules.Market.RepricesOn(tick))
        {
            _world.RepriceDistrictPools();
        }

        // The water graph's own Day boundary, milestone 24 task 6b. A modulo over Ticks.PerDay for
        // the reprice's stated reason -- one countdown needs no wheel -- and at offset 0 rather than
        // sharing the reprice's, because the two read nothing of each other and a shared offset would
        // imply they did. ⚠ It moves NOTHING on every shipped world: no Scope reaches a Water Body, so
        // every level is zero (adr/0161).
        if (tick.Raw % (ulong)Ticks.PerDay == 0)
        {
            // IN, THEN OUT, and the order is hash-bearing rather than tidy. Draining first would let a
            // body shed the level it held yesterday and then take today's runoff on top, so a city
            // that paved a catchment would see the effect a Day late for ever. adr/0161, F17.
            _world.RunoffIntoWater(tick);
            _world.DrainWaterBodies(tick);
        }
    }

    /// <summary>Phase 7 — schedule next events, re-evaluate Stress, emit the State Hash if due.</summary>
    /// <remarks>
    /// <b>This phase no longer swaps Past and Future</b>, which <c>02 §1.1</c>'s table still says it
    /// does. <c>adr/0037</c> deleted the full-world double buffer in favour of one live state, so
    /// there is nothing to swap; the Past is a property of the phase ordering rather than a copy.
    /// Emitting the hash is the caller's business in slice 5 — see <c>Replay</c> — because <em>if
    /// due</em> is a cadence the host chooses.
    /// </remarks>
    private void Commit(Ticks tick)
    {
        _phase = TickPhase.Commit;

        // 02 §10's staggered tier. Last in the Tick because it asserts about a settled world: run
        // before Growth and it would report a city mid-edit, which is a check that fires on correct
        // code and is therefore a check somebody eventually deletes.
        _world.Invariants.RunStaggered(_world);
    }

    /// <summary>
    /// Asks for a save at the end of this Tick. The one door a host has to a save.
    /// </summary>
    /// <param name="destination">
    /// Where the finished bytes go. Written once, synchronously, before <see cref="Step"/> returns.
    /// </param>
    /// <remarks>
    /// <para>
    /// <b>The cadence is the host's and the <em>instant</em> is not</b> (<c>adr/0087</c>). An autosave
    /// interval changes no state and enters no hash, so it is a setting rather than a world constant;
    /// where in the Tick the copy is taken is neither. A copy taken mid-Tick captures some tables
    /// before Settle and some after, which is <b>a world that never existed</b>.
    /// </para>
    /// <para>
    /// ⚠ <b>The copy is taken after <see cref="Entities.World.Advance"/> and not at the end of phase 7,
    /// against <c>adr/0087</c>'s wording, and the difference is the clock.</b> That ADR's reasoning
    /// about phase 7 is sound and untouched — it is serial, and both double-buffered tables have
    /// settled, because <c>MapLayers</c> swaps inside the Layers phase. What it does not account for is
    /// that <c>Advance</c> runs <em>after</em> Commit and increments the Tick, which has been <b>saved
    /// state</b> since <c>adr/0058</c>. A copy taken before it records the Tick just finished, so
    /// reloading it re-runs that Tick: one duplicated Tick, no error, and a hash that diverges from the
    /// run it was meant to continue. ***"The end of phase 7" and "the end of the Tick" are different
    /// instants, and the difference is one increment of saved state.*** Found by the hash disagreeing;
    /// <c>adr/0058</c> shipped before <c>adr/0087</c> and the phrase reads as though they are the same
    /// moment.
    /// </para>
    /// <para>
    /// <b>⚠ It is called from inside <see cref="Step"/> rather than after it, and that is the seam.</b>
    /// <c>05 §6</c>'s threading policy is session R's and decides nothing a save needs, so this
    /// milestone writes synchronously (<c>plans/0030</c> D4) — but the boundary a thread would wrap is
    /// drawn now: <see cref="WorldSnapshot"/> is filled on the simulation thread, at ~10 ms once per
    /// autosave, and everything after that moves. Calling this from outside a Tick would put the copy at
    /// a moment nothing guarantees is a boundary.
    /// </para>
    /// <para>
    /// ⚠ <b>The hash is on the movable side, which is task 10's whole result</b> (<c>adr/0112</c>).
    /// <c>SaveHash</c> folds the copy rather than the world, so the ninth header field costs this thread
    /// nothing — where folding the live world would have cost <b>32.47 ms</b> at 1M, on top of the copy.
    /// </para>
    /// <para>
    /// <b>One save may be outstanding.</b> Asking twice before a Tick runs replaces the destination
    /// rather than queueing, because two saves of the same instant are one save written twice.
    /// </para>
    /// </remarks>
    public void SaveAtEndOfTick(ISaveSink destination)
    {
        ArgumentNullException.ThrowIfNull(destination);

        _saveDue = destination;
    }

    /// <summary>Whether a save has been asked for and not yet taken.</summary>
    public bool SaveIsDue => _saveDue is not null;

    private void TakeSaveIfDue()
    {
        if (_saveDue is null)
        {
            return;
        }

        ISaveSink destination = _saveDue;
        _saveDue = null;

        // Allocated on the first save rather than with the Simulation: a session that never saves must
        // not carry 131.33 MiB of buffer for the option.
        _snapshot ??= new WorldSnapshot();

        // The copy, the hash and the write. Only the copy has to happen on this thread -- ~10 ms at 1M,
        // once per autosave, serial and after every phase; what moved against adr/0087's wording is that
        // it is after the clock increment rather than before it. The hash is folded from the copy rather
        // than from the world (adr/0112), so it is on the far side of the seam with the write and the
        // simulation thread pays nothing for a save that verifies itself on load.
        SaveFile.Write(_world, _inForce, _snapshot, destination);
    }

    /// <summary>
    /// Runs <c>02 §10</c>'s end-of-run tier: the expensive whole-world walks.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Called once, after the last Tick, by whoever owns the run.</b> It is <c>O(world)</c> and
    /// affordable precisely because there is one of it per run however long the run was — which is
    /// <c>adr/0033</c>'s shape, quoted by <c>02 §10</c>: <em>unaffordable per Tick and trivial at the
    /// end of a headless run.</em>
    /// </para>
    /// <para>
    /// <b>It is not called from <see cref="Step"/>, and that is the whole point of the tier.</b> A
    /// check that ran every Tick would have to be cheap, and these are the ones that are not.
    /// </para>
    /// </remarks>
    public void CheckEndOfRun() => _world.Invariants.RunEndOfRun(_world);

    /// <summary>
    /// Folds every column of every table — derived ones included — for the Decide guard.
    /// </summary>
    /// <remarks>
    /// <b>Deliberately not <see cref="Entities.World.HashState"/>.</b> The State Hash folds saved
    /// state only, by declaration, so a Decide that wrote to a derived column would pass a check built
    /// on it. That is exactly the hole slice 4 found in the other direction, where a derived list's
    /// ordering escaped the hash; the same blind spot, read from the other side.
    /// </remarks>
    private ulong FoldEverything()
    {
        ulong hash = 0;

        // TablesAPhaseCanWrite and not Tables, and the difference is the guard's whole cost. A table
        // nothing writes at all cannot be evidence about what Decide wrote, and folding terrain's
        // 262,144 rows twice a Tick made a Tick 138x itself. What stops that being a silent hole is
        // WorldInvariants.TerrainIsWhatItsWorldKeyGenerates, at the end-of-run tier. See World.
        foreach (Rows table in _world.TablesAPhaseCanWrite)
        {
            table.FoldAll(ref hash);
        }

        return hash;
    }
}
