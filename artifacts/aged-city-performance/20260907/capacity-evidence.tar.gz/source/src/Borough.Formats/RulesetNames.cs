namespace Borough.Formats;

using Borough.Core.Rules;
using Borough.Core.Tables;

/// <summary>
/// What the Ruleset's authored names were, kept so a shell can put words back on the ids
/// <c>Borough.Core</c> returns.
/// </summary>
/// <remarks>
/// <para>
/// <b><c>05 §1</c>'s rule is that <c>Core</c> returns ids and numbers and <em>"the shell owns every
/// string a human reads, resolved through the Ruleset"</em> — and until milestone 6 task 5 there was
/// nothing to resolve them through.</b> The loader builds four name-to-id maps while reading a file
/// and dropped all four on the floor; <c>Ruleset</c> could not keep them, because a Ruleset is
/// <c>Core</c> and <c>Core</c> holds no strings. So the resolution path the architecture assumes
/// simply did not exist, and no reader of that sentence would have guessed it — the eight runner modes
/// shipped before this one all get away with it because <b>they print quantities rather than names</b>.
/// A grid of v/c ratios needs no vocabulary. A condemnation reason is nothing but one.
/// </para>
/// <para>
/// ⚠ <b>The corpus already had the other half of this and the two are easy to mistake for one.</b>
/// <c>Ruleset.ResourceKeys</c> and <c>KindKeys</c> are <em>content hashes</em> of the same authored
/// names, carried into <c>Core</c> under <c>adr/0048</c>'s rule that a number may cross where the name
/// it was made from may not — and that ADR says in as many words that <em>"the core never renders it
/// and never resolves a name with it; it only asks whether two declarations are the same thing."</em>
/// <b>A key answers <em>are these two the same</em>; a name answers <em>what do I call it</em>.</b> The
/// build had the first and not the second, which is why the gap survived: a reader checking whether
/// names were kept finds a table that looks like the answer and is a one-way hash.
/// </para>
/// <para>
/// <b>Here rather than in <c>Core</c>, and it is not a near miss.</b> <c>Borough.Formats</c> is the
/// project described as <em>"the artefacts that spell things in words"</em>; putting these on the
/// <c>Ruleset</c> would put <c>string</c> into simulation state, which lint 7 refuses and
/// <c>adr/0002</c> refuses for the reason that matters — a method returning a formatted string because
/// a panel wanted one is the real leak vector, not <c>using Godot;</c>. Nothing here reaches the
/// simulation: it is a by-product of parsing, it does not enter the State Hash, and a world loaded
/// from a save has none of it.
/// </para>
/// <para>
/// ⚠ <b>Every lookup can return null and that is not a defensive habit.</b> An id can outlive the name
/// that introduced it — a Building standing under a Ruleset that no longer declares its kind is
/// <c>adr/0068</c>'s <em>derelict</em>, and is a state the design has on purpose. A caller that wants
/// a word either way spells the fallback itself, because what to show for a kind nobody named is a
/// presentation decision and this is not the presentation layer.
/// </para>
/// </remarks>
public sealed class RulesetNames
{
    private static readonly string[] Nothing = [];

    private readonly string[] _kinds;
    private readonly string[] _businessKinds;
    private readonly string[] _conditions;
    private readonly string[] _resources;
    private readonly string[] _rules;
    private readonly string[] _lifeStages;
    private readonly string?[] _policies;
    private readonly string?[] _zoneRules;

    internal RulesetNames(
        IReadOnlyDictionary<string, byte> kinds,
        IReadOnlyDictionary<string, byte> businessKinds,
        IReadOnlyDictionary<string, ushort> conditions,
        IReadOnlyDictionary<string, ushort> resources,
        IReadOnlyDictionary<string, ushort> rules,
        IReadOnlyDictionary<string, byte> lifeStages,
        IReadOnlyList<string?> policies,
        IReadOnlyList<string?> zoneRules)
    {
        _kinds = Invert(kinds);
        _businessKinds = Invert(businessKinds);
        _conditions = Invert(conditions);
        _resources = Invert(resources);
        _rules = Invert(rules);
        _lifeStages = Invert(lifeStages);

        // ⚠ A LIST AND NOT A MAP, which is the one name here that is not inverted from an id table.
        // A Policy has no id: Govern addresses it by DECLARATION POSITION and the Ruleset keys it by
        // a hash of this string, so the position IS the index and inverting anything would lose it.
        _policies = [.. policies];

        // A list for the Policy's reason: a Zone Rule has no id either, and what addresses it in a
        // panel is its position in declaration order.
        _zoneRules = [.. zoneRules];
    }

    private RulesetNames()
    {
        _kinds = Nothing;
        _businessKinds = Nothing;
        _conditions = Nothing;
        _resources = Nothing;
        _rules = Nothing;
        _lifeStages = Nothing;
        _policies = [];
        _zoneRules = [];
    }

    /// <summary>A Ruleset whose names were not kept. Every lookup returns null.</summary>
    /// <remarks>
    /// <b>The honest state for a world that did not come from a file</b> — a save, or a
    /// <c>Ruleset</c> a test built by hand. Those have ids and never had names, so an empty table is
    /// the fact rather than a placeholder for one.
    /// </remarks>
    public static RulesetNames None { get; } = new();

    /// <summary>What the file called a Building kind, or null.</summary>
    public string? Kind(byte id) => At(_kinds, id);

    /// <summary>
    /// What the <c>[[policy]]</c> at this declaration position called itself, or null.
    /// </summary>
    /// <remarks>
    /// ⚠ <b>Null means the table stated no <c>name</c>, and such a Policy is UNGOVERNABLE</b> — its
    /// <c>Ruleset.PolicyKeys</c> entry is zero and <c>Simulation.ApplyGovern</c> refuses it, because
    /// a governed amount is saved state and a name is the only thing that survives a renumbering.
    /// ***A panel showing such a row has to show it as unavailable rather than omit it***, or the
    /// positions a person counts down stop matching the ones <c>Govern</c> addresses.
    /// </remarks>
    public string? Policy(int position) =>
        position >= 0 && position < _policies.Length ? _policies[position] : null;

    /// <summary>
    /// What the <c>[[zone_rule]]</c> at this declaration position called itself, or null.
    /// </summary>
    /// <remarks>
    /// ⚠ <b>Null is not a refusal here, unlike <see cref="Policy"/>.</b> A Zone Rule is addressed by
    /// the permission word it admits (<c>ZoneRuleDefinition.Admits</c>) rather than by its name, so a
    /// nameless one is paintable and merely unlabelled. ***A panel spells its own fallback***, which
    /// is this type's standing rule about what to show for a thing nobody named.
    /// </remarks>
    public string? ZoneRule(int position) =>
        position >= 0 && position < _zoneRules.Length ? _zoneRules[position] : null;

    /// <summary>What the file called a Business kind, or null.</summary>
    /// <remarks>
    /// <b>A second kind namespace, and the two do not share ids.</b> <c>adr/0141</c> gives the Ruleset
    /// two kind tables because the premises and the trade are not correlated — the same shopfront hosts
    /// a bakery and then a barber — so <em>bakery</em> must not be a property of the walls. A file may
    /// therefore name a <c>[[building]]</c> and a <c>[[business]]</c> the same thing, and they are
    /// different kinds.
    /// </remarks>
    public string? BusinessKind(byte id) => At(_businessKinds, id);

    /// <summary>What the file called a Life Stage, or null.</summary>
    /// <remarks>
    /// <b>A third namespace, and it shares ids with neither kind table.</b> A stage is named so that
    /// <c>[[life_stage]] next</c> can refer to one — the chain is authored rather than taken from
    /// declaration order — and so that a readout can print <em>empty_nest</em> instead of
    /// <em>stage 5</em>. ⚠ <b><c>Core</c> never sees these</b>: it returns ids and numbers, and the
    /// shell resolves them, which is the boundary <c>05 §2</c> draws.
    /// </remarks>
    public string? LifeStage(byte id) => At(_lifeStages, id);

    /// <summary>What the file called a condition, or null.</summary>
    /// <remarks>
    /// <c>ConditionId.None</c> returns null, which is correct rather than incidental: a Rule reporting
    /// nothing has no condition to name, and <em>a demolition with no sentence behind it</em> is the
    /// state every Ruleset without an <c>on_fail</c> chain is in.
    /// </remarks>
    public string? Condition(ConditionId id) => At(_conditions, id.Raw);

    /// <summary>What the file called a Resource, or null.</summary>
    public string? Resource(ResourceId id) => At(_resources, id.Raw);

    /// <summary>What the file called a Rule, or null.</summary>
    public string? Rule(RuleId id) => id.IsNone ? null : At(_rules, id.Raw);

    private static string? At(string[] table, int id) =>
        id > 0 && id < table.Length ? table[id] : null;

    /// <summary>
    /// Turns a name-to-id map into an id-indexed table.
    /// </summary>
    /// <remarks>
    /// <b>A dense array rather than the dictionary turned round</b>, because <c>05 §4</c>'s lint 3
    /// bans enumerating a hash map in simulation code and this is the pattern that stops the habit
    /// leaking across the boundary — the ids are small, dense and assigned in file order, so the array
    /// is the natural shape anyway. Index 0 is unused throughout: every id family here reserves it for
    /// <em>none</em>.
    /// </remarks>
    private static string[] Invert(IReadOnlyDictionary<string, byte> map)
    {
        int highest = 0;

        foreach (KeyValuePair<string, byte> entry in map)
        {
            if (entry.Value > highest)
            {
                highest = entry.Value;
            }
        }

        string[] table = new string[highest + 1];

        foreach (KeyValuePair<string, byte> entry in map)
        {
            table[entry.Value] = entry.Key;
        }

        return table;
    }

    private static string[] Invert(IReadOnlyDictionary<string, ushort> map)
    {
        int highest = 0;

        foreach (KeyValuePair<string, ushort> entry in map)
        {
            if (entry.Value > highest)
            {
                highest = entry.Value;
            }
        }

        string[] table = new string[highest + 1];

        foreach (KeyValuePair<string, ushort> entry in map)
        {
            table[entry.Value] = entry.Key;
        }

        return table;
    }
}
