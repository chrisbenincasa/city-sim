from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent
for seed in (0,1):
 for build in ('after','before'):
  name=f'hundred-{seed}-untraced-{build}'
  binary=r/(build+'-run')/'Borough.Tests.dll'
  cmd=['dotnet',str(binary),'resumed',str(r/f'hundred-{seed}.save'),'100000',str(seed),'8','2']
  (r/(name+'-command.json')).write_text(json.dumps({'command':cmd,'conditions':'Sequential Release M4 Pro desktop diagnostics, 8 route workers, untraced, after then before; no overlapping tests/builds/captures.','assemblies':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.parent.glob('*.dll')}},indent=2)+'\n')
  print('START',name,flush=True)
  with (r/(name+'.jsonl')).open('x') as out,(r/(name+'-resources.txt')).open('x') as err:
   result=subprocess.run(['/usr/bin/time','-l',*cmd],stdout=out,stderr=err)
  if result.returncode:raise RuntimeError((name,result.returncode))
  a=[json.loads(s) for s in (r/(name+'.jsonl')).read_text().splitlines()]
  print('DONE',name,json.dumps([x for x in a if 'MeanMs' in x]),flush=True)
