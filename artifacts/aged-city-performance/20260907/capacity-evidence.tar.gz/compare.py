from pathlib import Path
import json
r=Path(__file__).parent
ignore=set('MeanMs P95Ms P99Ms MaxMs MaxTick AllocatedBytes Gen0Collections Gen1Collections Gen2Collections ManagedHeapBytes WorkingSetBytes'.split())
groups={}; runs={}; checked=0
for p in sorted(r.glob('*.jsonl')):
 a=[json.loads(s) for s in p.read_text().splitlines()]
 if not a or a[-1].get('type')!='end':continue
 c=a[0]; key=(c['population'],c['seed'])
 samples=[x for x in a if 'MeanMs' in x]
 activity=[{k:v for k,v in x.items() if k not in ignore} for x in samples]
 work=[{k:v for k,v in x.items() if k not in ('ms','phaseMs','allocated','tableGrowth')} for x in a if x.get('type')=='work']
 if key in groups:
  old=groups[key];assert activity==old['activity'], (p.name,'activity differs')
  assert a[-1]==old['end'], (p.name,'end differs')
  if work and old['work']:assert work==old['work'], (p.name,'work differs')
 else:groups[key]={'activity':activity,'end':a[-1],'work':work}
 storage=[x for x in a if x.get('type')=='storage']
 hashes={x['tick']:x['hash'] for x in storage}
 if 'hashes' in groups[key]:
  for tick in hashes.keys() & groups[key]['hashes'].keys():assert hashes[tick]==groups[key]['hashes'][tick], (p.name,tick,'checkpoint hash')
 else:groups[key]['hashes']=hashes
 previous=None; dayGrowth=[]
 for reading in storage:
  if reading['stage']=='measure-start':previous=reading
  if reading['stage']!='measure-end':continue
  old={t['Name']:t for t in previous['tables']};changes=[]
  for t in reading['tables']:
   start=old[t['Name']]['Capacity'];cap=start;payload=0;events=0
   while cap<t['Capacity']:
    cap*=2;events+=1;payload+=cap*(t['payloadBytes']//t['Capacity'])
   assert cap==t['Capacity']
   if events:changes.append({'table':t['Name'],'before':start,'after':cap,'growths':events,'replacementPayloadBytes':payload})
  dayGrowth.append({'startTick':previous['tick'],'endTick':reading['tick'],'changes':changes})
  previous=reading
 growth=[{'tick':x['tick'],'changes':x['tableGrowth']} for x in a if x.get('type')=='work' and x['tableGrowth']]
 runs[p.stem]={'samples':samples,'storage':storage,'growth':growth if work else None,'growthScope':'per-Tick when work is enabled; otherwise only daily capacity deltas are available','capacityGrowthByDay':dayGrowth,'end':a[-1]};checked+=1
 print(p.stem,[(s['StartTick'],round(s['MeanMs'],3),s['AllocatedBytes']) for s in samples], 'capacity growth events',sum(g['growths'] for d in dayGrowth for g in d['changes']))
for pair in [('million-resumed-before','million-resumed-after')]+[(f'hundred-{seed}-resumed-before',f'hundred-{seed}-resumed-after') for seed in (0,1)]:
 if any(name not in runs for name in pair):continue
 before,after=[runs[name] for name in pair]
 old={(x['stage'],x['tick']):x for x in before['storage']};new={(x['stage'],x['tick']):x for x in after['storage']}
 for key in old.keys() & new.keys():
  original={t['Name']:t for t in old[key]['tables']};restored={t['Name']:t for t in new[key]['tables']}
  for name,x in original.items():
   y=restored[name];assert x['SlotCount']==y['SlotCount'] and x['LiveCount']==y['LiveCount']
   if name not in ('trip','leg','traveller','route_hop'):assert x==y,(pair,key,name)
(r/'comparisons.json').write_text(json.dumps({'activityAndHashesMatchWithinFixtures':True,'perTickWorkMatchesWhereCounted':True,'onlyMovementCapacitiesDifferInBeforeAfterPairs':True,'runs':runs},indent=2)+'\n')
print('Checked',checked,'completed captures.')
