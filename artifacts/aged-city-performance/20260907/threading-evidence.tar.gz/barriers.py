import os,pathlib,re,subprocess
out=pathlib.Path('/tmp/borough-threading/barriers');out.mkdir(exist_ok=True)
hashes=[];logs=[]
for mode in ['threaded','serial']:
 drive=out/(mode+'.drive')
 drive.write_text(f'1 speed 8\n7 readout {out}/{mode}-seven.txt\n7 hold street\n7 click 48 32 shift\n7 speed 8\n8 readout {out}/{mode}-eight.txt\n11 quit\n')
 command=['godot','--headless','--path','src/Borough.Godot','--','--ruleset','rulesets/stress-shopping.toml','--citizens','1000','--start-at','1','--route-workers','8' if mode=='threaded' else '1','--drive',str(drive)]
 if mode=='serial':command+=['--main-thread-sim']
 result=subprocess.run(command,env=dict(os.environ,BOROUGH_LOG='1'),text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
 (out/(mode+'.log')).write_text(result.stdout)
 assert result.returncode==0,result.stdout
 hashes.append(re.search(r'State Hash 0x([0-9A-F]+)',result.stdout).group(1))
 logs.append(pathlib.Path('src/Borough.Godot/session-11.borough').read_bytes())
 (out/(mode+'.borough')).write_bytes(logs[-1])
 assert (out/(mode+'-seven.txt')).read_text().startswith('tick 7\n')
 assert (out/(mode+'-eight.txt')).read_text().startswith('tick 8\n')
assert hashes[0]==hashes[1],hashes
assert logs[0]==logs[1]
print('Drive barriers at 7 and 8; byte-identical Input Logs and hash', hashes[0])
