import pathlib,socket,subprocess,time
out=pathlib.Path('/tmp/borough-threading/channel-cancel');out.mkdir(exist_ok=True)
for mode in ['accept','partial-line']:
 address=str(out/(mode+'.sock'));pathlib.Path(address).unlink(missing_ok=True)
 with (out/(mode+'.log')).open('w') as log:
  p=subprocess.Popen(['godot','--headless','--path','src/Borough.Godot','--','--citizens','256','--start-at','1','--quit-at','8','--listen',address],stdout=log,stderr=subprocess.STDOUT)
  client=None
  try:
   for i in range(100):
    if pathlib.Path(address).exists():break
    time.sleep(.01)
   if mode=='partial-line':
    client=socket.socket(socket.AF_UNIX);client.connect(address);client.sendall(b'pa')
   assert p.wait(timeout=10)==0
   assert not pathlib.Path(address).exists()
  finally:
   if client:client.close()
   if p.poll() is None:p.terminate();p.wait(timeout=10)
 print(mode,'cancelled and exited normally')
