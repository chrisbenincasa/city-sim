Functional Godot Debug observations; not quiet Release reference timings.
final-visible, final-serial and aged-16000 passed the final check script. barriers compares fixed Drive Ticks and Input Log bytes. channel-cancel tests listener cancellation.
Earlier attempts preserve the original listener exit hang, the small-workload busy-frame assumption, headless pointer drift, and the 100000-Citizen synchronous ageing timeout.
Final-source is the final source snapshot; old attempts predate the listener fix. The source snapshot includes pre-existing workspace changes.
Use the commands in run.json with scripts/check-shell-threading.py; first build Godot Debug and Headless Release. No checkpoints or binaries are archived.
