import os, pathlib, socket, subprocess, time
out=pathlib.Path('/tmp/borough-threading/exit-probe');out.mkdir(exist_ok=True)
path=str(out/'shell.sock')
pathlib.Path(path).unlink(missing_ok=True)
with (out/'game.log').open('w') as log:
 p=subprocess.Popen(['godot','--headless','--path','src/Borough.Godot','--','--citizens','256','--start-at','1','--main-thread-sim','--route-workers','1','--listen',path],stdout=log,stderr=subprocess.STDOUT)
 try:
  for i in range(100):
   if pathlib.Path(path).exists(): break
   time.sleep(.1)
  with socket.socket(socket.AF_UNIX) as s:
   s.settimeout(15);s.connect(path)
   with s.makefile('rwb',buffering=0) as wire:
    wire.write(b'quit\n');print(wire.readline(),flush=True)
  try: print('exit',p.wait(timeout=5),flush=True)
  except subprocess.TimeoutExpired:
   print('socket remains',pathlib.Path(path).exists(),flush=True)
   subprocess.run(['sample',str(p.pid),'1','-file',str(out/'stack.txt')],check=True)
 finally:
  if p.poll() is None:
   p.terminate();p.wait(timeout=10)
