import hashlib,json,pathlib,tarfile
root=pathlib.Path('/home/christian/Code/city-sim');out=root/'artifacts/aged-city-performance/20260908';repeat=pathlib.Path('/tmp/borough-repeat-20260908');trace=pathlib.Path('/tmp/borough-repeat-pid-trace-20260908')
checks=json.loads((repeat/'analysis.json').read_text());records=[json.loads(s) for s in (trace/'run.jsonl').read_text().splitlines()];daily=next(r for r in records if 'MeanMs' in r);base=checks['runs'][0];exclude={'MeanMs','P95Ms','P99Ms','MaxMs','MaxTick','AllocatedBytes','ManagedHeapBytes','WorkingSetBytes','Gen0Collections','Gen1Collections','Gen2Collections'}
checks['trace_activity_hash_equal']=all(daily[k]==v for k,v in base['daily'].items() if k not in exclude) and records[-1]==base['end'];assert checks['trace_activity_hash_equal'] and checks['activity_hash_equal']
checks['trace_execution']='taskset -c 2; outside sandbox for diagnostic socket access; fresh trace with frozen observer binary and checkpoint, commands in capture.json; intrusive timing excluded'
checks['validation']={'ProfileDump':16,'summary_script':'passed CPU_TIME and UNMANAGED_CODE_TIME coverage, timestamp exclusion and scopes','repeat_script':'replayed original captures; allocation difference accepted separately; deliberately changed hash refused'}
(out/'repeatability-checks.json').write_text(json.dumps(checks,indent=2))
files={}
def add(path,name):
 if path.is_file():files[name]=path
for folder,name in [(repeat,'repeats'),(trace,'trace'),(pathlib.Path('/tmp/borough-repeat-trace-20260908'),'failed-pid'),(pathlib.Path('/tmp/borough-repeat-port-trace-20260908'),'failed-port'),(pathlib.Path('/tmp/borough-repeat-host-trace-20260908'),'failed-host-port'),(pathlib.Path('/tmp/borough-payroll/observer'),'binary')]:
 for p in folder.rglob('*'):add(p,name+'/'+str(p.relative_to(folder)))
for name in ['scripts/repeat-profile.py','scripts/summarize-simulation-profile.py','scripts/check-profile-summary.py','scripts/profile-simulation.py','src/Borough.Headless/ProfileDump.cs','plans/0067-aged-city-performance.md','rulesets/stress-shopping.toml']:
 add(root/name,'source/'+name)
add(pathlib.Path('/tmp/borough-test-20260908-125929.log'),'validation/ProfileDump.log');add(pathlib.Path('/tmp/borough-payroll/checkpoint.json'),'checkpoint.json');add(pathlib.Path('/tmp/borough-payroll/before-seed0-reproduction.json'),'checkpoint-reproduction.json');add(pathlib.Path(__file__),'package.py');add(out/'repeatability-checks.json','checks.json')
archive=out/'repeatability-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name)
fingerprints={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()}
with tarfile.open(archive) as tar:
 assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar if m.isfile()}==fingerprints
manifest={'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':fingerprints,'verified':True,'checkpoint':'Excluded reproducible save; fingerprint and reproduction retained.','scope':'Desktop repeatability investigation; no retained simulation optimization.'}
(out/'repeatability-manifest.json').write_text(json.dumps(manifest,indent=2));print('Verified',len(files),'files;',archive.stat().st_size,'archive bytes')
