import json
from pathlib import Path
out=Path(__file__).resolve().parent
activity='StartTick Ticks Citizens Buildings Employed PeakTravellers PeakVehicles VehicleTicks LoadedSegmentTicks CongestedSegmentTicks PeakVolumeCapacity CompletedTrips NoRoute OverBudget DriveLegs WalkLegs ShoppingOutings Purchases DeliveredGoods Wages RuleEvaluations RoutePrepared RouteUsed RouteFallback CivicEvents'.split()
def read(label): return [json.loads(s) for s in (out/(label+'.jsonl')).read_text().splitlines()]
checks={}
for base in ('hundred-0','hundred-1','small','million-1','million-8','hundred-0-counted'):
 if not (out/(base+'-after.jsonl')).exists(): continue
 b=read(base+'-before'); a=read(base+'-after')
 if a[-1].get('type')!='end' or b[-1].get('type')!='end': continue
 assert a[-1]==b[-1],base
 bd=[r for r in b if 'MeanMs' in r]; ad=[r for r in a if 'MeanMs' in r]
 assert len(bd)==len(ad)
 for x,y in zip(bd,ad): assert all(x[k]==y[k] for k in activity),base
 metrics='MeanMs P95Ms P99Ms MaxMs MaxTick AllocatedBytes Gen0Collections Gen1Collections Gen2Collections ManagedHeapBytes WorkingSetBytes'.split()
 checks[base]=dict(end=a[-1],activityMatches=True,days=[dict(start=x['StartTick'],before={k:x[k] for k in metrics},after={k:y[k] for k in metrics},meanReductionPercent=100*(1-y['MeanMs']/x['MeanMs'])) for x,y in zip(bd,ad)])
 if base.endswith('counted'):
  bw=[r for r in b if r.get('type')=='work']; aw=[r for r in a if r.get('type')=='work']
  assert len(bw)==len(aw)==2048
  for x,y in zip(bw,aw):
   for k in ('tick','shopping','shoppingRoutes','civicRoutes','otherRoutes','travellers','vehicles','routeReuse','routeBatch','tableGrowth'): assert x[k]==y[k],(x['tick'],k)
   for k,v in x['shoppingWork'].items():
    if k!='Selection': assert v==y['shoppingWork'][k],(x['tick'],k)
   for k,v in x['shoppingWork']['Selection'].items():
    if k!='PrefixReads': assert v==y['shoppingWork']['Selection'][k],(x['tick'],k)
  def selection(rows): return {k:sum(r['shoppingWork']['Selection'][k] for r in rows) for k in rows[0]['shoppingWork']['Selection']}
  checks[base]['selection']=dict(before=selection(bw),after=selection(aw))
  checks[base]['otherPerTickCountersMatch']=True
for seed in (0,1):
 bname=f'hundred-{seed}-before-repeat'; aname=f'hundred-{seed}-after-repeat'
 if not (out/(aname+'.jsonl')).exists() or not (out/(bname+'.jsonl')).exists():continue
 b=read(bname); a=read(aname)
 if a[-1].get('type')!='end' or b[-1].get('type')!='end':continue
 assert a[-1]==b[-1]
 x=next(r for r in b if 'MeanMs' in r);y=next(r for r in a if 'MeanMs' in r)
 assert all(x[k]==y[k] for k in activity)
 checks[f'hundred-{seed}-repeat']=dict(end=a[-1],activityMatches=True,before={k:x[k] for k in metrics},after={k:y[k] for k in metrics},meanReductionPercent=100*(1-y['MeanMs']/x['MeanMs']))
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
for name,c in checks.items():
 print(name, [(round(d['before']['MeanMs'],5),round(d['after']['MeanMs'],5),round(d['meanReductionPercent'],2)) for d in c.get('days',[c])])
