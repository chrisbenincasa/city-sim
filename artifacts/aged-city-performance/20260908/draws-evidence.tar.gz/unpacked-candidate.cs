using Borough.Core.Arithmetic;
using Borough.Core.Entities;
using Borough.Core.Quantities;
using Borough.Core.Tables;

namespace Borough.Core.Space;

public sealed partial class BuildingResidency
{
    private ulong _version;

    // Caller-owned scratch; valid only until Add, Remove or Rebuild changes the index.
    internal PreparedDraws PrepareDraws(CellRect area, BuildingTable buildings, Span<int> totals,
        BuildingQueryWork? work = null)
    {
        ArgumentNullException.ThrowIfNull(buildings);
        CellRect box = area.Clamp();
        int height = box.Height.Raw;
        if (totals.Length <= height) { throw new ArgumentException("Row totals need height + 1 entries.", nameof(totals)); }
        if (work is not null) { work.CountCalls++; }
        totals[0] = 0;
        for (int offset = 0; offset < height; offset++)
        {
            int row = PrefixRow(box.North.Raw + offset, work);
            totals[offset + 1] = totals[offset] + _prefix[row + box.EastEnd.Raw] - _prefix[row + box.East.Raw];
            if (work is not null) { work.PrefixReads += 3; }
        }
        return new PreparedDraws(this, buildings, box, totals[..(height + 1)], work);
    }

    internal readonly ref struct PreparedDraws
    {
        private readonly BuildingResidency _owner;
        private readonly BuildingTable _buildings;
        private readonly CellRect _box;
        private readonly ReadOnlySpan<int> _totals;
        private readonly BuildingQueryWork? _work;
        private readonly ulong _version;
        internal int Count { get; }

        internal PreparedDraws(BuildingResidency owner, BuildingTable buildings, CellRect box,
            ReadOnlySpan<int> totals, BuildingQueryWork? work)
        {
            _owner = owner; _buildings = buildings; _box = box; _totals = totals; _work = work;
            _version = owner._version;
            Count = totals[^1];
            if (work is not null) { work.PrefixReads++; }
        }

        internal int Nth(int ordinal)
        {
            ArgumentOutOfRangeException.ThrowIfNegative(ordinal);
            if (_version != _owner._version) { throw new InvalidOperationException("Building index changed during prepared draws."); }
            if (_work is not null) { _work.CandidateCalls++; }
            if (ordinal >= Count) { return Rows.NoSlot; }
            int low = 0, high = _box.Height.Raw - 1;
            while (low < high)
            {
                int middle = low + IntegerMath.FloorDiv(high - low, 2);
                if (_work is not null) { _work.PrefixReads++; }
                if (_totals[middle + 1] <= ordinal) { low = middle + 1; }
                else { high = middle; }
            }
            int north = _box.North.Raw + low;
            int row = north * PrefixStride;
            int rank = ordinal - _totals[low] + _owner._prefix[row + _box.East.Raw];
            if (_work is not null) { _work.PrefixReads += 2; }
            low = _box.East.Raw; high = _box.EastEnd.Raw - 1;
            while (low < high)
            {
                int middle = low + IntegerMath.FloorDiv(high - low, 2);
                if (_work is not null) { _work.PrefixReads++; }
                if (_owner._prefix[row + middle + 1] <= rank) { low = middle + 1; }
                else { high = middle; }
            }
            int remaining = rank - _owner._prefix[row + low];
            if (_work is not null) { _work.PrefixReads++; _work.CandidateLinks += remaining; }
            int encoded = _owner._head[CellGrid.Index(new Cells(low), new Cells(north))];
            Span<int> next = _buildings.CellNext.Span;
            for (int i = 0; i < remaining; i++) { encoded = next[encoded - 1]; }
            return encoded - 1;
        }
    }
}
