using Borough.Core.Arithmetic;
using Borough.Core.Entities;
using Borough.Core.Quantities;
using Borough.Core.Tables;

namespace Borough.Core.Space;

public sealed partial class BuildingResidency
{
    private ulong _version;
    private readonly int[] _firstColumn = new int[CellGrid.WorldCells];
    private readonly int[] _lastColumn = new int[CellGrid.WorldCells];

    // Caller-owned scratch, unchanged until the draws finish. Index mutations invalidate the query.
    internal PreparedDraws PrepareDraws(CellRect area, BuildingTable buildings, Span<int> totals,
        BuildingQueryWork? work = null)
    {
        ArgumentNullException.ThrowIfNull(buildings);
        CellRect box = area.Clamp();
        int height = box.Height.Raw;
        if (totals.Length < height * 2) { throw new ArgumentException("Row totals need two entries per row.", nameof(totals)); }
        if (work is not null) { work.CountCalls++; }
        int total = 0, written = 0;
        for (int offset = 0; offset < height; offset++)
        {
            int row = PrefixRow(box.North.Raw + offset, work);
            int here = _prefix[row + box.EastEnd.Raw] - _prefix[row + box.East.Raw];
            if (work is not null) { work.PrefixReads += 2; }
            if (here == 0) { continue; }
            total += here;
            totals[written++] = total;
            totals[written++] = box.North.Raw + offset;
        }
        return new PreparedDraws(this, buildings, box, totals[..written], total, work);
    }

    internal readonly ref struct PreparedDraws
    {
        private readonly BuildingResidency _owner;
        private readonly BuildingTable _buildings;
        private readonly CellRect _box;
        private readonly ReadOnlySpan<int> _totals;
        private readonly BuildingQueryWork? _work;
        private readonly ulong _version;
        internal int Count { get; }

        internal PreparedDraws(BuildingResidency owner, BuildingTable buildings, CellRect box,
            ReadOnlySpan<int> totals, int count, BuildingQueryWork? work)
        {
            _owner = owner; _buildings = buildings; _box = box; _totals = totals; _work = work;
            _version = owner._version;
            Count = count;
        }

        internal int Nth(int ordinal)
        {
            ArgumentOutOfRangeException.ThrowIfNegative(ordinal);
            if (_version != _owner._version) { throw new InvalidOperationException("Building index changed during prepared draws."); }
            if (_work is not null) { _work.CandidateCalls++; }
            if (ordinal >= Count) { return Rows.NoSlot; }
            int rows = IntegerMath.FloorDiv(_totals.Length, 2);
            int low = 0, high = rows - 1;
            if (rows > 1)
            {
                // Equal row counts make this exact; skewed rows retain the binary-search fallback.
                int guess = (int)IntegerMath.FloorDiv((long)ordinal * rows, Count);
                if (_work is not null && guess > 0) { _work.PrefixReads++; }
                if (guess > 0 && ordinal < _totals[(guess - 1) * 2]) { high = guess - 1; }
                else
                {
                    if (_work is not null) { _work.PrefixReads++; }
                    if (ordinal < _totals[guess * 2]) { low = high = guess; }
                    else { low = guess + 1; }
                }
            }
            while (low < high)
            {
                int middle = low + IntegerMath.FloorDiv(high - low, 2);
                if (_work is not null) { _work.PrefixReads++; }
                if (_totals[middle * 2] <= ordinal) { low = middle + 1; }
                else { high = middle; }
            }
            int north = _totals[low * 2 + 1];
            int row = north * PrefixStride;
            int before = low == 0 ? 0 : _totals[(low - 1) * 2];
            int rowCount = _totals[low * 2] - before;
            int rank = ordinal - before + _owner._prefix[row + _box.East.Raw];
            if (_work is not null) { _work.PrefixReads += low == 0 ? 3 : 4; }
            low = _box.East.Raw; high = _box.EastEnd.Raw - 1;
            int first = _owner._firstColumn[north], last = _owner._lastColumn[north];
            if (_work is not null) { _work.PrefixReads += 2; }
            if (low < first) { low = first; }
            if (high > last) { high = last; }
            if (low < high)
            {
                int guess = low + (int)IntegerMath.FloorDiv((long)(ordinal - before) * (high - low + 1), rowCount);
                if (_work is not null) { _work.PrefixReads++; }
                if (rank < _owner._prefix[row + guess]) { high = guess - 1; }
                else
                {
                    if (_work is not null) { _work.PrefixReads++; }
                    if (rank < _owner._prefix[row + guess + 1]) { low = high = guess; }
                    else { low = guess + 1; }
                }
            }
            while (low < high)
            {
                int middle = low + IntegerMath.FloorDiv(high - low, 2);
                if (_work is not null) { _work.PrefixReads++; }
                if (_owner._prefix[row + middle + 1] <= rank) { low = middle + 1; }
                else { high = middle; }
            }
            int remaining = rank - _owner._prefix[row + low];
            if (_work is not null) { _work.PrefixReads++; _work.CandidateLinks += remaining; }
            int encoded = _owner._head[CellGrid.Index(new Cells(low), new Cells(north))];
            Span<int> next = _buildings.CellNext.Span;
            for (int i = 0; i < remaining; i++) { encoded = next[encoded - 1]; }
            return encoded - 1;
        }
    }
}
