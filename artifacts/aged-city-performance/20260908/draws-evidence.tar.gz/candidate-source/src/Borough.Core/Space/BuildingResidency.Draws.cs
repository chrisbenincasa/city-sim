using Borough.Core.Entities;
using Borough.Core.Quantities;
using Borough.Core.Tables;
using System.Runtime.CompilerServices;

namespace Borough.Core.Space;

public sealed partial class BuildingResidency
{
    private ulong _version;
    // Execution cutoff: shorter expected scans retain NthIn. It does not affect candidate choices.
    private const int MinimumPreparedRows = 24;

    // Caller-owned scratch, unchanged until the draws finish. Index mutations invalidate the query.
    internal PreparedDraws PrepareDraws(CellRect area, BuildingTable buildings, Span<int> totals,
        BuildingQueryWork? work = null)
    {
        ArgumentNullException.ThrowIfNull(buildings);
        CellRect box = area.Clamp();
        int height = box.Height.Raw;
        if (totals.Length < height * 2) { throw new ArgumentException("Row totals need two entries per row.", nameof(totals)); }
        if (work is not null) { work.CountCalls++; }
        int total = 0, written = 0;
        long weightedRows = 0;
        for (int offset = 0; offset < height; offset++)
        {
            int row = PrefixRow(box.North.Raw + offset, work);
            int here = _prefix[row + box.EastEnd.Raw] - _prefix[row + box.East.Raw];
            if (work is not null) { work.PrefixReads += 2; }
            if (here == 0) { continue; }
            total += here;
            weightedRows += (long)here * (offset + 1);
            totals[written++] = total;
            totals[written++] = box.North.Raw + offset;
        }
        return new PreparedDraws(this, buildings, box, totals[..written], total,
            total > 0 && weightedRows >= (long)total * MinimumPreparedRows, work);
    }

    internal readonly ref struct PreparedDraws
    {
        private readonly BuildingResidency _owner;
        private readonly BuildingTable _buildings;
        private readonly CellRect _box;
        private readonly ReadOnlySpan<int> _totals;
        private readonly BuildingQueryWork? _work;
        private readonly ulong _version;
        private readonly bool _prepared;
        internal int Count { get; }

        internal PreparedDraws(BuildingResidency owner, BuildingTable buildings, CellRect box,
            ReadOnlySpan<int> totals, int count, bool prepared, BuildingQueryWork? work)
        {
            _owner = owner; _buildings = buildings; _box = box; _totals = totals; _work = work;
            _version = owner._version;
            _prepared = prepared;
            Count = count;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal int Nth(int ordinal)
        {
            if (_version != _owner._version) { throw new InvalidOperationException("Building index changed during prepared draws."); }
            return _prepared ? NthPrepared(ordinal) : _owner.NthIn(_box, _buildings, ordinal, _work);
        }

        private int NthPrepared(int ordinal)
        {
            BuildingResidency owner = _owner;
            BuildingTable buildings = _buildings;
            CellRect box = _box;
            ReadOnlySpan<int> totals = _totals;
            BuildingQueryWork? work = _work;
            ArgumentOutOfRangeException.ThrowIfNegative(ordinal);
            if (work is not null) { work.CandidateCalls++; work.PreparedCalls++; }
            if (ordinal >= Count) { return Rows.NoSlot; }
            int low = 0, high = (totals.Length >> 1) - 1;
            while (low < high)
            {
                int middle = low + ((high - low) >> 1);
                if (work is not null) { work.PrefixReads++; }
                int earlier = (int)(((long)ordinal - totals[middle * 2]) >> 63);
                low = (middle + 1) ^ (((middle + 1) ^ low) & earlier);
                high ^= (middle ^ high) & earlier;
            }
            int north = totals[low * 2 + 1];
            int row = north * PrefixStride;
            int before = low == 0 ? 0 : totals[(low - 1) * 2];
            int rank = ordinal - before + owner._prefix[row + box.East.Raw];
            if (work is not null) { work.PrefixReads += low == 0 ? 2 : 3; }
            low = box.East.Raw; high = box.EastEnd.Raw - 1;
            while (low < high)
            {
                int middle = low + ((high - low) >> 1);
                if (work is not null) { work.PrefixReads++; }
                // -1 selects the earlier half; widening keeps the subtraction exact.
                int earlier = (int)(((long)rank - owner._prefix[row + middle + 1]) >> 63);
                low = (middle + 1) ^ (((middle + 1) ^ low) & earlier);
                high ^= (middle ^ high) & earlier;
            }
            int remaining = rank - owner._prefix[row + low];
            if (work is not null) { work.PrefixReads++; work.CandidateLinks += remaining; }
            int encoded = owner._head[CellGrid.Index(new Cells(low), new Cells(north))];
            Span<int> next = buildings.CellNext.Span;
            for (int i = 0; i < remaining; i++) { encoded = next[encoded - 1]; }
            return encoded - 1;
        }
    }
}
