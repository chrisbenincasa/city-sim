import hashlib,json,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
rules=p/'wide-streets.toml'
text=Path('rulesets/stress-shopping.toml').read_text().replace('block_tiles                    = 32','block_tiles                    = 128')
rules.write_text(text)
activity='StartTick Ticks Citizens Buildings Employed PeakTravellers PeakVehicles VehicleTicks LoadedSegmentTicks CongestedSegmentTicks PeakVolumeCapacity CompletedTrips NoRoute OverBudget DriveLegs WalkLegs ShoppingOutings Purchases DeliveredGoods Wages RuleEvaluations RoutePrepared RouteUsed RouteFallback CivicEvents'.split()
results={}
for seed in (0,1):
 results[seed]={}
 for build in (('before','after') if seed==0 else ('after','before')):
  label=f'wide-{seed}-{build}'
  command=['dotnet',str(p/build/'Borough.Headless.dll'),'--profile','--ruleset',str(rules),'--citizens','10000','--seed',str(seed),'--warmup-ticks','14336','--ticks','2048','--no-decide-guard']
  (p/(label+'-command.json')).write_text(json.dumps({'command':command,'conditions':'Release .NET 10.0.2, M4 Pro desktop, one simulation thread; sequential without overlapping tests/builds. Same stress content except block_tiles=128; local diagnostics.'},indent=2)+'\n')
  print(label,flush=True)
  with (p/(label+'.jsonl')).open('x') as log,(p/(label+'.err')).open('x') as err:
   subprocess.run(command,stdout=log,stderr=err,check=True)
  rows=[json.loads(s) for s in (p/(label+'.jsonl')).read_text().splitlines()]
  assert rows[-1].get('invariants')=='passed'
  results[seed][build]={'sample':next(r for r in rows if 'MeanMs' in r),'end':rows[-1]}
 b=results[seed]['before'];a=results[seed]['after']
 assert a['end']==b['end']
 assert all(a['sample'][k]==b['sample'][k] for k in activity)
 print(seed,b['sample']['MeanMs'],a['sample']['MeanMs'],flush=True)
(p/'wide-checks.json').write_text(json.dumps(results,indent=2)+'\n')
