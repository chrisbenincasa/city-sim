import argparse, hashlib, json, pathlib, subprocess
parser=argparse.ArgumentParser()
parser.add_argument('group',choices=['hundred','repeat','small','million','counted'])
args=parser.parse_args()
root=pathlib.Path('/Users/cbeni/code/city-sim')
out=pathlib.Path(__file__).resolve().parent
runs={
 'hundred': [('hundred-0-before','before',0,100000,1,2048,False),('hundred-0-after','after',0,100000,1,2048,False),('hundred-1-after','after',1,100000,1,2048,False),('hundred-1-before','before',1,100000,1,2048,False)],
 'repeat': [('hundred-0-after-repeat','after',0,100000,1,2048,False),('hundred-0-before-repeat','before',0,100000,1,2048,False),('hundred-1-before-repeat','before',1,100000,1,2048,False),('hundred-1-after-repeat','after',1,100000,1,2048,False)],
 'small': [('small-before','before',0,1000,1,14336,False),('small-after','after',0,1000,1,14336,False)],
 'million': [('million-1-before','before',0,1000000,1,2048,False),('million-1-after','after',0,1000000,1,2048,False),('million-8-after','after',0,1000000,8,2048,False),('million-8-before','before',0,1000000,8,2048,False)],
 'counted': [('hundred-0-counted-before','before',0,100000,1,2048,True),('hundred-0-counted-after','after',0,100000,1,2048,True)]
}[args.group]
for label,build,seed,population,workers,ticks,counted in runs:
 save=pathlib.Path('/tmp/borough-capacity-20260907/small.save' if population==1000 else f'/tmp/borough-capacity-20260907/hundred-{seed}.save' if population==100000 else '/tmp/borough-layers-20260907/million-day6.save')
 command=['dotnet',str(out/build/'Borough.Headless.dll'),'--profile','--ruleset','rulesets/stress-shopping.toml','--citizens',str(population),'--seed',str(seed),'--profile-load',str(save),'--warmup-ticks','14336','--ticks',str(ticks),'--route-workers',str(workers),'--no-decide-guard']
 if counted: command.append('--profile-work')
 h=hashlib.sha256()
 with save.open('rb') as source:
  for block in iter(lambda:source.read(1024*1024),b''): h.update(block)
 metadata=dict(command=command,checkpointSha256=h.hexdigest(),conditions='Release .NET 10.0.2, M4 Pro desktop, sequential captures without overlapping tests/builds; worker limit includes caller. Local diagnostics, not budget ratification.')
 with (out/(label+'-command.json')).open('x') as f: json.dump(metadata,f,indent=2)
 print(label,flush=True)
 with (out/(label+'.jsonl')).open('x') as log,(out/(label+'.err')).open('x') as errors:
  subprocess.run(command,cwd=root,stdout=log,stderr=errors,check=True)
 rows=[json.loads(s) for s in (out/(label+'.jsonl')).read_text().splitlines()]
 assert rows[-1].get('invariants')=='passed'
 print(json.dumps([r for r in rows if 'MeanMs' in r]+[rows[-1]]),flush=True)
 if counted:
  with (out/(label+'-summary.txt')).open('x') as f:
   subprocess.run(['python3','scripts/summarize-work-profile.py',str(out/(label+'.jsonl')),'--output',str(out/(label+'-summary.json'))],cwd=root,stdout=f,check=True)
