; Assembly listing for method Borough.Core.Space.BuildingResidency+PreparedDraws:Nth(int):int:this (FullOpts)
; Emitting BLENDED_CODE for generic ARM64 on Apple
; FullOpts code
; optimized code
; fp based frame
; fully interruptible
; No PGO data
; 2 inlinees with PGO data; 38 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
            stp     fp, lr, [sp, #-0x30]!
            stp     x19, x20, [sp, #0x18]
            str     x21, [sp, #0x28]
            mov     fp, sp
            mov     w19, w1
 
G_M000_IG02:                ;; offset=0x0014
            ldp     x1, x2, [x0]
            ldr     w3, [x0, #0x24]
            ldr     w4, [x0, #0x2C]
            ldr     x5, [x0, #0x38]
            ldr     w6, [x0, #0x40]
            ldr     x7, [x0, #0x10]
            tbnz    w19, #31, G_M000_IG30
            ldr     x8, [x0, #0x18]
            ldr     x9, [x1, #0x30]
            cmp     x8, x9
            bne     G_M000_IG31
            cbz     x7, G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0044
            ldr     x8, [x7, #0x28]
            add     x8, x8, #1
            str     x8, [x7, #0x28]
 
G_M000_IG04:                ;; offset=0x0050
            ldr     w0, [x0, #0x20]
            cmp     w19, w0
            bge     G_M000_IG28
 
G_M000_IG05:                ;; offset=0x005C
            mov     w0, wzr
            cbz     w6, G_M000_IG34
            ldr     w8, [x5]
            cmp     w8, w19
            bgt     G_M000_IG09
            align   [0 bytes for IG06]
            align   [0 bytes]
            align   [0 bytes]
            align   [0 bytes]
 
G_M000_IG06:                ;; offset=0x0070
            cbz     x7, G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0074
            ldr     x8, [x7, #0x08]
            add     x8, x8, #1
            str     x8, [x7, #0x08]
 
G_M000_IG08:                ;; offset=0x0080
            add     w0, w0, #1
            lsl     w8, w0, #1
            cmp     w8, w6
            bhs     G_M000_IG34
            ldr     w8, [x5, w8, UXTW #2]
            cmp     w8, w19
            ble     G_M000_IG06
 
G_M000_IG09:                ;; offset=0x009C
            cbz     x7, G_M000_IG10
            ldr     x8, [x7, #0x08]
            add     x8, x8, #1
            str     x8, [x7, #0x08]
 
G_M000_IG10:                ;; offset=0x00AC
            lsl     w8, w0, #1
            add     w9, w8, #1
            cmp     w9, w6
            bhs     G_M000_IG34
            ldr     w9, [x5, w9, UXTW #2]
            mov     w10, #513
            mul     w10, w9, w10
            cbnz    w0, G_M000_IG11
            mov     w11, wzr
            b       G_M000_IG12
            align   [0 bytes for IG14]
            align   [0 bytes]
            align   [0 bytes]
            align   [0 bytes]
 
G_M000_IG11:                ;; offset=0x00D4
            sub     w11, w8, #2
            cmp     w11, w6
            bhs     G_M000_IG34
            ldr     w11, [x5, w11, UXTW #2]
 
G_M000_IG12:                ;; offset=0x00E4
            ldr     x5, [x1, #0x10]
            sub     w6, w19, w11
            add     w8, w10, w3
            ldr     w11, [x5, #0x08]
            cmp     w8, w11
            bhs     G_M000_IG34
            add     x5, x5, #16
            ldr     w8, [x5, w8, UXTW #2]
            add     w6, w6, w8
            cbz     x7, G_M000_IG13
            ldr     x8, [x7, #0x08]
            mov     w13, #2
            cmp     w0, #0
            cinc    w0, w13, ne
            add     x0, x8, w0, UXTW
            str     x0, [x7, #0x08]
 
G_M000_IG13:                ;; offset=0x0124
            sxtw    w0, w3
            add     w3, w0, w4
            sub     w3, w3, #1
            cmp     w0, w3
            bge     G_M000_IG22
 
G_M000_IG14:                ;; offset=0x0138
            sub     w4, w3, w0
            add     w4, w0, w4,  ASR #1
            cbz     x7, G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0144
            ldr     x8, [x7, #0x08]
            add     x8, x8, #1
            str     x8, [x7, #0x08]
 
G_M000_IG16:                ;; offset=0x0150
            add     w8, w10, w4
            add     w8, w8, #1
            cmp     w8, w11
            bhs     G_M000_IG34
            ldr     w8, [x5, w8, UXTW #2]
            cmp     w8, w6
            cset    x8, le
            cbz     w8, G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0170
            add     w0, w4, #1
            b       G_M000_IG18
 
G_M000_IG18:                ;; offset=0x0178
            cbz     w8, G_M000_IG20
 
G_M000_IG19:                ;; offset=0x017C
            b       G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0180
            sxtw    w3, w4
 
G_M000_IG21:                ;; offset=0x0184
            cmp     w0, w3
            blt     G_M000_IG14
 
G_M000_IG22:                ;; offset=0x018C
            add     w3, w10, w0
            cmp     w3, w11
            bhs     G_M000_IG34
            ldr     w3, [x5, w3, UXTW #2]
            sub     w19, w6, w3
            cbz     x7, G_M000_IG23
            ldr     x3, [x7, #0x08]
            add     x3, x3, #1
            str     x3, [x7, #0x08]
            ldr     x3, [x7, #0x38]
            add     x3, x3, w19, SXTW
            str     x3, [x7, #0x38]
 
G_M000_IG23:                ;; offset=0x01BC
            ldr     x1, [x1, #0x08]
            add     w0, w0, w9,  LSL #9
            ldr     w3, [x1, #0x08]
            cmp     w0, w3
            bhs     G_M000_IG34
            add     x1, x1, #16
            ldr     w20, [x1, w0, UXTW #2]
            ldr     x0, [x2, #0x70]
            ldr     x1, [x0, #0x20]
            ldr     x0, [x0, #0x10]
            ldr     w0, [x0, #0x4C]
            cbz     x1, G_M000_IG32
            ldr     w2, [x1, #0x08]
            cmp     w2, w0
            blo     G_M000_IG33
            add     x21, x1, #16
 
G_M000_IG24:                ;; offset=0x01FC
            cmp     w19, #0
            ble     G_M000_IG26
            align   [0 bytes for IG25]
            align   [0 bytes]
            align   [0 bytes]
            align   [0 bytes]
 
G_M000_IG25:                ;; offset=0x0204
            sub     w1, w20, #1
            cmp     w1, w0
            bhs     G_M000_IG34
            ldr     w20, [x21, w1, UXTW #2]
            sub     w19, w19, #1
            cbnz    w19, G_M000_IG25
 
G_M000_IG26:                ;; offset=0x021C
            sub     w0, w20, #1
 
G_M000_IG27:                ;; offset=0x0220
            ldr     x21, [sp, #0x28]
            ldp     x19, x20, [sp, #0x18]
            ldp     fp, lr, [sp], #0x30
            ret     lr
 
G_M000_IG28:                ;; offset=0x0230
            movn    w0, #0
 
G_M000_IG29:                ;; offset=0x0234
            ldr     x21, [sp, #0x28]
            ldp     x19, x20, [sp, #0x18]
            ldp     fp, lr, [sp], #0x30
            ret     lr
 
G_M000_IG30:                ;; offset=0x0244
            mov     w0, #0x43D1
            movz    x1, #0xDFF0
            movk    x1, #0xD78 LSL #16
            movk    x1, #1 LSL #32
            movz    x2, #0xC8D0
            movk    x2, #0xD6B LSL #16
            movk    x2, #1 LSL #32
            ldr     x2, [x2]
            blr     x2
            mov     x1, x0
            mov     w0, w19
            movz    x2, #0xD398
            movk    x2, #0xE29 LSL #16
            movk    x2, #1 LSL #32
            ldr     x2, [x2]
            blr     x2
            brk     #0
 
G_M000_IG31:                ;; offset=0x0288
            movz    x0, #0x5E98
            movk    x0, #0xDBF LSL #16
            movk    x0, #1 LSL #32
            bl      CORINFO_HELP_NEWSFAST
            mov     x19, x0
            movz    w0, #0x2130
            movk    w0, #1 LSL #16
            movz    x1, #0xDFF0
            movk    x1, #0xD78 LSL #16
            movk    x1, #1 LSL #32
            movz    x2, #0xC8D0
            movk    x2, #0xD6B LSL #16
            movk    x2, #1 LSL #32
            ldr     x2, [x2]
            blr     x2
            mov     x1, x0
            mov     x0, x19
            movz    x2, #0x4A08
            movk    x2, #0xE29 LSL #16
            movk    x2, #1 LSL #32
            ldr     x2, [x2]
            blr     x2
            mov     x0, x19
            bl      CORINFO_HELP_THROW
            brk     #0
 
G_M000_IG32:                ;; offset=0x02EC
            cbnz    w0, G_M000_IG33
            mov     x21, xzr
            mov     w0, wzr
            b       G_M000_IG24
 
G_M000_IG33:                ;; offset=0x02FC
            movz    x0, #0xCA08
            movk    x0, #0xD6B LSL #16
            movk    x0, #1 LSL #32
            ldr     x0, [x0]
            blr     x0
            brk     #0
 
G_M000_IG34:                ;; offset=0x0314
            bl      CORINFO_HELP_RNGCHKFAIL
            brk     #0
 
; Total bytes of code 796

