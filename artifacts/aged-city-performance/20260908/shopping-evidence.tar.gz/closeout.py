import hashlib, json, shutil
from pathlib import Path
out=Path(__file__).resolve().parent
root=Path('/Users/cbeni/code/city-sim')
activity='StartTick Ticks Citizens Buildings Employed PeakTravellers PeakVehicles VehicleTicks LoadedSegmentTicks CongestedSegmentTicks PeakVolumeCapacity CompletedTrips NoRoute OverBudget DriveLegs WalkLegs ShoppingOutings Purchases DeliveredGoods Wages RuleEvaluations RoutePrepared RouteUsed RouteFallback CivicEvents'.split()
def read(path): return [json.loads(s) for s in path.read_text().splitlines()]
checks=json.loads((out/'checks.json').read_text())
for label,trace in [('hundred-0-counted','trace'),('million-0-counted','million-trace')]:
    counted=read(out/(label+'.jsonl')); traced=read(out/trace/'run.jsonl')
    a=next(r for r in counted if 'MeanMs' in r); b=next(r for r in traced if 'MeanMs' in r)
    assert counted[-1]==traced[-1]
    assert all(a[k]==b[k] for k in activity)
    checks[label]['tracedActivityAndHashMatch']=True
prior=out/'prior-hundred-counted.jsonl'
shutil.copy2('/tmp/borough-viability-20260907/hundred-counted-after.jsonl',prior)
before=[r for r in read(prior) if r.get('type')=='work']
after=[r for r in read(out/'hundred-0-counted.jsonl') if r.get('type')=='work']
assert len(before)==len(after)==2048
for old,new in zip(before,after):
    for k in ('tick','travellers','vehicles','shopping','shoppingRoutes','otherRoutes'):
        assert old[k]==new[k],(old['tick'],k)
    for k,v in old['shoppingWork'].items(): assert new['shoppingWork'][k]==v,(old['tick'],k)
checks['previousPerTickCountersMatch']=True
for directory in ('trace','million-trace'):
    report=json.loads((out/directory/'step.json').read_text())
    checks[directory]={k:report[k] for k in ('step_weight_ms','move_weight_ms_by_work','building_selection_weight_ms_by_caller')}
    checks[directory]['methods']=report['methods'][:15]
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
for filename in ('src/Borough.Core/Rules/ShoppingWork.cs','src/Borough.Core/Rules/ShoppingEngine.cs','tests/Borough.Tests/Headless/ProfileDumpTests.cs','plans/0067-aged-city-performance.md'):
    target=out/'source'/filename
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/filename,target)
print('Trace/control activity, end hashes and prior per-Tick counters match.')
