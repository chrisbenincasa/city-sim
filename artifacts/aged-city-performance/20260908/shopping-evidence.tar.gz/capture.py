import hashlib, json, pathlib, subprocess
root = pathlib.Path('/Users/cbeni/code/city-sim')
out = pathlib.Path('/tmp/borough-shopping-20260908')
for label, build, seed, population, counted in [
    ('hundred-0-before', 'before', 0, 100000, False),
    ('hundred-0-observed', 'observed', 0, 100000, False),
    ('hundred-1-observed', 'observed', 1, 100000, False),
    ('hundred-1-before', 'before', 1, 100000, False),
    ('hundred-0-counted', 'observed', 0, 100000, True),
    ('hundred-1-counted', 'observed', 1, 100000, True),
    ('million-0-counted', 'observed', 0, 1000000, True),
]:
    save = pathlib.Path(f'/tmp/borough-capacity-20260907/hundred-{seed}.save' if population == 100000 else '/tmp/borough-layers-20260907/million-day6.save')
    command = ['dotnet', str(out / build / 'Borough.Headless.dll'), '--profile', '--ruleset', 'rulesets/stress-shopping.toml', '--citizens', str(population), '--seed', str(seed), '--profile-load', str(save), '--warmup-ticks', '14336', '--ticks', '2048', '--no-decide-guard']
    if counted: command.append('--profile-work')
    digest = hashlib.sha256()
    with save.open('rb') as source:
        for block in iter(lambda: source.read(1024*1024), b''): digest.update(block)
    metadata = dict(command=command, checkpointSha256=digest.hexdigest(), conditions='Release, M4 Pro desktop, one simulation thread; sequential captures, no overlapping tests/builds; local diagnostics only')
    (out / (label + '-command.json')).write_text(json.dumps(metadata, indent=2)+'\n')
    print(label, flush=True)
    with (out / (label + '.jsonl')).open('w') as log, (out / (label + '.err')).open('w') as errors:
        subprocess.run(command, cwd=root, stdout=log, stderr=errors, check=True)
    if counted:
        with (out / (label + '-summary.txt')).open('w') as log:
            subprocess.run(['python3', 'scripts/summarize-work-profile.py', str(out / (label + '.jsonl')), '--output', str(out / (label + '-summary.json'))], cwd=root, stdout=log, check=True)
print('complete', flush=True)
