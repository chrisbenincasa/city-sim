import hashlib,json,shutil,tarfile
from pathlib import Path
out=Path(__file__).resolve().parent
root=Path('/Users/cbeni/code/city-sim')
destination=root/'artifacts/aged-city-performance/20260908'
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()
for log in ('/tmp/borough-test-20260908-081414.log','/tmp/borough-test-20260908-082421.log'):
    shutil.copy2(log,out/Path(log).name)
files={str(p.relative_to(out)):{'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file()}
archive=destination/'shopping-evidence.tar.gz'
assert not archive.exists(),archive
with tarfile.open(archive,'w:gz') as tar:
    for name in files: tar.add(out/name,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for member in tar.getmembers():
        data=tar.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
manifest=dict(archive=archive.name,sha256=digest(archive),bytes=archive.stat().st_size,files=files,verified=True,excluded='Reproducible checkpoints; hashes and reproduction commands are retained.')
(destination/'shopping-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copy2(out/'checks.json',destination/'shopping-checks.json')
print(f'Verified {len(files)} files; archive {archive.stat().st_size} bytes: {archive}')
