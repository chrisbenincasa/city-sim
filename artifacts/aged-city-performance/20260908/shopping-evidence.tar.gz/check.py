import json
from pathlib import Path
out=Path(__file__).resolve().parent
activity = 'StartTick Ticks Citizens Buildings Employed PeakTravellers PeakVehicles VehicleTicks LoadedSegmentTicks CongestedSegmentTicks PeakVolumeCapacity CompletedTrips NoRoute OverBudget DriveLegs WalkLegs ShoppingOutings Purchases DeliveredGoods Wages RuleEvaluations RoutePrepared RouteUsed RouteFallback CivicEvents'.split()
def records(label): return [json.loads(s) for s in (out/(label+'.jsonl')).read_text().splitlines()]
def sample(rows): return next(r for r in rows if 'MeanMs' in r)
checks={}
for seed in (0,1):
    names=[f'hundred-{seed}-{suffix}' for suffix in ('before','observed','counted')]
    captures=[records(n) for n in names]
    control=sample(captures[0])
    for name,rows in zip(names,captures):
        assert rows[-1]==captures[0][-1],name
        assert all(sample(rows)[k]==control[k] for k in activity),name
        checks[name]={k:sample(rows)[k] for k in ('MeanMs','P95Ms','P99Ms','MaxMs','AllocatedBytes')}
        checks[name]['hash']=rows[-1]['hash']
for name in ('hundred-0-counted','hundred-1-counted','million-0-counted'):
    rows=records(name)
    assert rows[-1]['invariants']=='passed'
    work=[r['shoppingWork'] for r in rows if r.get('type')=='work']
    assert len(work)==2048
    for w in work:
        assert w['Draws']==w['Selection']['CandidateCalls']
        assert w['BusinessesChecked']==sum(w[k] for k in ('NoSaleBin','AlreadyKnown','DiscoveryRouteRejected','ProvidersAdded'))
        assert w['DiscoveryWithoutAddition']<=w['DiscoveryCalls']
    totals={k:sum(w[k] for w in work) for k in work[0] if isinstance(work[0][k],int)}
    totals['indexReads']=sum(w['Selection'][k] for w in work for k in ('PrefixReads','RebuiltCells','CandidateCells','CountCells'))
    totals['discoveryRouteChecks']=totals['DiscoveryRouteRejected']+totals['ProvidersAdded']
    totals['failedDiscoveryShare']=totals['DiscoveryWithoutAddition']/totals['DiscoveryCalls']
    totals['noSaleBinShareOfBusinesses']=totals['NoSaleBin']/totals['BusinessesChecked']
    totals['drawsPerAddedProvider']=totals['Draws']/totals['ProvidersAdded']
    totals['hash']=rows[-1]['hash']
    totals['activity']={k:sample(rows)[k] for k in activity}
    checks.setdefault(name, {})['discovery']=totals

(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
