using Borough.Core;
using Borough.Core.Entities;
using Borough.Core.Quantities;
using Borough.Core.Rules;
using Borough.Core.Tables;

namespace Borough.Tests.Rules;

public sealed class ShoppingSaleBinTests
{
    [Fact]
    public void Repeated_shopping_eligibility_does_not_walk_owner_bins()
    {
        var (world, sim) = ShoppingTests.Start();
        for (int t = 0; t < 2048; t++) { sim.Step(default); }
        var work = new ShoppingWork();
        sim.Shopping.Work = work;
        CheckAll(world, sim);
        work.Reset();
        ulong hash = world.HashState();
        CheckAll(world, sim);
        Assert.True(work.SaleBinChecks > 100);
        Assert.Equal(0, work.SaleBinOwnerLinks);
        Assert.Equal(hash, world.HashState());
    }

    [Fact]
    public void Eligibility_follows_loss_and_restoration_of_premises_and_rebuild()
    {
        var (world, sim) = ShoppingTests.Start();
        for (int t = 0; t < 2048; t++) { sim.Step(default); }
        CheckAll(world, sim);
        int seller = Enumerable.Range(0, world.Businesses.Rows.SlotCount).First(b =>
            world.Businesses.Rows.IsLive(b) && Enumerable.Range(1, world.Rules.ResourceCount)
                .Any(r => Expected(world, b, new ResourceId((ushort)r)) >= 0));
        var business = world.Businesses.Rows.At(seller);
        var building = world.Businesses.Building[seller];
        world.Unpremise(business, world.Tick);
        CheckAll(world, sim);
        world.Premise(business, building);
        CheckAll(world, sim);
        world.RebuildDerived();
        CheckAll(world, sim);
    }

    private static void CheckAll(World world, Simulation sim)
    {
        for (int b = 0; b < world.Businesses.Rows.SlotCount; b++)
        for (int r = 1; r <= world.Rules.ResourceCount; r++)
        {
            var good = new ResourceId((ushort)r);
            Assert.Equal(Expected(world, b, good), sim.Shopping.StockBin(b, good));
        }
    }

    private static int Expected(World world, int business, ResourceId good)
    {
        if (!world.Businesses.Rows.IsLive(business)) { return -1; }
        for (var at = world.Businesses.BinHead[business]; world.Bins.Rows.TryResolve(at, out int bin);
             at = world.Bins.OwnerNext[bin])
        {
            if (world.Bins.Resource[bin] == good)
            { return world.Markets.MarketOf(world, bin) >= 0 ? bin : -1; }
        }
        return -1;
    }
}
