from pathlib import Path
import json
p=Path(__file__).parent
skip={'MeanMs','P95Ms','P99Ms','MaxMs','MaxTick','AllocatedBytes','ManagedHeapBytes','WorkingSetBytes','Gen0Collections','Gen1Collections','Gen2Collections'}
def read(stem):
 rows=[json.loads(s) for s in (p/(stem+'.jsonl')).read_text().splitlines()]
 assert rows[-1].get('type')=='end' and rows[-1]['invariants']=='passed'
 return {'file':stem,'conditions':rows[0],'daily':next(r for r in rows if 'MeanMs' in r),'end':rows[-1]}
def pair(before,after):
 a,b=read(before),read(after)
 assert a['end']==b['end']
 assert {k:v for k,v in a['daily'].items() if k not in skip}=={k:v for k,v in b['daily'].items() if k not in skip}
 return {'before':a,'after':b,'activity_hash_equal':True,'mean_improvement_percent':100*(a['daily']['MeanMs']-b['daily']['MeanMs'])/a['daily']['MeanMs']}
pairs=[pair('before-1788893896','shift-1788893841'),pair('before-1788894037','shift-1788894094')]
seed1=[]
for f in sorted(p.glob('*.command.json')):
 m=json.loads(f.read_text())
 if m.get('seed')==1: seed1.append((f.name.replace('.command.json',''),m['build']))
seed1.sort(key=lambda r:int(r[0].split('-')[-1]))
excluded_seed1=seed1[:-4]
seed1=seed1[-4:]
if len(seed1)==4:
 assert [r[1] for r in seed1]==['before','shift','shift','before']
 pairs.extend([pair(seed1[0][0],seed1[1][0]),pair(seed1[3][0],seed1[2][0])])
result={'pairs':pairs,'two_seeds_complete':len(pairs)==4,'retained':False,'reason':'Seed 1 comparisons disagree despite temporary browser affinity isolation; repeatability gate not met.','excluded_seed1':excluded_seed1,'chrome_affinity':json.loads((p/'chrome-affinity.json').read_text()),'scope':'Release i5-10400 desktop, .NET 10.0.11, one simulation thread pinned to CPU 2, 100000 Citizens, stress-shopping.toml, checkpoint 16384, warm 18432, measure 2048, Decide guard off. Not budget ratification.','eligibility':json.loads((p/'eligibility-checks.json').read_text())}
(p/'reuse-checks.json').write_text(json.dumps(result,indent=2))
for r in pairs:print(r['before']['conditions']['Seed'],round(r['mean_improvement_percent'],3),r['before']['daily']['MeanMs'],r['after']['daily']['MeanMs'])
