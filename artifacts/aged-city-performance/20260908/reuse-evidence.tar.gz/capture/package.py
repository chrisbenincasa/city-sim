from pathlib import Path
import json,tarfile,hashlib
p=Path(__file__).parent; root=Path('/home/christian/Code/city-sim'); out=root/'artifacts/aged-city-performance/20260908'
checks=json.loads((p/'reuse-checks.json').read_text()); assert not checks['chrome_affinity']['restore_errors'] and not checks['chrome_affinity']['remaining_restricted']
(out/'reuse-checks.json').write_text(json.dumps(checks,indent=2))
files={'capture/'+str(f.relative_to(p)):f for f in p.rglob('*') if f.is_file() and f.suffix!='.save'}
for name in ['plans/0067-aged-city-performance.md','src/Borough.Core/Movement/WorkSchedule.cs','tests/Borough.Tests/Rules/PayrollAccrualTests.cs','rulesets/stress-shopping.toml']:
 files['restored-source/'+name]=root/name
for stamp in ['144824','144942','145545','150318','150716','152848']:
 name='borough-test-20260908-'+stamp+'.log';files['validation/'+name]=Path('/tmp')/name
for name in ['checkpoint.json','before-seed0-reproduction.json']:
 files['checkpoint/'+name]=Path('/tmp/borough-payroll')/name
files['checks.json']=out/'reuse-checks.json'
archive=out/'reuse-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,f in sorted(files.items()):t.add(f,arcname=name)
hashes={name:hashlib.sha256(f.read_bytes()).hexdigest() for name,f in files.items()}
with tarfile.open(archive) as t:
 assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==hashes
(out/'reuse-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':hashes,'verified':True,'checkpoints':'Save files excluded; fingerprints and recreation commands retained.'},indent=2))
print('Verified',len(files),'files;',archive.stat().st_size,'bytes')
