import pathlib,json,subprocess,hashlib,time,sys
p=pathlib.Path(__file__).parent;root=pathlib.Path.cwd()
seed=0
if len(sys.argv)>2 and sys.argv[1]=='--seed':
 seed=int(sys.argv[2]);sys.argv=sys.argv[:1]+sys.argv[3:]
for i,name in enumerate(sys.argv[1:]):
 stem=p/f'{name}-seed{seed}-{int(time.time())}';command=['taskset','-c','2','dotnet',str(p/name/'Borough.Headless.dll'),'--profile','--ruleset','rulesets/stress-shopping.toml','--citizens','100000','--seed',str(seed),'--profile-load',('/tmp/borough-payroll/seed0.save' if seed==0 else str(p/'seed1.save')),'--warmup-ticks','18432','--ticks','2048','--no-decide-guard']
 metadata={'command':command,'cwd':str(root),'build':name,'seed':seed,'assembly_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (p/name).glob('Borough.*.dll')}}
 stem.with_suffix('.command.json').write_text(json.dumps(metadata,indent=2))
 with stem.with_suffix('.jsonl').open('w') as output,stem.with_suffix('.err').open('w') as errors,stem.with_suffix('.host.jsonl').open('w') as host:
  process=subprocess.Popen(command,stdout=output,stderr=errors)
  try:
   while True:
    host.write(json.dumps({'time':time.time(),'stat':pathlib.Path('/proc/stat').read_text(),'frequency':pathlib.Path('/sys/devices/system/cpu/cpu2/cpufreq/scaling_cur_freq').read_text()})+'\n');host.flush()
    if process.poll() is not None:break
    time.sleep(1)
  finally:
   if process.poll() is None:process.terminate();process.wait()
  assert process.returncode==0,stem
 rows=[json.loads(s) for s in stem.with_suffix('.jsonl').read_text().splitlines()];daily=next(r for r in rows if 'MeanMs' in r)
 print(json.dumps({'file':str(stem),'build':name,'daily':daily,'end':rows[-1]}),flush=True)
