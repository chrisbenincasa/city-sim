import os,pathlib,subprocess,json,signal,sys,time
p=pathlib.Path(__file__).parent

def tasks():
 for proc in pathlib.Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   if (proc/'comm').read_text().strip()!='chrome' or proc.stat().st_uid!=os.getuid():continue
   for task in (proc/'task').iterdir():
    try:yield int(task.name),frozenset(os.sched_getaffinity(int(task.name)))
    except ProcessLookupError:pass
  except (FileNotFoundError,ProcessLookupError):pass

snapshot=dict(tasks());masks=set(snapshot.values())
if len(masks)!=1:raise RuntimeError('Refusing to change nonuniform Chrome affinities.')
original=next(iter(masks));restricted=original-{2,8}
if not restricted or restricted==original:raise RuntimeError('No safe affinity restriction available.')
record={'original':sorted(original),'temporary':sorted(restricted),'original_threads':sorted(snapshot),'started':time.time(),'command':sys.argv[1:]}
ledger=p/'chrome-affinity.json';ledger.write_text(json.dumps(record,indent=2))
child=None

def stop(signum,frame):raise KeyboardInterrupt
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
try:
 for tid in snapshot:
  try:os.sched_setaffinity(tid,restricted)
  except ProcessLookupError:pass
 child=subprocess.Popen(sys.argv[1:],start_new_session=True)
 code=child.wait()
 if code:raise RuntimeError(f'Capture exited {code}')
finally:
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM);child.wait()
 restored=[];errors=[]
 # New Chrome threads inherit the temporary mask; restore those as well.
 for tid,mask in tasks():
  if mask==restricted:
   try:os.sched_setaffinity(tid,original);restored.append(tid)
   except ProcessLookupError:pass
   except OSError as error:errors.append([tid,str(error)])
 record.update(ended=time.time(),restored_threads=restored,restore_errors=errors,
               remaining_restricted=[tid for tid,mask in tasks() if mask==restricted])
 ledger.write_text(json.dumps(record,indent=2))
 print('Chrome affinity restored:',len(restored),'threads; errors:',len(errors),flush=True)
 if errors or record['remaining_restricted']:raise RuntimeError('Affinity restoration needs attention; inspect ledger.')
