from pathlib import Path
import tarfile,json,hashlib,shutil
repo=Path.cwd();root=Path('/tmp/borough-viability-20260907');out=repo/'artifacts/aged-city-performance/20260908';out.mkdir(parents=True,exist_ok=True)
logs=root/'logs';logs.mkdir(exist_ok=True)
for path in ['/tmp/borough-test-20260907-235449.log','/tmp/borough-test-20260907-235701.log','/tmp/borough-test-20260907-235936.log','/tmp/borough-test-20260908-000051.log','/tmp/borough-test-20260908-000152.log','/tmp/borough-test-20260908-000534.log','/tmp/borough-test-20260908-002157.log']:
    shutil.copy2(path,logs)
import re
for log in list(root.glob('*.log')):
    for name in re.findall(r'full output: (/.+)', log.read_text(errors='replace')):
        path=Path(name.strip())
        if path.exists():shutil.copy2(path,logs)
shutil.copy2('/tmp/borough-capacity-20260907/checkpoint-fingerprints.json',root/'checkpoints.json')
sources=[]
for project in ['Borough.Core','Borough.Formats','Borough.Headless','Borough.Analysers']:
    for p in (repo/'src'/project).rglob('*'):
        if p.is_file() and not any(x in ('bin','obj') for x in p.relative_to(repo/'src'/project).parts) and p.suffix in ('.cs','.csproj','.props','.targets'):
            sources.append(p)
for p in [*repo.glob('*.props'),*repo.glob('*.targets'),*repo.glob('*.sln*'),repo/'global.json',repo/'plans/0067-aged-city-performance.md',repo/'tests/Borough.Tests/Headless/ProfileDumpTests.cs',repo/'tests/Borough.Tests/Movement/DirectedRoutingTests.cs',repo/'tests/Borough.Tests/Movement/RouteWorkerTests.cs',repo/'tests/Borough.Tests/Entities/TwinLatticeTests.cs',repo/'tests/Borough.Tests/Space/DistrictWatershedTests.cs',repo/'rulesets/profile-services.toml',repo/'rulesets/stress-shopping.toml']:
    if p.exists():sources.append(p)
for p in sources:
    target=root/'source'/p.relative_to(repo);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
archive=out/'viability-evidence.tar.gz'
files=sorted(p for p in root.rglob('*') if p.is_file())
manifest=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
with tarfile.open(archive,'w:gz') as tar:
    for p in files:tar.add(p,arcname=str(p.relative_to(root)))
with tarfile.open(archive) as tar:
    for entry in manifest:
        assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest()==entry['sha256'],entry['path']
result={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(out/'viability-manifest.json').write_text(json.dumps(result,indent=2))
shutil.copy2(root/'checks.json',out/'viability-checks.json')
print('Verified',len(files),'files;',archive.stat().st_size,'bytes;',archive)
