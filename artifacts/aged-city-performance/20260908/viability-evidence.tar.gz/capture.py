import json, subprocess, hashlib, pathlib, time
root=pathlib.Path('/tmp/borough-viability-20260907')
def run(name, build, population, seed, save, workers, work=False, rules='rulesets/stress-shopping.toml', warm=14336, ticks=2048, services=False):
    command=[str(root/build/'Borough.Headless'),'--profile','--ruleset',rules,'--citizens',str(population),'--seed',str(seed),'--warmup-ticks',str(warm),'--ticks',str(ticks),'--route-workers',str(workers),'--no-decide-guard']
    if save: command+=['--profile-load',save]
    if work: command+=['--profile-work']
    if services: command+=['--profile-services']
    (root/(name+'-command.json')).write_text(json.dumps({'command':command,'conditions':'Release .NET 10.0.2, M4 Pro, desktop open; captures sequential, no tests/builds overlapping; Step timing excludes setup/reporting. Local diagnostics, not reference-machine ratification.','assemblies':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/build).glob('Borough.*.dll')}},indent=2))
    print('START',name,flush=True)
    with (root/(name+'.jsonl')).open('w') as out, (root/(name+'.err')).open('w') as err:
        subprocess.run(command,stdout=out,stderr=err,check=True)
    records=[json.loads(l) for l in (root/(name+'.jsonl')).read_text().splitlines()]
    assert records[-1].get('invariants')=='passed'
    print('DONE',name,[(r['MeanMs'],r['P99Ms']) for r in records if 'MeanMs' in r],records[-1]['hash'],flush=True)
for seed in (0,1):
    for label,build in [('before','probe-build'),('after','final-build')]:
        run(f'hundred-{seed}-{label}',build,100000,seed,f'/tmp/borough-capacity-20260907/hundred-{seed}.save',1)
for label,build in [('after','final-build'),('before','probe-build')]:
    run('million-8-'+label,build,1000000,0,'/tmp/borough-layers-20260907/million-day6.save',8)
run('services-10000','final-build',10000,0,None,1,rules='rulesets/profile-services.toml',warm=65536,ticks=14336,services=True)
print('ALL DONE',flush=True)
