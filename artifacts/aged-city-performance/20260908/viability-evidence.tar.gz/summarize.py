import json, pathlib
root=pathlib.Path('/tmp/borough-viability-20260907')
def read(name):
    rows=[json.loads(l) for l in (root/(name+'.jsonl')).read_text().splitlines()]
    assert rows[-1].get('invariants')=='passed',name
    return [r for r in rows if 'MeanMs' in r],rows[-1]
activity=['StartTick','Ticks','Citizens','Buildings','Employed','PeakTravellers','PeakVehicles','VehicleTicks','LoadedSegmentTicks','CongestedSegmentTicks','PeakVolumeCapacity','CompletedTrips','NoRoute','OverBudget','DriveLegs','WalkLegs','ShoppingOutings','Purchases','DeliveredGoods','Wages','RuleEvaluations','RoutePrepared','RouteUsed','RouteFallback','CivicEvents']
checks={}
for pair in ['hundred-0','hundred-1','million-8','hundred-counted','small','small-repeat','small-no-tiering']:
    if not (root/(pair+'-after.jsonl')).exists():continue
    before,bend=read(pair+'-before');after,aend=read(pair+'-after')
    assert bend==aend,(pair,bend,aend)
    assert len(before)==len(after)
    for b,a in zip(before,after):
        for key in activity:assert a[key]==b[key],(pair,key,b[key],a[key])
    checks[pair]={'hash':aend['hash'],'activityEqual':True,'days':[{'start':b['StartTick'],'before':{k:b[k] for k in ['MeanMs','P95Ms','P99Ms','MaxMs','AllocatedBytes']},'after':{k:a[k] for k in ['MeanMs','P95Ms','P99Ms','MaxMs','AllocatedBytes']},'meanReductionPercent':100*(1-a['MeanMs']/b['MeanMs']),'p99ReductionPercent':100*(1-a['P99Ms']/b['P99Ms'])} for b,a in zip(before,after)]}
    if pair=='hundred-counted':
        totals=[]
        for label in ['before','after']:
            rows=[json.loads(l) for l in (root/(pair+'-'+label+'.jsonl')).read_text().splitlines()]
            work=[r for r in rows if r.get('type')=='work']
            totals.append({category:{k:sum((r['shoppingWork']['Estimates'] if category=='estimates' else r[category])[k] for r in work) for k in ['Requests','Searches','Settled','Pops','Pushes']} for category in ['estimates','shoppingRoutes','otherRoutes']})
        checks[pair]['routeWork']=dict(zip(['before','after'],totals))
checks['crossTickReuse']=[r for r in [json.loads(l) for l in (root/'million-reuse.jsonl').read_text().splitlines()] if r.get('type')=='crossTickReuse'][-1]
if (root/'services-10000.jsonl').exists():
    days,end=read('services-10000');totals={k:sum(r['CivicEvents'][k] for r in days) for k in days[0]['CivicEvents']}
    assert totals['SchoolAttended']>0 and totals['Treated']>0
    assert sum(r['Purchases'] for r in days)>0 and sum(r['Wages'] for r in days)>0
    checks['services']={'hash':end['hash'],'events':totals,'purchases':[r['Purchases'] for r in days],'wages':[r['Wages'] for r in days],'days':[{k:r[k] for k in ['StartTick','Citizens','MeanMs','P99Ms','AllocatedBytes']} for r in days]}
(root/'checks.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
