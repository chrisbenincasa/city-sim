import json, subprocess, time
from pathlib import Path
root = Path('/tmp/borough-payroll')
for citizens, seed, build in [(100000, 1, 'before'), (100000, 1, 'after'), (1000, 0, 'before'), (1000, 0, 'after')]:
    name = f'{build}-seed{seed}' if citizens == 100000 else f'{build}-small'
    command = ['dotnet', str(root / build / 'Borough.Headless.dll'), '--profile', '--ruleset', 'rulesets/stress-shopping.toml', '--citizens', str(citizens), '--seed', str(seed), '--warmup-ticks', '14336', '--ticks', '2048' if citizens == 100000 else '14336', '--no-decide-guard']
    record = {'command': command, 'cwd': str(Path.cwd()), 'started': time.time()}
    print('starting', name, flush=True)
    with (root / (name + '.jsonl')).open('x') as output, (root / (name + '.err')).open('x') as errors:
        result = subprocess.run(command, stdout=output, stderr=errors)
    record.update(ended=time.time(), exitCode=result.returncode)
    (root / (name + '-command.json')).write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode:
        raise SystemExit(result.returncode)
    print('finished', name, flush=True)
