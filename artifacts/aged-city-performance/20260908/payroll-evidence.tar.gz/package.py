import hashlib, json, subprocess, tarfile, sys
from pathlib import Path
root = Path('/tmp/borough-payroll')
destination = Path('artifacts/aged-city-performance/20260908')
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def read(name): return [json.loads(line) for line in (root / (name + '.jsonl')).read_text().splitlines()]
metrics = {'MeanMs','P95Ms','P99Ms','MaxMs','MaxTick','AllocatedBytes','Gen0Collections','Gen1Collections','Gen2Collections','ManagedHeapBytes','WorkingSetBytes'}
def compare(left, right):
    a, b = read(left), read(right)
    for key in ['rulesetSha256','Seed','Citizens','WarmupTicks','Ticks','network','stepThreads','configuration','runtime','DecideGuard']:
        assert a[0][key] == b[0][key], key
    assert a[-1] == b[-1] and a[-1]['invariants'] == 'passed'
    daysA = [r for r in a if 'MeanMs' in r]; daysB = [r for r in b if 'MeanMs' in r]
    assert len(daysA) == len(daysB)
    days = []
    for x,y in zip(daysA, daysB):
        assert {k:v for k,v in x.items() if k not in metrics} == {k:v for k,v in y.items() if k not in metrics}
        days.append({'start':x['StartTick'], 'before':{k:x[k] for k in sorted(metrics)}, 'after':{k:y[k] for k in sorted(metrics)}, 'meanReductionPercent':100*(1-y['MeanMs']/x['MeanMs'])})
    return {'beforeFile':left+'.jsonl','afterFile':right+'.jsonl','end':a[-1], 'activityMatches':True, 'days':days}
checks = {'retainedOptimization':False,
    'reason':'Employer-list iteration regressed seed 0. Roster timing reuse had mixed seed results and failed the two-seed retention gate; both removed.',
    'conditions':'Release .NET 10.0.11, Ubuntu 24.04, Intel Core i5-10400, one simulation thread, guard disabled. Unpinned desktop diagnostics, not a quiet-machine budget ratification. Focused tests/builds overlapped portions of ageing; no deliberate overlap with measured windows. No CPU-frequency or external-workload control.',
    'employerLists':compare('before-seed0','after-seed0'),
    'rosterSeed0':compare('before-seed0','roster-seed0'),
    'rosterSeed1':compare('before-seed1','roster-seed1'),
    'rosterSmallWeek':compare('before-small','roster-small'),
    'observerDisabled':compare('before-resumed','observer-resumed'),
    'observerEnabled':compare('observer-resumed','observer-counted')}
work = [r for r in read('observer-counted') if r.get('type') == 'work']
assert len(work) == 2048
keys = work[0]['payrollWork'].keys()
checks['payroll'] = {'startTick':work[0]['tick'],'ticks':len(work),
    'totals':{k:sum(r['payrollWork'][k] for r in work) for k in keys},
    'peaks':{k:max(r['payrollWork'][k] for r in work) for k in keys},
    'scope':'Diagnostic population scan immediately before accrual. Counts are Tick-summed visits, not distinct Citizens over the Day. OnDuty means entitlement, not wages paid. Counted Step timings and allocations include the additional scan.'}
checks['validationLogs'] = [Path(name).name for name in sys.argv[1:]]
(root / 'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
destination.mkdir(parents=True,exist_ok=True)
(destination / 'payroll-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
for name in ['before-seed0','after-seed0','before-seed1','roster-seed0']:
    rows = read(name); c = rows[0]; build = name.split('-')[0]
    command = ['dotnet',str(root/build/'Borough.Headless.dll'),'--profile','--ruleset',c['ruleset'],'--citizens',str(c['Citizens']),'--seed',str(c['Seed']),'--warmup-ticks',str(c['WarmupTicks']),'--ticks',str(c['Ticks']),'--no-decide-guard']
    if c['ProfileSavePath']: command += ['--profile-save',c['ProfileSavePath']]
    (root/(name+'-reproduction.json')).write_text(json.dumps({'command':command,'cwd':str(Path.cwd()),'source':'Reconstructed from the executed command and capture conditions. The original second-seed baseline outlived its cancelled scheduler; its end record is complete.'},indent=2)+'\n')
(root/'machine.txt').write_text(subprocess.check_output(['lscpu'],text=True))
(root/'baseline-WorkSchedule.cs').write_text(subprocess.check_output(['git','show','41f87dd:src/Borough.Core/Movement/WorkSchedule.cs'],text=True))
source = ['plans/0067-aged-city-performance.md','src/Borough.Core/Simulation.cs','src/Borough.Core/Movement/WorkSchedule.cs','src/Borough.Headless/ProfileDump.cs','src/Borough.Headless/ProfilePayroll.cs','tests/Borough.Tests/Rules/PayrollAccrualTests.cs','tests/Borough.Tests/Headless/ProfileDumpTests.cs','rulesets/stress-shopping.toml']
for name in source:
    target=root/'source'/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(Path(name).read_bytes())
logs = ['20260908-114612','20260908-114737','20260908-114829','20260908-114959','20260908-115124','20260908-115224','20260908-120149','20260908-120419','20260908-120531','20260908-121323','20260908-121639']
for name in [*(f'/tmp/borough-test-{s}.log' for s in logs),*sys.argv[1:]]:
    path=Path(name)
    if path.exists():
        target=root/'tests'/path.name; target.parent.mkdir(exist_ok=True); target.write_bytes(path.read_bytes())
(root/'checkpoint.json').write_text(json.dumps({'file':'seed0.save','sha256':sha(root/'seed0.save'),'bytes':(root/'seed0.save').stat().st_size,'reproduce':'before-seed0-reproduction.json','excluded':'Reproducible save dump excluded from archive.'},indent=2)+'\n')
files = [p for p in root.rglob('*') if p.is_file() and p.suffix != '.save']
manifest = {'archive':'payroll-evidence.tar.gz','baselineCommit':'41f87dd','files':{str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(files)}}
archive=destination/manifest['archive']
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(files): tar.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames()) == set(manifest['files'])
    for name, item in manifest['files'].items():
        with tar.extractfile(name) as stream: assert hashlib.file_digest(stream,'sha256').hexdigest() == item['sha256'],name
manifest.update(archiveSha256=sha(archive),archiveBytes=archive.stat().st_size,verified=True)
(destination/'payroll-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'payroll':checks['payroll'],'observerDisabled':checks['observerDisabled'],'archiveBytes':manifest['archiveBytes'],'verified':True},indent=2))
