import json, subprocess, time
from pathlib import Path
root = Path('/tmp/borough-payroll')
for build, counted in [('before', False), ('observer', False), ('observer', True)]:
    name = build + ('-counted' if counted else '-resumed')
    command = ['dotnet', str(root / build / 'Borough.Headless.dll'), '--profile', '--ruleset', 'rulesets/stress-shopping.toml', '--citizens', '100000', '--seed', '0', '--profile-load', str(root / 'seed0.save'), '--warmup-ticks', '18432', '--ticks', '2048', '--no-decide-guard']
    if counted: command.append('--profile-work')
    record = {'command': command, 'cwd': str(Path.cwd()), 'started': time.time()}
    print('starting', name, flush=True)
    with (root / (name + '.jsonl')).open('x') as output, (root / (name + '.err')).open('x') as errors:
        result = subprocess.run(command, stdout=output, stderr=errors)
    record.update(ended=time.time(), exitCode=result.returncode)
    (root / (name + '-command.json')).write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode: raise SystemExit(result.returncode)
    print('finished', name, flush=True)
