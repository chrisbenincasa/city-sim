import json,pathlib,subprocess
p=pathlib.Path('/tmp/borough-payroll-scan-20260908');spec=json.loads((p/'normal-command.json').read_text());spec['command'][1]=str(p/'measured/Borough.Headless.dll');spec['command'].append('--profile-work');(p/'measured-command.json').write_text(json.dumps(spec,indent=2))
subprocess.run(['python3','scripts/repeat-profile.py',str(p/'measured-command.json'),'--output',str(p/'measured-runs'),'--cpu','2','--repeats','2'],check=True)
