import pathlib,subprocess,time,json
p=pathlib.Path('/tmp/borough-payroll-scan-20260908')
while not (p/'control/summary.json').exists():time.sleep(1)
summary=json.loads((p/'control/summary.json').read_text());assert summary['equivalent_activity_hash']
cmd=['taskset','-c','2','python3','scripts/profile-simulation.py','--trace-tool','/tmp/borough-profiler/dotnet-trace','--binary',str(p/'diagnostic/Borough.Headless.dll'),'--profile-load','/tmp/borough-payroll/seed0.save','--warmup-ticks','18432','--ticks','2048','--output',str(p/'trace')]
(p/'trace-command.json').write_text(json.dumps({'command':cmd,'outsideSandbox':True},indent=2))
subprocess.run(cmd,check=True)
