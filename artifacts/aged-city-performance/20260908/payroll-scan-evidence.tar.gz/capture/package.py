import pathlib,json,hashlib,tarfile,subprocess
root=pathlib.Path('/home/christian/Code/city-sim');p=pathlib.Path(__file__).parent;out=root/'artifacts/aged-city-performance/20260908'
checks=json.loads((p/'scan-checks.json').read_text());base=json.loads((p/'control/summary.json').read_text())['runs'][0]
exclude={'MeanMs','P95Ms','P99Ms','MaxMs','MaxTick','AllocatedBytes','ManagedHeapBytes','WorkingSetBytes','Gen0Collections','Gen1Collections','Gen2Collections'}
trace=[json.loads(s) for s in (p/'trace/run.jsonl').read_text().splitlines()];daily=next(r for r in trace if 'MeanMs' in r);assert trace[-1]==base['end'];assert all(daily[k]==v for k,v in base['daily'].items() if k not in exclude)
checks['trace_activity_hash_matches']=True;checks['tests']={'diagnostic':'18 passed, borough-test-20260908-142958.log','normal':'18 passed, borough-test-20260908-143038.log'}
checks['limitations']=['Desktop host interference remains.','Empty-body calibration does not exactly reproduce real boundary overhead.','Normal builds omit diagnostic boundaries.','Frozen measured build precedes removal of the obsolete payrollScheduleNoInlining metadata field; attribution algorithm is unchanged.','No retained simulation optimization.']
(out/'payroll-scan-checks.json').write_text(json.dumps(checks,indent=2));files={}
for f in p.rglob('*'):
 if f.is_file():files['capture/'+str(f.relative_to(p))]=f
for name in ['src/Borough.Core/Borough.Core.csproj','src/Borough.Core/Movement/WorkSchedule.cs','src/Borough.Core/Simulation.cs','src/Borough.Headless/ProfileDump.cs','src/Borough.Headless/ProfilePayroll.cs','src/Borough.Headless/PayrollClock.cs','tests/Borough.Tests/Headless/ProfileDumpTests.cs','tests/Borough.Tests/Rules/PayrollAccrualTests.cs','scripts/repeat-profile.py','scripts/profile-simulation.py','scripts/summarize-simulation-profile.py','plans/0067-aged-city-performance.md','rulesets/stress-shopping.toml']:
 files['source/'+name]=root/name
for name in ['borough-test-20260908-141808.log','borough-test-20260908-141945.log','borough-test-20260908-142958.log','borough-test-20260908-143038.log']:
 files['validation/'+name]=pathlib.Path('/tmp')/name
for name in ['checkpoint.json','before-seed0-reproduction.json']:
 files['checkpoint/'+name]=pathlib.Path('/tmp/borough-payroll')/name
files['checks.json']=out/'payroll-scan-checks.json'
archive=out/'payroll-scan-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,f in sorted(files.items()):tar.add(f,arcname=name)
hashes={name:hashlib.sha256(f.read_bytes()).hexdigest() for name,f in files.items()}
with tarfile.open(archive) as tar:
 assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar if m.isfile()}==hashes
(out/'payroll-scan-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':hashes,'verified':True,'save':'Excluded reproducible 85 MB checkpoint; fingerprint and original recreation command retained.'},indent=2))
print('Verified',len(files),'files;',archive.stat().st_size,'archive bytes')
